package com.bionote.attachment;

import com.bionote.common.ApiResponse;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.security.core.Authentication;
import org.springframework.web.multipart.MultipartFile;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("AttachmentController 层测试")
class AttachmentControllerTest {

    @Mock
    private AttachmentUseCase service;

    @Mock
    private Authentication authentication;

    @Mock
    private MultipartFile multipartFile;

    @InjectMocks
    private AttachmentController controller;

    private final UUID userId = UUID.fromString("00000000-0000-0000-0000-000000000001");
    private final UUID recordId = UUID.randomUUID();
    private final UUID attachmentId = UUID.randomUUID();

    @Test
    @DisplayName("GET 附件列表应返回列表")
    void shouldListAttachments() {
        when(authentication.getName()).thenReturn(userId.toString());
        when(service.list(eq(userId), eq(recordId))).thenReturn(List.of());

        var result = controller.list(authentication, recordId);

        assertNotNull(result);
        assertTrue(result.getData().isEmpty());
    }

    @Test
    @DisplayName("POST 上传附件应返回附件信息")
    void shouldUploadAttachment() {
        when(authentication.getName()).thenReturn(userId.toString());
        AttachmentDtos.View mockView = new AttachmentDtos.View(
                attachmentId, recordId, "test.pdf", "application/pdf",
                1024L, true, userId, "测试用户", Instant.now(), false, true);
        when(service.upload(any(), eq(recordId), any())).thenReturn(mockView);

        var result = controller.upload(authentication, recordId, multipartFile);

        assertNotNull(result);
        assertEquals("test.pdf", result.getData().originalFilename());
    }

    @Test
    @DisplayName("DELETE 附件应返回 204")
    void shouldDeleteAttachment() {
        when(authentication.getName()).thenReturn(userId.toString());
        doNothing().when(service).delete(any(), eq(attachmentId));

        var result = controller.delete(authentication, attachmentId);

        assertNotNull(result);
        assertEquals(204, result.getStatusCode().value());
    }

    @Test
    @DisplayName("GET 预览应返回文件内容")
    void shouldPreviewAttachment() {
        when(authentication.getName()).thenReturn(userId.toString());
        AttachmentUseCase.FilePayload payload = new AttachmentUseCase.FilePayload(
                "test content".getBytes(), "test.txt", "text/plain");
        when(service.load(any(), eq(attachmentId), eq(true))).thenReturn(payload);

        var result = controller.preview(authentication, attachmentId);

        assertNotNull(result);
        assertEquals(200, result.getStatusCode().value());
        assertArrayEquals("test content".getBytes(), result.getBody());
    }

    @Test
    @DisplayName("GET 下载应返回文件内容带 attachment 头")
    void shouldDownloadAttachment() {
        when(authentication.getName()).thenReturn(userId.toString());
        AttachmentUseCase.FilePayload payload = new AttachmentUseCase.FilePayload(
                "test content".getBytes(), "test.pdf", "application/pdf");
        when(service.load(any(), eq(attachmentId), eq(false))).thenReturn(payload);

        var result = controller.download(authentication, attachmentId);

        assertNotNull(result);
        assertEquals(200, result.getStatusCode().value());
    }

    @Test
    @DisplayName("GET 修订附件列表应返回列表")
    void shouldListRevisionAttachments() {
        when(authentication.getName()).thenReturn(userId.toString());
        UUID revisionId = UUID.randomUUID();
        when(service.revisionAttachments(any(), eq(revisionId))).thenReturn(List.of());

        var result = controller.revisionAttachments(authentication, revisionId);

        assertNotNull(result);
    }
}
