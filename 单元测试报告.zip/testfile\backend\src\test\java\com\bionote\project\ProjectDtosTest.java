package com.bionote.project;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
class ProjectDtosTest {

    private final UUID projectId = UUID.randomUUID();
    private final UUID ownerId = UUID.randomUUID();
    private final Instant now = Instant.now();

    @Test
    void shouldCreateCreateProjectRequest() {
        ProjectDtos.CreateProjectRequest request = new ProjectDtos.CreateProjectRequest("项目名", "描述", "详细描述");
        assertEquals("项目名", request.name());
        assertEquals("描述", request.description());
        assertEquals("详细描述", request.detailedDescription());
    }

    @Test
    void shouldCreateInviteRequest() {
        ProjectDtos.InviteRequest request = new ProjectDtos.InviteRequest("user@example.com");
        assertEquals("user@example.com", request.email());
    }

    @Test
    void shouldCreateRoleRequest() {
        ProjectDtos.RoleRequest request = new ProjectDtos.RoleRequest("REVIEWER", Map.of());
        assertEquals("REVIEWER", request.role());
        assertNotNull(request.reassignments());
    }

    @Test
    void shouldCreateRemoveRequest() {
        ProjectDtos.RemoveRequest request = new ProjectDtos.RemoveRequest(Map.of());
        assertNotNull(request.reassignments());
    }

    @Test
    void shouldCreateProjectView() {
        ProjectDtos.ProjectView view = new ProjectDtos.ProjectView(
                projectId, "项目", "desc", "detail", "ACTIVE", ownerId,
                "OWNER", now, now, null, 0L,
                Map.of("canManage", true), 5L, 10L);
        assertEquals(projectId, view.id());
        assertEquals("OWNER", view.currentUserRole());
        assertEquals(5L, view.memberCount());
        assertEquals(10L, view.recordCount());
    }

    @Test
    void shouldCreateMemberView() {
        ProjectDtos.MemberView member = new ProjectDtos.MemberView(
                UUID.randomUUID(), "成员", "m@test.com", null, "MEMBER",
                now, now, Map.of("canCreateRecord", true));
        assertEquals("MEMBER", member.role());
    }

    @Test
    void shouldCreateInvitationView() {
        ProjectDtos.InvitationView view = new ProjectDtos.InvitationView(
                UUID.randomUUID(), projectId, "项目名", UUID.randomUUID(),
                "invitee@test.com", "PENDING", now.plusSeconds(86400), now);
        assertEquals("PENDING", view.status());
    }

    @Test
    void shouldCreateBlockingResponse() {
        RecordMembershipGuard.BlockingItem item = new RecordMembershipGuard.BlockingItem(
                UUID.randomUUID(), "记录1", "IN_PROGRESS");
        ProjectDtos.BlockingResponse response = new ProjectDtos.BlockingResponse(
                "仍有未完成记录", List.of(item));
        assertEquals("仍有未完成记录", response.message());
        assertEquals(1, response.blockingRecords().size());
    }
}
