import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import PageHeader from '@/components/ui/PageHeader';

describe('PageHeader', () => {
  it('renders title', () => {
    render(<PageHeader title="项目管理" />);
    expect(screen.getByText('项目管理')).toBeInTheDocument();
  });

  it('renders eyebrow text when provided', () => {
    render(<PageHeader eyebrow="工作区" title="实验记录" />);
    expect(screen.getByText('工作区')).toBeInTheDocument();
  });

  it('does not render eyebrow when not provided', () => {
    const { container } = render(<PageHeader title="搜索" />);
    expect(container.querySelector('.text-brand-600')).toBeNull();
  });

  it('renders description when provided', () => {
    render(
      <PageHeader
        title="模板中心"
        description="管理所有实验模板"
      />
    );
    expect(screen.getByText('管理所有实验模板')).toBeInTheDocument();
  });

  it('renders actions area when provided', () => {
    render(
      <PageHeader
        title="项目列表"
        actions={<button>新建项目</button>}
      />
    );
    expect(screen.getByRole('button', { name: '新建项目' })).toBeInTheDocument();
  });
});
