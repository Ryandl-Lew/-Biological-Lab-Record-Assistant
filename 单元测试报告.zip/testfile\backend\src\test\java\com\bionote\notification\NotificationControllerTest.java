package com.bionote.notification;

import com.bionote.common.PagedResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificationControllerTest {

    @Mock
    private NotificationUseCase service;

    @InjectMocks
    private NotificationController controller;

    private static final UUID USER_ID = UUID.randomUUID();
    private static final UUID NOTIF_ID = UUID.randomUUID();

    @Test
    void list_shouldReturnPagedResponseFromService() {
        NotificationDtos.View view = new NotificationDtos.View(
                NOTIF_ID, "SYSTEM", "Test", "Body",
                Map.of("type", "NONE"), List.of(), false, Instant.now(), null
        );
        PagedResponse<NotificationDtos.View> expected = PagedResponse.of(List.of(view), 0, 20, 1);
        when(service.list(USER_ID, false, 0, 20)).thenReturn(expected);

        PagedResponse<NotificationDtos.View> result = service.list(USER_ID, false, 0, 20);

        assertNotNull(result);
        assertEquals(1, result.data().size());
    }

    @Test
    void count_shouldReturnCountInResponse() {
        when(service.unread(USER_ID)).thenReturn(3L);

        var response = service.unread(USER_ID);

        assertEquals(3L, response);
    }

    @Test
    void read_shouldCallServiceRead() {
        doNothing().when(service).read(USER_ID, NOTIF_ID);

        service.read(USER_ID, NOTIF_ID);

        verify(service).read(USER_ID, NOTIF_ID);
    }

    @Test
    void readAll_shouldCallServiceReadAll() {
        doNothing().when(service).readAll(USER_ID);

        service.readAll(USER_ID);

        verify(service).readAll(USER_ID);
    }

    @Test
    void read_shouldThrowWhenServiceThrows() {
        doThrow(new com.bionote.common.ApiException(HttpStatus.NOT_FOUND, "RESOURCE_NOT_FOUND", "通知不存在"))
                .when(service).read(USER_ID, NOTIF_ID);

        assertThrows(com.bionote.common.ApiException.class,
                () -> service.read(USER_ID, NOTIF_ID));
    }

    @Test
    void list_errorCase_serviceReturnsEmptyForUnreadOnly() {
        when(service.list(USER_ID, true, 0, 20))
                .thenReturn(PagedResponse.of(List.of(), 0, 20, 0));

        var result = service.list(USER_ID, true, 0, 20);

        assertTrue(result.data().isEmpty());
        assertEquals(0, result.meta().totalElements());
    }
}
