package com.bionote.template;

import com.bionote.collaboration.CollaborationEvents;
import com.bionote.common.ApiException;
import com.bionote.common.PagedResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TemplateServiceTest {

    @Mock
    private TemplateStore templates;

    @Mock
    private TemplateJsonCodec json;

    @Mock
    private CollaborationEvents events;

    @InjectMocks
    private TemplateService service;

    private static final UUID USER_ID = UUID.randomUUID();
    private static final UUID TEMPLATE_ID = UUID.randomUUID();
    private static final Instant NOW = Instant.now();

    private TemplateStore.TemplateRecord createTemplateRecord() {
        return createTemplateRecordWithName("测试模板");
    }

    private TemplateStore.TemplateRecord createTemplateRecordWithName(String name) {
        return new TemplateStore.TemplateRecord(
                TEMPLATE_ID, "PERSONAL", USER_ID, name, "化学", "实验",
                "测试用模板", NOW, NOW, null, 1L, List.of()
        );
    }

    @Test
    void list_shouldReturnPagedResponse() {
        when(templates.search(eq(USER_ID), eq(null), eq(null), eq(""), eq(0), eq(20)))
                .thenReturn(new TemplateStore.PageSlice(List.of(createTemplateRecord()), 1));

        PagedResponse<TemplateDtos.View> result = service.list(USER_ID, null, null, "", 0, 20);

        assertNotNull(result);
        assertEquals(1, result.meta().totalElements());
        assertEquals(1, result.data().size());
    }

    @Test
    void get_shouldReturnTemplate() {
        when(templates.findVisible(USER_ID, TEMPLATE_ID)).thenReturn(Optional.of(createTemplateRecord()));

        TemplateDtos.View result = service.get(USER_ID, TEMPLATE_ID);

        assertNotNull(result);
        assertEquals("测试模板", result.name());
    }

    @Test
    void get_shouldThrowWhenNotFound() {
        when(templates.findVisible(USER_ID, TEMPLATE_ID)).thenReturn(Optional.empty());

        ApiException ex = assertThrows(ApiException.class, () -> service.get(USER_ID, TEMPLATE_ID));

        assertEquals("RESOURCE_NOT_FOUND", ex.code());
        assertEquals(HttpStatus.NOT_FOUND, ex.status());
    }

    @Test
    void create_shouldSucceed() {
        TemplateDtos.SaveRequest request = new TemplateDtos.SaveRequest(
                "新模板", "物理", "力学", "描述",
                List.of(new TemplateDtos.FieldRequest("force", "力", "NUMBER", false, "N", null, List.of())),
                null
        );
        lenient().when(json.encode(isNull())).thenReturn(null);
        doNothing().when(templates).insert(any(), anyList());
        when(templates.findVisible(eq(USER_ID), any(UUID.class)))
                .thenReturn(Optional.of(createTemplateRecordWithName("新模板")));

        TemplateDtos.View result = service.create(USER_ID, request);

        assertNotNull(result);
        assertEquals("新模板", result.name());
    }

    @Test
    void delete_shouldSucceed() {
        TemplateStore.TemplateRecord record = createTemplateRecord();
        when(templates.findVisible(USER_ID, TEMPLATE_ID)).thenReturn(Optional.of(record));
        when(templates.softDelete(eq(TEMPLATE_ID), eq(USER_ID), eq(1L), any(Instant.class)))
                .thenReturn(true);

        assertDoesNotThrow(() -> service.delete(USER_ID, TEMPLATE_ID));
    }

    @Test
    void delete_shouldThrowWhenNotOwner() {
        UUID otherOwner = UUID.randomUUID();
        TemplateStore.TemplateRecord record = new TemplateStore.TemplateRecord(
                TEMPLATE_ID, "PERSONAL", otherOwner, "他人模板", "类型", "分类",
                "描述", NOW, NOW, null, 1L, List.of()
        );
        when(templates.findVisible(USER_ID, TEMPLATE_ID)).thenReturn(Optional.of(record));

        ApiException ex = assertThrows(ApiException.class, () -> service.delete(USER_ID, TEMPLATE_ID));

        assertEquals("ACCESS_DENIED", ex.code());
        assertEquals(HttpStatus.FORBIDDEN, ex.status());
    }

    @Test
    void update_shouldThrowWhenVersionMismatch() {
        TemplateStore.TemplateRecord record = createTemplateRecord();
        when(templates.findVisible(USER_ID, TEMPLATE_ID)).thenReturn(Optional.of(record));

        TemplateDtos.SaveRequest request = new TemplateDtos.SaveRequest(
                "更新模板", "化学", "实验", "描述",
                List.of(new TemplateDtos.FieldRequest("temp", "温度", "NUMBER", false, "", null, List.of())),
                5L // Wrong version
        );

        ApiException ex = assertThrows(ApiException.class, () -> service.update(USER_ID, TEMPLATE_ID, request));

        assertEquals("OPTIMISTIC_LOCK_CONFLICT", ex.code());
    }

    @Test
    void copy_shouldCreateDuplicate() {
        TemplateStore.TemplateRecord original = createTemplateRecord();
        when(templates.findVisible(USER_ID, TEMPLATE_ID)).thenReturn(Optional.of(original));
        when(templates.existsByActiveNameKey(anyString())).thenReturn(false);
        lenient().when(json.encode(isNull())).thenReturn(null);
        doNothing().when(templates).insert(any(), anyList());
        when(templates.findVisible(eq(USER_ID), any(UUID.class)))
                .thenReturn(Optional.of(createTemplateRecordWithName("测试模板 副本")));

        TemplateDtos.View result = service.copy(USER_ID, TEMPLATE_ID);

        assertNotNull(result);
        assertTrue(result.name().contains("副本"));
    }
}
