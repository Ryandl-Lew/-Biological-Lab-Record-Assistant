package com.bionote.notification.infrastructure.persistence;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.TestPropertySource;

import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@TestPropertySource(properties = {"spring.flyway.enabled=false", "spring.jpa.hibernate.ddl-auto=update"})
class NotificationJpaRepositoryTest {

    @Autowired
    private NotificationJpaRepository repository;

    @Autowired
    private TestEntityManager entityManager;

    @Test
    void findByRecipientId_shouldReturnPagedResults() {
        UUID recipientId = UUID.randomUUID();
        NotificationEntity entity = new NotificationEntity();
        setId(entity, UUID.randomUUID());
        setField(entity, "recipientId", recipientId);
        setField(entity, "type", "SYSTEM");
        setField(entity, "title", "Test");
        setField(entity, "body", "Body text");
        setField(entity, "payloadJson", "{}");
        setField(entity, "dedupKey", UUID.randomUUID().toString());
        setField(entity, "createdAt", Instant.now());

        entityManager.persist(entity);
        entityManager.flush();

        Page<NotificationEntity> result = repository.findByRecipientIdOrderByCreatedAtDescIdDesc(
                recipientId, PageRequest.of(0, 20));

        assertEquals(1, result.getTotalElements());
    }

    @Test
    void countByRecipientIdAndReadAtIsNull_shouldReturnCount() {
        UUID recipientId = UUID.randomUUID();
        NotificationEntity e1 = createEntity(recipientId, null);
        NotificationEntity e2 = createEntity(recipientId, null);

        entityManager.persist(e1);
        entityManager.persist(e2);
        entityManager.flush();

        long count = repository.countByRecipientIdAndReadAtIsNull(recipientId);

        assertEquals(2, count);
    }

    @Test
    void markRead_shouldUpdateReadAt() {
        UUID recipientId = UUID.randomUUID();
        UUID id = UUID.randomUUID();
        NotificationEntity entity = createEntity(recipientId, null);
        setId(entity, id);

        entityManager.persist(entity);
        entityManager.flush();

        Instant now = Instant.now();
        int updated = repository.markRead(id, recipientId, now);

        assertEquals(1, updated);
    }

    @Test
    void findByRecipientIdAndReadAtIsNull_shouldReturnOnlyUnread() {
        UUID recipientId = UUID.randomUUID();
        NotificationEntity e1 = createEntity(recipientId, null);

        entityManager.persist(e1);
        entityManager.flush();

        Page<NotificationEntity> result = repository.findByRecipientIdAndReadAtIsNullOrderByCreatedAtDescIdDesc(
                recipientId, PageRequest.of(0, 20));

        assertEquals(1, result.getTotalElements());
    }

    @Test
    void markRead_shouldReturnZeroWhenNotFound() {
        int updated = repository.markRead(UUID.randomUUID(), UUID.randomUUID(), Instant.now());
        assertEquals(0, updated);
    }

    private NotificationEntity createEntity(UUID recipientId, Instant readAt) {
        NotificationEntity entity = new NotificationEntity();
        setId(entity, UUID.randomUUID());
        setField(entity, "recipientId", recipientId);
        setField(entity, "type", "SYSTEM");
        setField(entity, "title", "Title");
        setField(entity, "body", "Body");
        setField(entity, "payloadJson", "{}");
        setField(entity, "dedupKey", UUID.randomUUID().toString());
        setField(entity, "createdAt", Instant.now());
        if (readAt != null) {
            setField(entity, "readAt", readAt);
        }
        return entity;
    }

    private void setId(NotificationEntity entity, UUID id) {
        try {
            var field = NotificationEntity.class.getDeclaredField("id");
            field.setAccessible(true);
            field.set(entity, id);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private void setField(NotificationEntity entity, String name, Object value) {
        try {
            var field = NotificationEntity.class.getDeclaredField(name);
            field.setAccessible(true);
            field.set(entity, value);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
