package com.bionote.template.infrastructure.persistence;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.TestPropertySource;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@TestPropertySource(properties = {"spring.flyway.enabled=false", "spring.jpa.hibernate.ddl-auto=update"})
class TemplateFieldJpaRepositoryTest {

    @Autowired
    private TemplateFieldJpaRepository repository;

    @Autowired
    private TestEntityManager entityManager;

    @Test
    void save_shouldPersistField() {
        UUID templateId = UUID.randomUUID();
        TemplateFieldEntity field = new TemplateFieldEntity(
                UUID.randomUUID(), templateId, "pH", "pH值", "NUMBER",
                false, 0, "7.0", null, null
        );

        TemplateFieldEntity saved = repository.save(field);
        entityManager.flush();

        assertNotNull(saved);
        assertNotNull(entityManager.find(TemplateFieldEntity.class, field.id));
    }

    @Test
    void findByTemplateId_shouldReturnOrderedFields() {
        UUID templateId = UUID.randomUUID();

        TemplateFieldEntity f1 = new TemplateFieldEntity(
                UUID.randomUUID(), templateId, "f1", "F1", "NUMBER",
                false, 2, null, null, null
        );
        TemplateFieldEntity f2 = new TemplateFieldEntity(
                UUID.randomUUID(), templateId, "f2", "F2", "SINGLE_LINE_TEXT",
                true, 0, "enter", null, null
        );
        TemplateFieldEntity f3 = new TemplateFieldEntity(
                UUID.randomUUID(), templateId, "f3", "F3", "SELECT",
                true, 1, null, null, "[]"
        );

        entityManager.persist(f1);
        entityManager.persist(f2);
        entityManager.persist(f3);
        entityManager.flush();

        List<TemplateFieldEntity> result = repository.findByTemplateIdOrderBySortOrderAsc(templateId);

        assertEquals(3, result.size());
        assertEquals(0, result.get(0).sortOrder);
        assertEquals(1, result.get(1).sortOrder);
        assertEquals(2, result.get(2).sortOrder);
        assertEquals("f2", result.get(0).fieldKey);
        assertEquals("f3", result.get(1).fieldKey);
        assertEquals("f1", result.get(2).fieldKey);
    }

    @Test
    void findByTemplateId_shouldReturnEmptyForUnknownTemplate() {
        List<TemplateFieldEntity> result = repository.findByTemplateIdOrderBySortOrderAsc(UUID.randomUUID());

        assertTrue(result.isEmpty());
    }

    @Test
    void deleteByTemplateId_shouldRemoveAllFields() {
        UUID templateId = UUID.randomUUID();

        TemplateFieldEntity f1 = new TemplateFieldEntity(
                UUID.randomUUID(), templateId, "k1", "L1", "NUMBER",
                false, 0, null, null, null
        );
        TemplateFieldEntity f2 = new TemplateFieldEntity(
                UUID.randomUUID(), templateId, "k2", "L2", "DATE",
                false, 1, null, null, null
        );

        entityManager.persist(f1);
        entityManager.persist(f2);
        entityManager.flush();

        long deleted = repository.deleteByTemplateId(templateId);
        entityManager.flush();

        assertEquals(2, deleted);
        assertTrue(repository.findByTemplateIdOrderBySortOrderAsc(templateId).isEmpty());
    }

    @Test
    void deleteByTemplateId_shouldReturnZeroForUnknownTemplate() {
        long deleted = repository.deleteByTemplateId(UUID.randomUUID());

        assertEquals(0, deleted);
    }
}
