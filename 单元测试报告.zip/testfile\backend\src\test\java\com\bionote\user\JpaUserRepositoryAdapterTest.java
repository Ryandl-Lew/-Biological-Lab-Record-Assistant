package com.bionote.user;

import com.bionote.user.infrastructure.persistence.JpaUserRepositoryAdapter;
import com.bionote.user.infrastructure.persistence.UserJpaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JpaUserRepositoryAdapterTest {

    @Mock private UserJpaRepository repository;
    private JpaUserRepositoryAdapter adapter;
    private final UUID userId = UUID.randomUUID();
    private User testUser;

    @BeforeEach
    void setUp() {
        adapter = new JpaUserRepositoryAdapter(repository);
        testUser = new User(userId, "测试", "test@test.com", "hash", Instant.now());
    }

    @Test
    void shouldFindById() {
        when(repository.findById(userId)).thenReturn(Optional.of(testUser));
        Optional<User> result = adapter.findById(userId);
        assertTrue(result.isPresent());
        assertEquals(userId, result.get().getId());
    }

    @Test
    void shouldReturnEmptyWhenUserNotFound() {
        when(repository.findById(userId)).thenReturn(Optional.empty());
        Optional<User> result = adapter.findById(userId);
        assertFalse(result.isPresent());
    }

    @Test
    void shouldFindByEmailNormalized() {
        when(repository.findByEmailNormalized("test@test.com")).thenReturn(Optional.of(testUser));
        Optional<User> result = adapter.findByEmailNormalized("test@test.com");
        assertTrue(result.isPresent());
    }

    @Test
    void shouldCheckExistsByEmail() {
        when(repository.existsByEmailNormalized("test@test.com")).thenReturn(true);
        assertTrue(adapter.existsByEmailNormalized("test@test.com"));
    }

    @Test
    void shouldCheckExistsById() {
        when(repository.existsById(userId)).thenReturn(true);
        assertTrue(adapter.existsById(userId));
    }

    @Test
    void shouldSaveUser() {
        when(repository.save(testUser)).thenReturn(testUser);
        User result = adapter.save(testUser);
        assertEquals(userId, result.getId());
    }

    @Test
    void shouldSaveAndFlush() {
        when(repository.saveAndFlush(testUser)).thenReturn(testUser);
        User result = adapter.saveAndFlush(testUser);
        assertEquals(userId, result.getId());
    }

    @Test
    void shouldDeleteAll() {
        adapter.deleteAll();
        verify(repository).deleteAll();
    }
}
