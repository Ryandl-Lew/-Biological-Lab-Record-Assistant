import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import ProtectedRoute from '@/components/auth/ProtectedRoute';

let mockState = { currentUser: null, loading: true };

vi.mock('@/store/authStore', () => ({
  useAuthStore: (selector) => {
    return selector ? selector(mockState) : mockState;
  },
}));

describe('ProtectedRoute', () => {
  const renderWithRouter = (ui) => render(<MemoryRouter>{ui}</MemoryRouter>);

  beforeEach(() => {
    mockState = { currentUser: null, loading: true };
  });

  it('renders children when user is authenticated', () => {
    mockState = { currentUser: { id: '1' }, loading: false };
    renderWithRouter(
      <ProtectedRoute>
        <div>受保护内容</div>
      </ProtectedRoute>
    );
    expect(screen.getByText('受保护内容')).toBeInTheDocument();
  });

  it('redirects to /login when user is not authenticated', () => {
    mockState = { currentUser: null, loading: false };
    renderWithRouter(
      <ProtectedRoute>
        <div>受保护内容</div>
      </ProtectedRoute>
    );
    expect(screen.queryByText('受保护内容')).toBeNull();
  });

  it('shows loading state while session is restoring', () => {
    mockState = { currentUser: null, loading: true };
    renderWithRouter(
      <ProtectedRoute>
        <div>受保护内容</div>
      </ProtectedRoute>
    );
    expect(screen.getByText('加载中...')).toBeInTheDocument();
  });
});
