package com.bionote.review;

import org.junit.jupiter.api.Test;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class ReviewDtosTest {

    private final UUID reviewerId = UUID.randomUUID();
    private final UUID recordId = UUID.randomUUID();
    private final UUID revisionId = UUID.randomUUID();
    private final UUID reviewId = UUID.randomUUID();
    private final Instant now = Instant.now();

    @Test
    void shouldCreateSubmitRequest() {
        ReviewDtos.SubmitRequest request = new ReviewDtos.SubmitRequest(reviewerId, "提交说明", 0L);
        assertEquals(reviewerId, request.reviewerId());
        assertEquals("提交说明", request.submitNote());
        assertEquals(0L, request.expectedRecordVersion());
    }

    @Test
    void shouldCreateSubmitRequestWithNullNote() {
        ReviewDtos.SubmitRequest request = new ReviewDtos.SubmitRequest(reviewerId, null, 5L);
        assertNull(request.submitNote());
    }

    @Test
    void shouldCreateDecisionRequest() {
        ReviewDtos.DecisionRequest request = new ReviewDtos.DecisionRequest("审核意见");
        assertEquals("审核意见", request.comment());
    }

    @Test
    void shouldCreateDecisionRequestWithNullComment() {
        ReviewDtos.DecisionRequest request = new ReviewDtos.DecisionRequest(null);
        assertNull(request.comment());
    }

    @Test
    void shouldCreateCandidate() {
        ReviewDtos.Candidate candidate = new ReviewDtos.Candidate(reviewerId, "审核者1", "REVIEWER");
        assertEquals(reviewerId, candidate.userId());
        assertEquals("审核者1", candidate.displayName());
        assertEquals("REVIEWER", candidate.role());
    }

    @Test
    void shouldCreateReviewView() {
        ReviewDtos.ReviewView reviewView = new ReviewDtos.ReviewView(
                reviewId, revisionId, reviewerId, "审核者", "PENDING",
                null, now, null, true);
        assertEquals(reviewId, reviewView.id());
        assertEquals("PENDING", reviewView.status());
        assertTrue(reviewView.canDecide());
    }

    @Test
    void shouldCreateReviewViewDecided() {
        ReviewDtos.ReviewView reviewView = new ReviewDtos.ReviewView(
                reviewId, revisionId, reviewerId, "审核者", "APPROVED",
                "通过", now, now, false);
        assertEquals("APPROVED", reviewView.status());
        assertEquals("通过", reviewView.decisionComment());
        assertFalse(reviewView.canDecide());
    }

    @Test
    void shouldCreateRevisionView() {
        List<Map<String, Object>> attachmentViews = List.of();
        ReviewDtos.ReviewView reviewView = new ReviewDtos.ReviewView(
                reviewId, revisionId, reviewerId, "审核者", "PENDING",
                null, now, null, true);

        ReviewDtos.RevisionView revisionView = new ReviewDtos.RevisionView(
                revisionId, 1, Map.of("title", "快照"), "hash123",
                "提交说明", UUID.randomUUID(), "提交人", now,
                reviewView, attachmentViews);

        assertEquals(revisionId, revisionView.id());
        assertEquals(1, revisionView.revisionNo());
        assertEquals("hash123", revisionView.contentHash());
        assertEquals("提交人", revisionView.submitterName());
        assertNotNull(revisionView.review());
        assertNotNull(revisionView.attachments());
    }

    @Test
    void shouldCreatePendingReview() {
        ReviewDtos.PendingReview pending = new ReviewDtos.PendingReview(
                reviewId, recordId, "EXP-001", "实验记录",
                UUID.randomUUID(), "项目名", 2, now);
        assertEquals(reviewId, pending.reviewId());
        assertEquals("EXP-001", pending.recordCode());
        assertEquals(2, pending.revisionNo());
    }
}
