package com.bionote.review;

import com.bionote.collaboration.CollaborationEvents;
import com.bionote.common.ApiException;
import com.bionote.project.ProjectMemberStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReviewAssignmentServiceTest {

    @Mock private ReviewStore reviews;
    @Mock private ProjectMemberStore members;
    @Mock private CollaborationEvents events;

    private ReviewAssignmentService service;
    private final UUID actorId = UUID.randomUUID();
    private final UUID projectId = UUID.randomUUID();
    private final UUID currentReviewerId = UUID.randomUUID();
    private final UUID nextReviewerId = UUID.randomUUID();
    private final UUID reviewId1 = UUID.randomUUID();
    private final UUID recordId1 = UUID.randomUUID();
    private final UUID creatorId = UUID.randomUUID();

    @BeforeEach
    void setUp() {
        service = new ReviewAssignmentService(reviews, members, events);
    }

    @Test
    void shouldReturnZeroWhenNoPendingAssignments() {
        when(reviews.pendingAssignments(projectId, currentReviewerId)).thenReturn(List.of());

        int count = service.reassignPending(actorId, projectId, currentReviewerId, Map.of());
        assertEquals(0, count);
    }

    @Test
    void shouldReassignPendingSuccessfully() {
        ReviewStore.PendingAssignmentRecord record = new ReviewStore.PendingAssignmentRecord(
                reviewId1, recordId1, creatorId, "记录标题", 1);
        when(reviews.pendingAssignments(projectId, currentReviewerId)).thenReturn(List.of(record));
        when(members.findRole(projectId, nextReviewerId)).thenReturn(Optional.of("REVIEWER"));
        when(reviews.reassignPending(reviewId1, currentReviewerId, nextReviewerId)).thenReturn(true);

        Map<UUID, UUID> assignments = Map.of(reviewId1, nextReviewerId);

        int count = service.reassignPending(actorId, projectId, currentReviewerId, assignments);
        assertEquals(1, count);
    }

    @Test
    void shouldThrowWhenAssignmentKeyMismatch() {
        ReviewStore.PendingAssignmentRecord record = new ReviewStore.PendingAssignmentRecord(
                reviewId1, recordId1, creatorId, "记录标题", 1);
        when(reviews.pendingAssignments(projectId, currentReviewerId)).thenReturn(List.of(record));

        // Wrong keys - should throw
        Map<UUID, UUID> assignments = Map.of(UUID.randomUUID(), nextReviewerId);

        ApiException ex = assertThrows(ApiException.class,
                () -> service.reassignPending(actorId, projectId, currentReviewerId, assignments));
        assertEquals(HttpStatus.CONFLICT, ex.status());
    }

    @Test
    void shouldThrowWhenNextReviewerIsSameAsCurrent() {
        ReviewStore.PendingAssignmentRecord record = new ReviewStore.PendingAssignmentRecord(
                reviewId1, recordId1, creatorId, "记录标题", 1);
        when(reviews.pendingAssignments(projectId, currentReviewerId)).thenReturn(List.of(record));

        Map<UUID, UUID> assignments = Map.of(reviewId1, currentReviewerId);

        ApiException ex = assertThrows(ApiException.class,
                () -> service.reassignPending(actorId, projectId, currentReviewerId, assignments));
        assertEquals(HttpStatus.BAD_REQUEST, ex.status());
    }

    @Test
    void shouldThrowWhenNextReviewerIsCreator() {
        ReviewStore.PendingAssignmentRecord record = new ReviewStore.PendingAssignmentRecord(
                reviewId1, recordId1, creatorId, "记录标题", 1);
        when(reviews.pendingAssignments(projectId, currentReviewerId)).thenReturn(List.of(record));

        Map<UUID, UUID> assignments = Map.of(reviewId1, creatorId);

        ApiException ex = assertThrows(ApiException.class,
                () -> service.reassignPending(actorId, projectId, currentReviewerId, assignments));
        assertEquals(HttpStatus.BAD_REQUEST, ex.status());
    }

    @Test
    void shouldThrowWhenNextReviewerNotValidRole() {
        ReviewStore.PendingAssignmentRecord record = new ReviewStore.PendingAssignmentRecord(
                reviewId1, recordId1, creatorId, "记录标题", 1);
        when(reviews.pendingAssignments(projectId, currentReviewerId)).thenReturn(List.of(record));
        when(members.findRole(projectId, nextReviewerId)).thenReturn(Optional.of("MEMBER"));

        Map<UUID, UUID> assignments = Map.of(reviewId1, nextReviewerId);

        ApiException ex = assertThrows(ApiException.class,
                () -> service.reassignPending(actorId, projectId, currentReviewerId, assignments));
        assertEquals(HttpStatus.BAD_REQUEST, ex.status());
    }

    @Test
    void shouldThrowWhenNullAssignmentsProvided() {
        ReviewStore.PendingAssignmentRecord record = new ReviewStore.PendingAssignmentRecord(
                reviewId1, recordId1, creatorId, "记录标题", 1);
        when(reviews.pendingAssignments(projectId, currentReviewerId)).thenReturn(List.of(record));

        ApiException ex = assertThrows(ApiException.class,
                () -> service.reassignPending(actorId, projectId, currentReviewerId, null));
        assertEquals(HttpStatus.CONFLICT, ex.status());
    }
}
