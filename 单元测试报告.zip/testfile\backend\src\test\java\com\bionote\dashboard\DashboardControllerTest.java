package com.bionote.dashboard;

import com.bionote.common.ApiResponse;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.security.core.Authentication;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("DashboardController 层测试")
class DashboardControllerTest {

    @Mock
    private DashboardUseCase service;

    @Mock
    private Authentication authentication;

    @InjectMocks
    private DashboardController controller;

    private final UUID userId = UUID.fromString("00000000-0000-0000-0000-000000000001");
    private final UUID targetId = UUID.randomUUID();
    private final UUID projectId = UUID.randomUUID();

    @Test
    @DisplayName("GET /tasks 应返回任务列表")
    void shouldListTasks() {
        when(authentication.getName()).thenReturn(userId.toString());
        DashboardDtos.Task task = new DashboardDtos.Task(
                "task-1", "CHANGES_REQUESTED", targetId, "实验标题",
                projectId, "项目名", Instant.now(), null, "继续修改", false);
        when(service.tasks(userId)).thenReturn(List.of(task));

        ApiResponse<List<DashboardDtos.Task>> result = controller.tasks(authentication);

        assertNotNull(result);
        assertEquals(1, result.getData().size());
        assertEquals("CHANGES_REQUESTED", result.getData().get(0).type());
        assertEquals("实验标题", result.getData().get(0).title());
        assertEquals("项目名", result.getData().get(0).projectName());
    }

    @Test
    @DisplayName("GET /tasks 空列表应返回空数组")
    void shouldListEmptyTasks() {
        when(authentication.getName()).thenReturn(userId.toString());
        when(service.tasks(userId)).thenReturn(List.of());

        ApiResponse<List<DashboardDtos.Task>> result = controller.tasks(authentication);

        assertNotNull(result);
        assertTrue(result.getData().isEmpty());
    }

    @Test
    @DisplayName("GET /summary 应返回汇总数据")
    void shouldGetSummary() {
        when(authentication.getName()).thenReturn(userId.toString());
        DashboardDtos.Summary summary = new DashboardDtos.Summary(5L, 3L, 1L, 2L, 0L, 4L);
        when(service.summary(userId)).thenReturn(summary);

        ApiResponse<DashboardDtos.Summary> result = controller.summary(authentication);

        assertNotNull(result);
        assertEquals(5L, result.getData().projectCount());
        assertEquals(3L, result.getData().editableRecordCount());
        assertEquals(2L, result.getData().pendingReviewCount());
        assertEquals(4L, result.getData().unreadNotificationCount());
    }

    @Test
    @DisplayName("GET /summary 全零汇总应返回零值")
    void shouldGetZeroSummary() {
        when(authentication.getName()).thenReturn(userId.toString());
        DashboardDtos.Summary summary = new DashboardDtos.Summary(0L, 0L, 0L, 0L, 0L, 0L);
        when(service.summary(userId)).thenReturn(summary);

        ApiResponse<DashboardDtos.Summary> result = controller.summary(authentication);

        assertNotNull(result);
        assertEquals(0L, result.getData().projectCount());
        assertEquals(0L, result.getData().editableRecordCount());
    }

    @Test
    @DisplayName("未认证请求应返回错误")
    void shouldRejectUnauthenticated() {
        when(authentication.getName()).thenReturn("not-a-valid-uuid");
        assertThrows(IllegalArgumentException.class, () ->
                controller.tasks(authentication));
    }
}
