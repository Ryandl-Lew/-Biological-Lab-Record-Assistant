import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import TemplatesMvpPage from '@/pages/TemplatesMvpPage';

const mockTemplateFields = [
  {
    fieldKey: 'field1',
    label: 'Sample Name',
    fieldType: 'SINGLE_LINE_TEXT',
    required: true,
    placeholder: 'Enter sample name',
    options: [],
  },
  {
    fieldKey: 'field2',
    label: 'Concentration',
    fieldType: 'NUMBER',
    required: false,
    placeholder: null,
    options: [],
  },
  {
    fieldKey: 'field3',
    label: 'Category',
    fieldType: 'SELECT',
    required: false,
    placeholder: null,
    options: ['A', 'B', 'C'],
  },
];

const mockTemplates = [
  {
    id: 'tpl-1',
    name: 'PCR Template',
    description: 'Standard PCR experiment template',
    scope: 'SYSTEM',
    experimentType: '分子生物学',
    fields: mockTemplateFields,
    canEdit: false,
    canDelete: false,
  },
  {
    id: 'tpl-2',
    name: 'Western Blot',
    description: '',
    scope: 'PERSONAL',
    experimentType: '蛋白实验',
    fields: [mockTemplateFields[0]],
    canEdit: true,
    canDelete: true,
  },
  {
    id: 'tpl-3',
    name: 'ELISA',
    description: 'ELISA assay template',
    scope: 'PERSONAL',
    experimentType: '免疫实验',
    fields: mockTemplateFields,
    canEdit: true,
    canDelete: false,
  },
];

const mockFetchTemplates = vi.fn();
const mockCopyTemplate = vi.fn();
const mockCreateTemplate = vi.fn();
const mockDeleteTemplate = vi.fn();
const mockUpdateTemplate = vi.fn();

vi.mock('@/api', () => ({
  fetchTemplates: (...args) => mockFetchTemplates(...args),
  copyTemplate: (...args) => mockCopyTemplate(...args),
  createTemplate: (...args) => mockCreateTemplate(...args),
  deleteTemplate: (...args) => mockDeleteTemplate(...args),
  updateTemplate: (...args) => mockUpdateTemplate(...args),
}));

vi.mock('@/domain', () => ({
  TEMPLATE_FIELD_TYPE_LABELS: {
    SINGLE_LINE_TEXT: '单行文本',
    MULTI_LINE_TEXT: '多行文本',
    NUMBER: '数字',
    DATE: '日期',
    SELECT: '单选/下拉',
    FILE: '文件',
  },
}));

vi.mock('@/components/template/TemplateEditorDialog', () => ({
  default: ({ template, onClose, onSave }) => (
    <div data-testid="template-editor" data-template-id={template?.id || 'new'}>
      <button data-testid="editor-close" onClick={onClose}>Close</button>
      <button data-testid="editor-save" onClick={() => onSave({ name: 'New Template' })}>Save</button>
    </div>
  ),
}));

vi.mock('lucide-react', () => ({
  Copy: () => <span data-testid="icon-copy">CopyIcon</span>,
  Eye: () => <span data-testid="icon-eye">EyeIcon</span>,
  Plus: () => <span data-testid="icon-plus">PlusIcon</span>,
  Trash2: () => <span data-testid="icon-trash">TrashIcon</span>,
}));

vi.mock('@/components/ui', () => ({
  Badge: ({ children, tone }) => (
    <span data-testid="badge" data-tone={tone}>{children}</span>
  ),
  Button: ({ children, onClick, icon: Icon, size, variant, className }) => (
    <button onClick={onClick} data-testid={`btn-${children}`} data-variant={variant}>
      {Icon && <Icon />}
      {children}
    </button>
  ),
  EmptyState: ({ title }) => <div data-testid="empty-state">{title}</div>,
  PageHeader: ({ eyebrow, title, description, actions }) => (
    <header>
      <p>{eyebrow}</p>
      <h1>{title}</h1>
      {description && <p>{description}</p>}
      {actions && <div data-testid="header-actions">{actions}</div>}
    </header>
  ),
  Surface: ({ children, title, extra, className }) => (
    <div data-testid="surface" className={className}>
      {title && <h2 data-testid="surface-title">{title}</h2>}
      {extra && <div data-testid="surface-extra">{extra}</div>}
      {children}
    </div>
  ),
  Tabs: ({ items, activeKey, onChange }) => (
    <div data-testid="tabs">
      {items.map((item) => (
        <button
          key={item.key}
          data-testid={`tab-${item.key || 'all'}`}
          data-active={activeKey === item.key}
          onClick={() => onChange(item.key)}
        >
          {item.label}
        </button>
      ))}
    </div>
  ),
}));

describe('TemplatesMvpPage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockFetchTemplates.mockResolvedValue({ items: mockTemplates });
    mockCopyTemplate.mockResolvedValue({});
    mockDeleteTemplate.mockResolvedValue({});
    mockCreateTemplate.mockResolvedValue({ id: 'new-tpl' });
    mockUpdateTemplate.mockResolvedValue({});
  });

  function renderPage(initialRoute = '/templates') {
    return render(
      <MemoryRouter initialEntries={[initialRoute]}>
        <TemplatesMvpPage />
      </MemoryRouter>,
    );
  }

  it('should display the page header correctly', async () => {
    renderPage();
    expect(screen.getByText('模板中心')).toBeInTheDocument();
    expect(screen.getByText('实验模板')).toBeInTheDocument();
  });

  it('should load templates on mount and render them', async () => {
    renderPage();
    await waitFor(() => {
      expect(mockFetchTemplates).toHaveBeenCalledWith({ scope: '', page: 0, size: 100 });
    });
    expect(screen.getByText('PCR Template')).toBeInTheDocument();
    expect(screen.getByText('Western Blot')).toBeInTheDocument();
    expect(screen.getByText('ELISA')).toBeInTheDocument();
  });

  it('should display template descriptions or fallback text', async () => {
    renderPage();
    await waitFor(() => {
      expect(screen.getByText('Standard PCR experiment template')).toBeInTheDocument();
      expect(screen.getByText('暂无说明')).toBeInTheDocument();
    });
  });

  it('should show field count and experiment type for each template', async () => {
    renderPage();
    await waitFor(() => {
      expect(screen.getByText('3 个字段 · 分子生物学')).toBeInTheDocument();
      expect(screen.getByText('1 个字段 · 蛋白实验')).toBeInTheDocument();
      expect(screen.getByText('3 个字段 · 免疫实验')).toBeInTheDocument();
    });
  });

  it('should show scope badge (系统 / 个人) for each template', async () => {
    renderPage();
    await waitFor(() => {
      expect(screen.getByText('系统')).toBeInTheDocument();
      expect(screen.getAllByText('个人')).toHaveLength(2);
    });
  });

  it('should render Copy button on each template and call copyTemplate', async () => {
    renderPage();
    await waitFor(() => {
      expect(screen.getAllByTestId('btn-复制')).toHaveLength(3);
    });
    fireEvent.click(screen.getAllByTestId('btn-复制')[0]);
    await waitFor(() => {
      expect(mockCopyTemplate).toHaveBeenCalledWith('tpl-1');
    });
  });

  it('should not show Edit/Delete buttons for SYSTEM template', async () => {
    renderPage();
    await waitFor(() => {
      const pcrCard = screen.getByText('PCR Template').closest('article');
      expect(pcrCard.querySelector('[data-testid="btn-编辑"]')).toBeNull();
      expect(pcrCard.querySelector('[data-testid="btn-删除"]')).toBeNull();
    });
  });

  it('should show Edit/Delete buttons for PERSONAL template with canEdit/canDelete', async () => {
    renderPage();
    await waitFor(() => {
      const editButtons = screen.getAllByTestId('btn-编辑');
      expect(editButtons.length).toBe(2);
      const deleteButtons = screen.getAllByTestId('btn-删除');
      expect(deleteButtons.length).toBe(1);
    });
  });

  it('should show editor dialog when clicking Edit on first editable template', async () => {
    renderPage();
    await waitFor(() => {
      expect(screen.getAllByTestId('btn-编辑')).toHaveLength(2);
    });
    fireEvent.click(screen.getAllByTestId('btn-编辑')[0]);
    expect(screen.getByTestId('template-editor')).toBeInTheDocument();
    expect(screen.getByTestId('template-editor')).toHaveAttribute('data-template-id', 'tpl-2');
  });

  it('should show editor dialog for new template when clicking 新建模板', async () => {
    renderPage();
    await waitFor(() => {
      expect(screen.getByTestId('btn-新建模板')).toBeInTheDocument();
    });
    fireEvent.click(screen.getByTestId('btn-新建模板'));
    expect(screen.getByTestId('template-editor')).toBeInTheDocument();
    expect(screen.getByTestId('template-editor')).toHaveAttribute('data-template-id', 'new');
  });

  it('should call createTemplate when saving a new template', async () => {
    renderPage();
    await waitFor(() => {
      expect(screen.getByTestId('btn-新建模板')).toBeInTheDocument();
    });
    fireEvent.click(screen.getByTestId('btn-新建模板'));
    fireEvent.click(screen.getByTestId('editor-save'));
    await waitFor(() => {
      expect(mockCreateTemplate).toHaveBeenCalledWith({ name: 'New Template' });
    });
  });

  it('should show error message when fetchTemplates fails', async () => {
    mockFetchTemplates.mockRejectedValueOnce(new Error('Network Error'));
    renderPage();
    await waitFor(() => {
      expect(screen.getByText('Network Error')).toBeInTheDocument();
    });
  });

  it('should show empty state when no templates', async () => {
    mockFetchTemplates.mockResolvedValueOnce({ items: [] });
    renderPage();
    await waitFor(() => {
      expect(screen.getByTestId('empty-state')).toBeInTheDocument();
      expect(screen.getByText('暂无模板')).toBeInTheDocument();
    });
  });

  it('should filter templates by scope when tab changes', async () => {
    renderPage();
    await waitFor(() => {
      expect(screen.getByTestId('tab-SYSTEM')).toBeInTheDocument();
    });
    mockFetchTemplates.mockClear();
    mockFetchTemplates.mockResolvedValue({ items: [mockTemplates[0]] });
    fireEvent.click(screen.getByTestId('tab-SYSTEM'));
    await waitFor(() => {
      expect(mockFetchTemplates).toHaveBeenCalledWith(
        expect.objectContaining({ scope: 'SYSTEM' }),
      );
    });
  });

  it('should show preview dialog when clicking "查看"', async () => {
    renderPage();
    await waitFor(() => {
      expect(screen.getAllByTestId('btn-查看')).toHaveLength(3);
    });
    fireEvent.click(screen.getAllByTestId('btn-查看')[0]);
    await waitFor(() => {
      expect(screen.getByText('Sample Name')).toBeInTheDocument();
      expect(screen.getByText('Concentration')).toBeInTheDocument();
    });
  });

  it('should show required indicator (*) for required fields in preview', async () => {
    renderPage();
    await waitFor(() => {
      fireEvent.click(screen.getAllByTestId('btn-查看')[0]);
    });
    await waitFor(() => {
      const sampleLabel = screen.getByText('Sample Name');
      expect(sampleLabel.parentElement?.textContent).toContain('*');
    });
  });

  it('should show field type badges in preview', async () => {
    renderPage();
    await waitFor(() => {
      fireEvent.click(screen.getAllByTestId('btn-查看')[0]);
    });
    await waitFor(() => {
      expect(screen.getByText('单行文本')).toBeInTheDocument();
      expect(screen.getByText('数字')).toBeInTheDocument();
    });
  });

  it('should show options text for SELECT fields in preview', async () => {
    renderPage();
    await waitFor(() => {
      fireEvent.click(screen.getAllByTestId('btn-查看')[0]);
    });
    await waitFor(() => {
      expect(screen.getByText('选项：A、B、C')).toBeInTheDocument();
    });
  });
});
