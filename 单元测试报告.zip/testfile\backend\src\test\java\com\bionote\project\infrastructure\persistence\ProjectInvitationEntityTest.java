package com.bionote.project.infrastructure.persistence;

import org.junit.jupiter.api.Test;
import java.time.Instant;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class ProjectInvitationEntityTest {

    @Test
    void shouldCreateInvitationEntity() {
        UUID id = UUID.randomUUID();
        UUID projectId = UUID.randomUUID();
        UUID inviterId = UUID.randomUUID();
        UUID inviteeId = UUID.randomUUID();
        Instant now = Instant.now();
        Instant expires = now.plusSeconds(86400);

        ProjectInvitationEntity entity = new ProjectInvitationEntity(
                id, projectId, inviterId, inviteeId,
                "user@test.com", "PENDING", expires, now, null, projectId + ":" + inviteeId);

        assertEquals(id, entity.id);
        assertEquals(projectId, entity.projectId);
        assertEquals(inviterId, entity.inviterId);
        assertEquals(inviteeId, entity.inviteeUserId);
        assertEquals("user@test.com", entity.inviteeEmailSnapshot);
        assertEquals("PENDING", entity.status);
        assertEquals(expires, entity.expiresAt);
        assertEquals(now, entity.createdAt);
        assertNull(entity.respondedAt);
    }

    @Test
    void shouldCreateAcceptedInvitation() {
        UUID id = UUID.randomUUID();
        Instant now = Instant.now();
        ProjectInvitationEntity entity = new ProjectInvitationEntity(
                id, UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID(),
                "user@test.com", "ACCEPTED", now.plusSeconds(86400), now, now, null);

        assertEquals("ACCEPTED", entity.status);
        assertEquals(now, entity.respondedAt);
        assertNull(entity.pendingKey);
    }

    @Test
    void shouldHaveProtectedDefaultConstructor() throws Exception {
        var ctor = ProjectInvitationEntity.class.getDeclaredConstructor();
        ctor.setAccessible(true);
        ProjectInvitationEntity entity = ctor.newInstance();
        assertNull(entity.id);
    }
}
