import { describe, it, expect, vi } from 'vitest';

const expectedExports = [
  'DashboardPage',
  'ProjectsPage',
  'ProjectDetailPage',
  'AgentPage',
  'RecordsPage',
  'RecordCreatePage',
  'RecordEditorPage',
  'RecordDetailPage',
  'TemplatesPage',
  'SearchPage',
  'ProfilePage',
  'NotFoundPage',
  'LoginPage',
  'RegisterPage',
];

vi.mock('@/pages/DashboardMvpPage', () => ({ default: 'DashboardMock' }));
vi.mock('@/pages/ProjectsPage', () => ({ default: 'ProjectsMock' }));
vi.mock('@/pages/ProjectDetailMvpPage', () => ({ default: 'ProjectDetailMock' }));
vi.mock('@/pages/AgentMvpPage', () => ({ default: 'AgentMock' }));
vi.mock('@/pages/RecordsMvpPage', () => ({ default: 'RecordsMock' }));
vi.mock('@/pages/RecordCreateMvpPage', () => ({ default: 'RecordCreateMock' }));
vi.mock('@/pages/RecordEditorMvpPage', () => ({ default: 'RecordEditorMock' }));
vi.mock('@/pages/RecordDetailMvpPage', () => ({ default: 'RecordDetailMock' }));
vi.mock('@/pages/TemplatesMvpPage', () => ({ default: 'TemplatesMock' }));
vi.mock('@/pages/SearchMvpPage', () => ({ default: 'SearchMock' }));
vi.mock('@/pages/ProfilePage', () => ({ default: 'ProfileMock' }));
vi.mock('@/pages/NotFoundPage', () => ({ default: 'NotFoundMock' }));
vi.mock('@/pages/LoginPage', () => ({ default: 'LoginMock' }));
vi.mock('@/pages/RegisterPage', () => ({ default: 'RegisterMock' }));

describe('pages index', () => {
  it('should export all 14 named page components', async () => {
    const module = await import('@/pages/index.js');
    for (const name of expectedExports) {
      expect(module).toHaveProperty(name);
    }
    expect(Object.keys(module)).toHaveLength(expectedExports.length);
  });

  it('should map DashboardMvpPage to DashboardPage', async () => {
    const module = await import('@/pages/index.js');
    expect(module.DashboardPage).toBe('DashboardMock');
  });

  it('should map AgentMvpPage to AgentPage', async () => {
    const module = await import('@/pages/index.js');
    expect(module.AgentPage).toBe('AgentMock');
  });

  it('should map TemplatesMvpPage to TemplatesPage', async () => {
    const module = await import('@/pages/index.js');
    expect(module.TemplatesPage).toBe('TemplatesMock');
  });

  it('should map LoginPage and RegisterPage correctly', async () => {
    const module = await import('@/pages/index.js');
    expect(module.LoginPage).toBe('LoginMock');
    expect(module.RegisterPage).toBe('RegisterMock');
  });
});
