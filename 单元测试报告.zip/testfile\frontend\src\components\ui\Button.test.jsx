import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import { Search } from 'lucide-react';
import Button from '@/components/ui/Button';

describe('Button', () => {
  const renderWithRouter = (ui) => render(<MemoryRouter>{ui}</MemoryRouter>);

  it('renders children', () => {
    render(<Button>点击我</Button>);
    expect(screen.getByRole('button', { name: '点击我' })).toBeInTheDocument();
  });

  it('calls onClick when clicked', () => {
    const onClick = vi.fn();
    render(<Button onClick={onClick}>按钮</Button>);
    fireEvent.click(screen.getByRole('button'));
    expect(onClick).toHaveBeenCalledTimes(1);
  });

  it('renders as a disabled button when disabled', () => {
    render(<Button disabled>禁用</Button>);
    expect(screen.getByRole('button')).toBeDisabled();
  });

  it('renders as a Link when to prop is provided', () => {
    renderWithRouter(<Button to="/projects">前往项目</Button>);
    expect(screen.getByRole('link')).toHaveAttribute('href', '/projects');
  });

  it('renders an icon when icon prop is provided', () => {
    render(<Button icon={Search}>搜索</Button>);
    expect(screen.getByRole('button').querySelector('svg')).toBeTruthy();
  });

  it('shows loading spinner when loading is true', () => {
    render(<Button loading>加载中</Button>);
    const button = screen.getByRole('button');
    expect(button).toBeDisabled();
    expect(button.querySelector('.animate-spin')).toBeTruthy();
  });

  it('applies danger variant styles', () => {
    render(<Button variant="danger">删除</Button>);
    const button = screen.getByRole('button');
    expect(button.className).toContain('text-red-600');
  });
});
