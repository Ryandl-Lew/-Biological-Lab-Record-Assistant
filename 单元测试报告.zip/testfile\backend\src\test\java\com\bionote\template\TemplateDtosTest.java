package com.bionote.template;

import org.junit.jupiter.api.Test;
import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class TemplateDtosTest {

    @Test
    void fieldRequest_shouldHoldValidationConstraints() {
        TemplateDtos.FieldRequest field = new TemplateDtos.FieldRequest(
                "temperature", "温度", "NUMBER", true, "请输入温度", null, List.of()
        );

        assertEquals("temperature", field.fieldKey());
        assertEquals("温度", field.label());
        assertEquals("NUMBER", field.fieldType());
        assertTrue(field.required());
        assertEquals("请输入温度", field.placeholder());
        assertNull(field.defaultValue());
        assertTrue(field.options().isEmpty());
    }

    @Test
    void saveRequest_shouldHoldFieldsAndVersion() {
        TemplateDtos.FieldRequest field = new TemplateDtos.FieldRequest(
                "pH", "酸碱度", "SINGLE_LINE_TEXT", false, "请输入pH值", "7.0", List.of()
        );
        TemplateDtos.SaveRequest request = new TemplateDtos.SaveRequest(
                "实验模板A", "化学", "酸碱实验",
                "用于酸碱中和实验的记录模板", List.of(field), 3L
        );

        assertEquals("实验模板A", request.name());
        assertEquals("化学", request.experimentType());
        assertEquals("酸碱实验", request.category());
        assertEquals("用于酸碱中和实验的记录模板", request.description());
        assertEquals(1, request.fields().size());
        assertEquals(3L, request.version());
    }

    @Test
    void fieldView_shouldHoldAllProperties() {
        UUID id = UUID.randomUUID();
        TemplateDtos.FieldView view = new TemplateDtos.FieldView(
                id, "volume", "体积", "NUMBER", true, 0,
                "请输入体积(ml)", 100.0, List.of("10", "20", "50")
        );

        assertEquals(id, view.id());
        assertEquals("volume", view.fieldKey());
        assertEquals("体积", view.label());
        assertEquals("NUMBER", view.fieldType());
        assertTrue(view.required());
        assertEquals(0, view.sortOrder());
        assertEquals("请输入体积(ml)", view.placeholder());
        assertEquals(100.0, view.defaultValue());
        assertEquals(List.of("10", "20", "50"), view.options());
    }

    @Test
    void view_shouldContainTemplateWithPermissions() {
        UUID id = UUID.randomUUID();
        UUID ownerId = UUID.randomUUID();
        Instant now = Instant.now();
        TemplateDtos.FieldView field = new TemplateDtos.FieldView(
                UUID.randomUUID(), "temp", "温度", "NUMBER", false, 0,
                null, null, List.of()
        );
        TemplateDtos.View view = new TemplateDtos.View(
                id, "PERSONAL", ownerId, "我的模板", "化学", "实验",
                "描述", now, now, 1L, List.of(field), true, true
        );

        assertEquals(id, view.id());
        assertEquals("PERSONAL", view.scope());
        assertEquals(ownerId, view.ownerId());
        assertEquals("我的模板", view.name());
        assertEquals(1, view.fields().size());
        assertTrue(view.canEdit());
        assertTrue(view.canDelete());
        assertEquals(1L, view.version());
    }

    @Test
    void view_systemTemplate_cannotEdit() {
        TemplateDtos.View view = new TemplateDtos.View(
                UUID.randomUUID(), "SYSTEM", UUID.randomUUID(), "系统模板", "通用", "分类",
                "描述", Instant.now(), Instant.now(), 0L, List.of(), false, false
        );

        assertFalse(view.canEdit());
        assertFalse(view.canDelete());
        assertEquals("SYSTEM", view.scope());
    }

    @Test
    void fieldRequest_selectType_shouldHaveOptions() {
        TemplateDtos.FieldRequest field = new TemplateDtos.FieldRequest(
                "method", "实验方法", "SELECT", true, "请选择", "滴定法", List.of("滴定法", "光谱法", "称重法")
        );

        assertEquals("SELECT", field.fieldType());
        assertEquals(3, field.options().size());
        assertTrue(field.options().contains("光谱法"));
    }
}
