package com.bionote.audit;

import com.bionote.common.ApiException;
import com.bionote.common.PagedResponse;
import com.bionote.project.ProjectMemberStore;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("AuditService 测试")
class AuditServiceTest {

    @Mock private AuditQueryStore queries;
    @Mock private AuditJsonCodec json;
    @Mock private ProjectMemberStore members;

    @InjectMocks
    private AuditService service;

    private final UUID userId = UUID.randomUUID();
    private final UUID projectId = UUID.randomUUID();

    @Test
    @DisplayName("list 应返回分页事件列表")
    void shouldListAuditEvents() {
        AuditQueryStore.EventRecord record = new AuditQueryStore.EventRecord(
                UUID.randomUUID(), "RECORD_CREATED", "RECORD", UUID.randomUUID(),
                null, userId, "张三", "{}", Instant.now());
        AuditQueryStore.EventPage page = new AuditQueryStore.EventPage(List.of(record), 1L);

        when(members.exists(projectId, userId)).thenReturn(true);
        when(json.decode("{}")).thenReturn(java.util.Map.of());
        when(queries.findEvents(eq(projectId), isNull(), isNull(), isNull(), isNull(), eq(0), eq(20)))
                .thenReturn(page);

        PagedResponse<AuditDtos.View> result = service.list(userId, projectId, null, null, null, null, 0, 20);

        assertNotNull(result);
        assertEquals(1, result.data().size());
        assertEquals("RECORD_CREATED", result.data().get(0).eventType());
    }

    @Test
    @DisplayName("非项目成员 list 应抛异常")
    void shouldThrowWhenNotMember() {
        when(members.exists(projectId, userId)).thenReturn(false);

        ApiException ex = assertThrows(ApiException.class,
                () -> service.list(userId, projectId, null, null, null, null, 0, 20));
        assertEquals("RESOURCE_NOT_FOUND", ex.code());
    }

    @Test
    @DisplayName("不支持的事件类型应抛异常")
    void shouldThrowForInvalidEventType() {
        when(members.exists(projectId, userId)).thenReturn(true);

        ApiException ex = assertThrows(ApiException.class,
                () -> service.list(userId, projectId, "INVALID_TYPE", null, null, null, 0, 20));
        assertEquals("VALIDATION_ERROR", ex.code());
    }

    @Test
    @DisplayName("attachments 应返回分页附件摘要")
    void shouldListAttachments() {
        AuditQueryStore.AttachmentRecord ar = new AuditQueryStore.AttachmentRecord(
                UUID.randomUUID(), "test.pdf", "application/pdf", 1024L,
                UUID.randomUUID(), "Title", "RC-001", "张三", Instant.now());
        AuditQueryStore.AttachmentPage page = new AuditQueryStore.AttachmentPage(List.of(ar), 1L);

        when(members.exists(projectId, userId)).thenReturn(true);
        when(queries.findAttachments(projectId, 0, 20)).thenReturn(page);

        PagedResponse<AuditDtos.AttachmentSummary> result = service.attachments(userId, projectId, 0, 20);

        assertNotNull(result);
        assertEquals(1, result.data().size());
        assertEquals("test.pdf", result.data().get(0).filename());
    }

    @Test
    @DisplayName("metadata 中不安全的 key 应被过滤")
    void shouldFilterUnsafeMetadataKeys() {
        AuditQueryStore.EventRecord record = new AuditQueryStore.EventRecord(
                UUID.randomUUID(), "RECORD_CREATED", "RECORD", UUID.randomUUID(),
                null, userId, "张三", "{\"name\":\"safe\",\"password\":\"secret\",\"code\":\"001\"}", Instant.now());
        AuditQueryStore.EventPage page = new AuditQueryStore.EventPage(List.of(record), 1L);
        java.util.Map<String, Object> rawMap = new java.util.LinkedHashMap<>();
        rawMap.put("name", "safe");
        rawMap.put("password", "secret");
        rawMap.put("code", "001");

        when(members.exists(projectId, userId)).thenReturn(true);
        when(json.decode("{\"name\":\"safe\",\"password\":\"secret\",\"code\":\"001\"}")).thenReturn(rawMap);
        when(queries.findEvents(eq(projectId), isNull(), isNull(), isNull(), isNull(), eq(0), eq(20)))
                .thenReturn(page);

        PagedResponse<AuditDtos.View> result = service.list(userId, projectId, null, null, null, null, 0, 20);

        Map<String, Object> metadata = result.data().get(0).metadata();
        assertTrue(metadata.containsKey("name"));
        assertTrue(metadata.containsKey("code"));
        assertFalse(metadata.containsKey("password"));
    }

    @Test
    @DisplayName("空事件列表应返回空数据")
    void shouldReturnEmptyListForNoEvents() {
        AuditQueryStore.EventPage page = new AuditQueryStore.EventPage(List.of(), 0L);

        when(members.exists(projectId, userId)).thenReturn(true);
        when(queries.findEvents(eq(projectId), isNull(), isNull(), isNull(), isNull(), eq(0), eq(20)))
                .thenReturn(page);

        PagedResponse<AuditDtos.View> result = service.list(userId, projectId, null, null, null, null, 0, 20);

        assertNotNull(result);
        assertTrue(result.data().isEmpty());
        assertEquals(0L, result.meta().totalElements());
    }
}
