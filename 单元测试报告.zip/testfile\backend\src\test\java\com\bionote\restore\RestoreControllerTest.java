package com.bionote.restore;

import com.bionote.common.ApiException;
import com.bionote.common.PagedResponse;
import com.bionote.revision.RevisionDtos;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("RestoreController - 恢复接口测试")
class RestoreControllerTest {

    @Mock private RestorePreviewUseCase previews;
    @Mock private RestoreExecutionUseCase executions;
    @Mock private RestoreHistoryUseCase operations;
    @Mock private Authentication authentication;

    @InjectMocks private RestoreController controller;

    private final UUID userId = UUID.randomUUID();
    private final UUID recordId = UUID.randomUUID();

    @Nested
    @DisplayName("POST /api/v1/records/{recordId}/restore-preview")
    class PreviewTests {

        @Test
        @DisplayName("预览成功应返回 200")
        void shouldPreviewSuccessfully() {
            when(authentication.getName()).thenReturn(userId.toString());
            var request = new RestoreDtos.PreviewRequest(UUID.randomUUID(), 1L, true);
            var sourceRev = new RestoreDtos.SourceRevision(UUID.randomUUID(), 1);
            var summary = new RevisionDtos.DiffSummary(0, 0, 0, 5, 0, 0);
            var diffResult = new RevisionDtos.DiffResult(recordId, null, null, summary, List.of(), false, List.of(), Instant.now());
            var plan = new RestoreDtos.AttachmentPlan(List.of(), List.of(), List.of(), Map.of(), List.of());
            var preview = new RestoreDtos.Preview(recordId, sourceRev, 1L, "token", Instant.now().plusSeconds(300),
                    diffResult, plan, List.of(), Map.of("canExecute", true));
            when(previews.preview(userId, recordId, request)).thenReturn(preview);

            var result = controller.preview(authentication, recordId, request);

            assertNotNull(result);
            assertEquals("token", result.getData().previewToken());
            assertEquals(true, result.getData().capabilities().get("canExecute"));
        }

        @Test
        @DisplayName("未认证应返回错误")
        void shouldReturnUnauthorizedForAnonymous() {
            when(authentication.getName()).thenReturn("not-a-valid-uuid");
            var request = new RestoreDtos.PreviewRequest(UUID.randomUUID(), 1L, true);
            assertThrows(IllegalArgumentException.class, () ->
                    controller.preview(authentication, recordId, request));
        }
    }

    @Nested
    @DisplayName("POST /api/v1/records/{recordId}/restore")
    class RestoreTests {

        @Test
        @DisplayName("恢复成功应返回 200")
        void shouldRestoreSuccessfully() {
            when(authentication.getName()).thenReturn(userId.toString());
            var request = new RestoreDtos.ExecuteRequest(UUID.randomUUID(), 1L, true, "token");
            var diffSummary = new RevisionDtos.DiffSummary(1, 1, 3, 5, 0, 0);
            var op = new RestoreDtos.OperationSummary(UUID.randomUUID(), recordId, UUID.randomUUID(), 1,
                    userId, "Alice", 1L, 2L, "h1", "h2", diffSummary, Instant.now());
            var restoreResult = new RestoreDtos.Result(null, op);
            when(executions.restore(userId, recordId, request, "key-123")).thenReturn(restoreResult);

            var result = controller.restore(authentication, recordId, request, "key-123");

            assertNotNull(result);
            assertEquals(1, result.getData().operation().sourceRevisionNo());
        }

        @Test
        @DisplayName("缺少 Idempotency-Key 头部")
        void shouldHandleMissingIdempotencyKey() {
            when(authentication.getName()).thenReturn(userId.toString());
            var request = new RestoreDtos.ExecuteRequest(UUID.randomUUID(), 1L, true, "token");
            var ex = new ApiException(HttpStatus.BAD_REQUEST, "VALIDATION_ERROR", "缺少 Idempotency-Key");
            when(executions.restore(userId, recordId, request, null)).thenThrow(ex);

            assertThrows(ApiException.class, () ->
                    controller.restore(authentication, recordId, request, null));
        }
    }

    @Nested
    @DisplayName("GET /api/v1/records/{recordId}/restore-operations")
    class HistoryTests {

        @Test
        @DisplayName("分页查询成功应返回分页数据")
        void shouldReturnHistoryPage() {
            when(authentication.getName()).thenReturn(userId.toString());
            var page = PagedResponse.of(List.of(), 0, 20, 0L);
            when(operations.list(userId, recordId, 0, 20)).thenReturn(page);

            var result = controller.history(authentication, recordId, 0, 20);

            assertNotNull(result);
            assertEquals(0, result.meta().page());
            assertEquals(20, result.meta().size());
        }

        @Test
        @DisplayName("支持自定义分页参数")
        void shouldSupportCustomPagination() {
            when(authentication.getName()).thenReturn(userId.toString());
            var page = PagedResponse.of(List.of(), 1, 10, 0L);
            when(operations.list(userId, recordId, 1, 10)).thenReturn(page);

            var result = controller.history(authentication, recordId, 1, 10);

            assertNotNull(result);
        }

        @Test
        @DisplayName("未认证应返回错误")
        void shouldReturnUnauthorizedForAnonymousHistory() {
            when(authentication.getName()).thenReturn("not-a-valid-uuid");
            assertThrows(IllegalArgumentException.class, () ->
                    controller.history(authentication, recordId, 0, 20));
        }
    }
}
