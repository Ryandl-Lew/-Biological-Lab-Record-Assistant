package com.bionote.audit;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

@SpringBootTest
@ActiveProfiles("test")
@DisplayName("Audit 集成测试")
class AuditIntegrationTest {

    @Autowired
    private WebApplicationContext context;

    @Test
    @DisplayName("Spring 上下文应成功加载")
    void shouldLoadApplicationContext() {
        assertNotNull(context);
    }

    @Test
    @DisplayName("未认证请求审计事件应被拒绝")
    void shouldRejectUnauthenticatedAuditEvents() throws Exception {
        MockMvc mockMvc = MockMvcBuilders.webAppContextSetup(context).build();

        var result = mockMvc.perform(get("/api/v1/projects/{projectId}/audit-events", UUID.randomUUID()))
                .andReturn();

        int status = result.getResponse().getStatus();
        assertTrue(status == 401 || status == 403 || status == 302,
                "Expected 401, 403 or 302 but got " + status);
    }

    @Test
    @DisplayName("AuditController Bean 应存在于上下文中")
    void shouldHaveAuditControllerBean() {
        assertDoesNotThrow(() -> context.getBean(AuditController.class));
    }
}
