package com.bionote.dashboard;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("DashboardService 测试")
class DashboardServiceTest {

    @Mock
    private DashboardQueryStore queries;

    @InjectMocks
    private DashboardService service;

    private final UUID userId = UUID.randomUUID();

    @Test
    @DisplayName("tasks 应委托给 DashboardQueryStore 并返回任务列表")
    void shouldDelegateTasksToQueryStore() {
        DashboardDtos.Task task = new DashboardDtos.Task(
                "task-1", "CHANGES_REQUESTED", UUID.randomUUID(), "标题",
                UUID.randomUUID(), "项目", Instant.now(), null, "操作", false);
        when(queries.tasks(userId)).thenReturn(List.of(task));

        List<DashboardDtos.Task> result = service.tasks(userId);

        assertEquals(1, result.size());
        assertEquals("CHANGES_REQUESTED", result.get(0).type());
        assertEquals("标题", result.get(0).title());
        verify(queries).tasks(userId);
    }

    @Test
    @DisplayName("tasks 空结果应返回空列表")
    void shouldReturnEmptyTaskList() {
        when(queries.tasks(userId)).thenReturn(List.of());

        List<DashboardDtos.Task> result = service.tasks(userId);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    @DisplayName("summary 应委托给 DashboardQueryStore 并返回汇总数据")
    void shouldDelegateSummaryToQueryStore() {
        DashboardDtos.Summary expected = new DashboardDtos.Summary(3L, 2L, 1L, 0L, 0L, 5L);
        when(queries.summary(userId)).thenReturn(expected);

        DashboardDtos.Summary result = service.summary(userId);

        assertEquals(3L, result.projectCount());
        assertEquals(2L, result.editableRecordCount());
        assertEquals(1L, result.changesRequestedCount());
        assertEquals(0L, result.pendingReviewCount());
        assertEquals(0L, result.pendingInvitationCount());
        assertEquals(5L, result.unreadNotificationCount());
        verify(queries).summary(userId);
    }

    @Test
    @DisplayName("summary 全零值应正确返回")
    void shouldReturnZeroSummary() {
        DashboardDtos.Summary expected = new DashboardDtos.Summary(0L, 0L, 0L, 0L, 0L, 0L);
        when(queries.summary(userId)).thenReturn(expected);

        DashboardDtos.Summary result = service.summary(userId);

        assertEquals(0L, result.projectCount());
        assertEquals(0L, result.unreadNotificationCount());
    }
}
