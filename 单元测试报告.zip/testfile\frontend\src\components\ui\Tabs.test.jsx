import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import Tabs from '@/components/ui/Tabs';

describe('Tabs', () => {
  const items = [
    { key: 'all', label: '全部' },
    { key: 'recent', label: '最近' },
    { key: 'archived', label: '已归档' },
  ];

  it('renders all tab items', () => {
    render(<Tabs items={items} activeKey="all" onChange={vi.fn()} />);
    expect(screen.getByRole('button', { name: '全部' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '最近' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: '已归档' })).toBeInTheDocument();
  });

  it('highlights active tab', () => {
    render(<Tabs items={items} activeKey="recent" onChange={vi.fn()} />);
    const activeBtn = screen.getByRole('button', { name: '最近' });
    expect(activeBtn.className).toContain('bg-white');
  });

  it('calls onChange with correct key when clicked', () => {
    const onChange = vi.fn();
    render(<Tabs items={items} activeKey="all" onChange={onChange} />);
    fireEvent.click(screen.getByRole('button', { name: '已归档' }));
    expect(onChange).toHaveBeenCalledWith('archived');
  });

  it('inactive tabs have muted styling', () => {
    render(<Tabs items={items} activeKey="all" onChange={vi.fn()} />);
    const inactiveBtn = screen.getByRole('button', { name: '最近' });
    expect(inactiveBtn.className).toContain('text-slate-500');
  });
});
