import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('./client', () => ({ request: vi.fn() }))

import { request } from './client'
import { search, fetchDashboardTasks, fetchDashboardSummary } from './assist'

describe('assist API', () => {
  beforeEach(() => {
    request.mockReset()
  })

  describe('search', () => {
    it('sends GET /search with no params', async () => {
      request.mockResolvedValueOnce({ results: [] })
      await search()
      expect(request).toHaveBeenCalledWith('/search')
    })

    it('sends GET /search with query params', async () => {
      request.mockResolvedValueOnce({ results: [] })
      await search({ keyword: '实验', entityType: 'RECORD' })
      expect(request).toHaveBeenCalledWith('/search?keyword=%E5%AE%9E%E9%AA%8C&entityType=RECORD')
    })

    it('filters out null/undefined/empty string params', async () => {
      request.mockResolvedValueOnce({ results: [] })
      await search({ keyword: 'test', page: undefined, empty: '', extra: null })
      expect(request).toHaveBeenCalledWith('/search?keyword=test')
    })
  })

  describe('fetchDashboardTasks', () => {
    it('sends GET /dashboard/tasks', async () => {
      request.mockResolvedValueOnce([])
      await fetchDashboardTasks()
      expect(request).toHaveBeenCalledWith('/dashboard/tasks')
    })
  })

  describe('fetchDashboardSummary', () => {
    it('sends GET /dashboard/summary', async () => {
      request.mockResolvedValueOnce({ projects: 5, records: 20 })
      await fetchDashboardSummary()
      expect(request).toHaveBeenCalledWith('/dashboard/summary')
    })
  })
})
