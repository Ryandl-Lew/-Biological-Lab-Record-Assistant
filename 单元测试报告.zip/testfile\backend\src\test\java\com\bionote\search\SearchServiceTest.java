package com.bionote.search;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class SearchServiceTest {

    @Mock
    private SearchQueryStore queries;

    @InjectMocks
    private SearchService service;

    private static final UUID USER_ID = UUID.randomUUID();

    @Test
    void search_shouldReturnResults() {
        SearchDtos.Result result = new SearchDtos.Result(
                "RECORD", "r-1", "Record Title", "snippet",
                UUID.randomUUID(), "Project", "DRAFT", java.time.Instant.now(),
                Map.of("type", "RECORD", "id", "r-1")
        );
        SearchDtos.Meta meta = new SearchDtos.Meta(0, 20, 1, Map.of("RECORD", 1L));
        SearchDtos.Response expected = new SearchDtos.Response(List.of(result), meta);

        when(queries.search(USER_ID, "keyword", "ALL", null, null, null, 0, 20))
                .thenReturn(expected);

        SearchDtos.Response response = service.search(USER_ID, "keyword", "ALL", null, null, null, 0, 20);

        assertNotNull(response);
        assertEquals(1, response.data().size());
        assertEquals("Record Title", response.data().get(0).title());
        assertEquals(1, response.meta().total());
    }

    @Test
    void search_shouldReturnEmptyResults() {
        SearchDtos.Response expected = new SearchDtos.Response(
                List.of(), new SearchDtos.Meta(0, 20, 0, Map.of())
        );

        when(queries.search(USER_ID, "nonexistent", "ALL", null, null, null, 0, 20))
                .thenReturn(expected);

        SearchDtos.Response response = service.search(USER_ID, "nonexistent", "ALL", null, null, null, 0, 20);

        assertNotNull(response);
        assertTrue(response.data().isEmpty());
        assertEquals(0, response.meta().total());
    }

    @Test
    void search_shouldFilterByProjectId() {
        UUID projectId = UUID.randomUUID();
        SearchDtos.Response expected = new SearchDtos.Response(
                List.of(), new SearchDtos.Meta(0, 20, 0, Map.of())
        );

        when(queries.search(USER_ID, "test", "RECORD", projectId, null, null, 0, 20))
                .thenReturn(expected);

        SearchDtos.Response response = service.search(USER_ID, "test", "RECORD", projectId, null, null, 0, 20);

        assertNotNull(response);
        verify(queries).search(USER_ID, "test", "RECORD", projectId, null, null, 0, 20);
    }

    @Test
    void search_shouldFilterByCreatorId() {
        UUID creatorId = UUID.randomUUID();
        SearchDtos.Response expected = new SearchDtos.Response(
                List.of(), new SearchDtos.Meta(0, 20, 0, Map.of())
        );

        when(queries.search(USER_ID, "", "RECORD", null, creatorId, null, 0, 20))
                .thenReturn(expected);

        SearchDtos.Response response = service.search(USER_ID, "", "RECORD", null, creatorId, null, 0, 20);

        assertNotNull(response);
        verify(queries).search(USER_ID, "", "RECORD", null, creatorId, null, 0, 20);
    }

    @Test
    void search_shouldFilterByStatus() {
        SearchDtos.Response expected = new SearchDtos.Response(
                List.of(), new SearchDtos.Meta(0, 20, 0, Map.of())
        );

        when(queries.search(USER_ID, "chem", "RECORD", null, null, "COMPLETED", 0, 20))
                .thenReturn(expected);

        SearchDtos.Response response = service.search(USER_ID, "chem", "RECORD", null, null, "COMPLETED", 0, 20);

        assertNotNull(response);
        verify(queries).search(USER_ID, "chem", "RECORD", null, null, "COMPLETED", 0, 20);
    }
}
