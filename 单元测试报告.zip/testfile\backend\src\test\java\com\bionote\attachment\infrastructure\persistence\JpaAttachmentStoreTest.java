package com.bionote.attachment.infrastructure.persistence;

import com.bionote.attachment.AttachmentStore;
import com.bionote.revision.RevisionAttachmentAppender;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@Import(JpaAttachmentStore.class)
@TestPropertySource(properties = {"spring.flyway.enabled=false", "spring.jpa.hibernate.ddl-auto=update"})
@DisplayName("JpaAttachmentStore 持久化测试")
class JpaAttachmentStoreTest {

    @Autowired
    private AttachmentJpaRepository attachmentRepo;

    @Autowired
    private RevisionAttachmentJpaRepository revisionAttachmentRepo;

    @Autowired
    private JpaAttachmentStore store;

    private final UUID recordId = UUID.randomUUID();
    private final UUID uploaderId = UUID.randomUUID();

    @Test
    @DisplayName("insert 应成功插入并可通过 findById 查询")
    void shouldInsertAndFindById() {
        UUID id = UUID.randomUUID();
        Instant now = Instant.now();
        AttachmentStore.AttachmentRecord record = new AttachmentStore.AttachmentRecord(
                id, recordId, uploaderId, "test.pdf", "sk-1", "application/pdf",
                1024L, true, now, null);

        store.insert(record);

        var found = store.findById(id, false);
        assertTrue(found.isPresent());
        assertEquals("test.pdf", found.get().originalFilename());
        assertEquals("sk-1", found.get().storageKey());
    }

    @Test
    @DisplayName("softDelete 应标记删除时间")
    void shouldSoftDeleteAttachment() {
        UUID id = UUID.randomUUID();
        Instant now = Instant.now();
        store.insert(new AttachmentStore.AttachmentRecord(id, recordId, uploaderId, "f.txt",
                "sk-2", "text/plain", 100L, false, now, null));

        Instant deleteTime = Instant.now();
        boolean result = store.softDelete(id, deleteTime);

        assertTrue(result);
        var found = store.findById(id, true);
        assertTrue(found.isPresent());
        assertNotNull(found.get().deletedAt());
    }

    @Test
    @DisplayName("reactivate 应恢复已删除的附件")
    void shouldReactivateDeletedAttachment() {
        UUID id = UUID.randomUUID();
        Instant now = Instant.now();
        store.insert(new AttachmentStore.AttachmentRecord(id, recordId, uploaderId, "f.txt",
                "sk-3", "text/plain", 100L, false, now, null));
        store.softDelete(id, Instant.now());

        boolean success = store.reactivate(id);
        assertTrue(success);
        var found = store.findById(id, false);
        assertTrue(found.isPresent());
        assertNull(found.get().deletedAt());
    }

    @Test
    @DisplayName("findActiveByRecord 应只返回未删除的附件")
    void shouldFindActiveByRecord() {
        UUID id1 = UUID.randomUUID();
        UUID id2 = UUID.randomUUID();
        Instant now = Instant.now();
        store.insert(new AttachmentStore.AttachmentRecord(id1, recordId, uploaderId, "a.pdf",
                "sk-a", "application/pdf", 100L, true, now, null));
        store.insert(new AttachmentStore.AttachmentRecord(id2, recordId, uploaderId, "b.pdf",
                "sk-b", "application/pdf", 200L, true, now, null));
        store.softDelete(id2, Instant.now());

        List<AttachmentStore.AttachmentRecord> active = store.findActiveByRecord(recordId);

        assertEquals(1, active.size());
        assertEquals("a.pdf", active.get(0).originalFilename());
    }

    @Test
    @DisplayName("existsActive 应正确判断附件是否存在且未删除")
    void shouldCheckExistsActive() {
        UUID id = UUID.randomUUID();
        store.insert(new AttachmentStore.AttachmentRecord(id, recordId, uploaderId, "f.txt",
                "sk-check", "text/plain", 100L, false, Instant.now(), null));

        assertTrue(store.existsActive(id, recordId));
    }

    @Test
    @DisplayName("append 应添加修订附件关联")
    void shouldAppendRevisionAttachments() {
        UUID attachmentId = UUID.randomUUID();
        UUID revisionId = UUID.randomUUID();
        store.insert(new AttachmentStore.AttachmentRecord(attachmentId, recordId, uploaderId,
                "rev.pdf", "sk-rev", "application/pdf", 100L, true, Instant.now(), null));

        store.append(revisionId, List.of(attachmentId));

        List<RevisionAttachmentEntity> result = revisionAttachmentRepo.findByIdRevisionIdOrderBySortOrderAsc(revisionId);
        assertEquals(1, result.size());
        assertEquals(attachmentId, result.get(0).id.attachmentId);
    }

    @Test
    @DisplayName("storageKeysByRecord 应返回存储键列表")
    void shouldGetStorageKeysByRecord() {
        UUID id = UUID.randomUUID();
        store.insert(new AttachmentStore.AttachmentRecord(id, UUID.randomUUID(), uploaderId,
                "f.txt", "unique-sk", "text/plain", 100L, false, Instant.now(), null));

        List<String> keys = store.storageKeysByRecord(id);
        assertNotNull(keys);
    }
}
