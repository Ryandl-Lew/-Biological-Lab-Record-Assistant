package com.bionote.search;

import org.junit.jupiter.api.Test;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class SearchDtosTest {

    @Test
    void result_shouldHoldAllFields() {
        UUID projectId = UUID.randomUUID();
        Instant now = Instant.now();
        Map<String, Object> target = Map.of("type", "RECORD", "id", UUID.randomUUID().toString());

        SearchDtos.Result result = new SearchDtos.Result(
                "RECORD", "rec-1", "Experiment Title", "This is a snippet...",
                projectId, "Project Alpha", "DRAFT", now, target
        );

        assertEquals("RECORD", result.entityType());
        assertEquals("rec-1", result.id());
        assertEquals("Experiment Title", result.title());
        assertEquals("This is a snippet...", result.snippet());
        assertEquals(projectId, result.projectId());
        assertEquals("Project Alpha", result.projectName());
        assertEquals("DRAFT", result.status());
        assertEquals(now, result.updatedAt());
        assertEquals(target, result.target());
    }

    @Test
    void result_shouldHandleNullFields() {
        SearchDtos.Result result = new SearchDtos.Result(
                "TEMPLATE", "tmpl-1", "Template Name", null,
                null, null, "SYSTEM", null,
                Map.of("type", "TEMPLATE", "id", "tmpl-1")
        );

        assertNull(result.snippet());
        assertNull(result.projectId());
        assertNull(result.projectName());
        assertNull(result.updatedAt());
    }

    @Test
    void meta_shouldHoldCounts() {
        Map<String, Long> counts = Map.of("PROJECT", 2L, "RECORD", 5L, "TEMPLATE", 1L);

        SearchDtos.Meta meta = new SearchDtos.Meta(0, 20, 8, counts);

        assertEquals(0, meta.page());
        assertEquals(20, meta.size());
        assertEquals(8, meta.total());
        assertEquals(3, meta.counts().size());
        assertEquals(5L, meta.counts().get("RECORD"));
    }

    @Test
    void response_shouldHoldDataAndMeta() {
        List<SearchDtos.Result> data = List.of(
                new SearchDtos.Result("PROJECT", "p-1", "Project 1", "snippet",
                        UUID.randomUUID(), "P1", "ACTIVE", Instant.now(),
                        Map.of("type", "PROJECT", "id", "p-1"))
        );
        SearchDtos.Meta meta = new SearchDtos.Meta(0, 20, 1, Map.of("PROJECT", 1L));

        SearchDtos.Response response = new SearchDtos.Response(data, meta);

        assertEquals(1, response.data().size());
        assertEquals(meta, response.meta());
        assertEquals("Project 1", response.data().get(0).title());
    }

    @Test
    void response_shouldHandleEmptyData() {
        List<SearchDtos.Result> data = List.of();
        SearchDtos.Meta meta = new SearchDtos.Meta(0, 20, 0, Map.of());

        SearchDtos.Response response = new SearchDtos.Response(data, meta);

        assertTrue(response.data().isEmpty());
        assertEquals(0, response.meta().total());
    }
}
