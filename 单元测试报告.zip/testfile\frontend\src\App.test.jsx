import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';

const mockRestoreSession = vi.fn();
const mockClearSession = vi.fn();

vi.mock('@/store/authStore', () => ({
  useAuthStore: vi.fn((selector) => {
    const state = {
      restoreSession: mockRestoreSession,
      clearSession: mockClearSession,
    };
    return selector(state);
  }),
}));

vi.mock('@/router', () => ({
  router: {
    routes: [],
    state: { location: { pathname: '/' } },
    navigate: vi.fn(),
    subscribe: vi.fn(() => vi.fn()),
  },
}));

vi.mock('react-router-dom', () => ({
  RouterProvider: ({ router }) => (
    <div data-testid="router-provider">
      <span data-testid="router">RouterProvider Active</span>
    </div>
  ),
}));

import App from '@/App';

describe('App', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockRestoreSession.mockResolvedValue(undefined);
    mockClearSession.mockImplementation(() => {});
  });

  function renderApp() {
    return render(<App />);
  }

  it('should render RouterProvider', () => {
    renderApp();
    expect(screen.getByTestId('router-provider')).toBeInTheDocument();
    expect(screen.getByTestId('router')).toBeInTheDocument();
  });

  it('should call restoreSession on mount', async () => {
    renderApp();
    await waitFor(() => {
      expect(mockRestoreSession).toHaveBeenCalled();
    });
  });

  it('should register "bionote:unauthorized" event listener', async () => {
    const addEventListenerSpy = vi.spyOn(window, 'addEventListener');
    renderApp();
    await waitFor(() => {
      expect(addEventListenerSpy).toHaveBeenCalledWith(
        'bionote:unauthorized',
        expect.any(Function),
      );
    });
    addEventListenerSpy.mockRestore();
  });

  it('should call clearSession when unauthorized event is dispatched', async () => {
    let capturedHandler;
    const originalAdd = window.addEventListener;
    window.addEventListener = vi.fn((event, handler) => {
      capturedHandler = handler;
    });
    const originalRemove = window.removeEventListener;
    window.removeEventListener = vi.fn();

    renderApp();

    await waitFor(() => {
      expect(capturedHandler).toBeDefined();
    });

    capturedHandler();
    expect(mockClearSession).toHaveBeenCalled();

    window.addEventListener = originalAdd;
    window.removeEventListener = originalRemove;
  });

  it('should clean up event listener on unmount', () => {
    const removeEventListenerSpy = vi.spyOn(window, 'removeEventListener');
    const { unmount } = renderApp();
    unmount();
    expect(removeEventListenerSpy).toHaveBeenCalledWith(
      'bionote:unauthorized',
      expect.any(Function),
    );
    removeEventListenerSpy.mockRestore();
  });
});
