import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import RecordTree from '@/components/record/RecordTree';

vi.mock('@/components/ui/StatusBadge', () => ({
  default: ({ kind, status }) => <span data-testid="status-badge">{kind}:{status}</span>,
}));

describe('RecordTree', () => {
  const projects = [
    { id: 'p1', name: '项目A' },
    { id: 'p2', name: '项目B' },
  ];

  const records = [
    { id: 'r1', projectId: 'p1', title: '记录1', code: 'R001', status: 'draft' },
    { id: 'r2', projectId: 'p1', title: '记录2', code: 'R002', status: 'submitted' },
    { id: 'r3', projectId: 'p2', title: '记录3', code: 'R003', status: 'draft' },
  ];

  it('renders project names', () => {
    render(<RecordTree projects={projects} records={records} selectedId="" onSelect={vi.fn()} />);
    expect(screen.getByText('项目A')).toBeInTheDocument();
    expect(screen.getByText('项目B')).toBeInTheDocument();
  });

  it('shows record count per project', () => {
    render(<RecordTree projects={projects} records={records} selectedId="" onSelect={vi.fn()} />);
    // Project A has 2 records, Project B has 1
    const counts = screen.getAllByText('2');
    expect(counts.length).toBeGreaterThanOrEqual(1);
  });

  it('renders record names when expanded', () => {
    render(<RecordTree projects={projects} records={records} selectedId="" onSelect={vi.fn()} />);
    expect(screen.getByText('记录1')).toBeInTheDocument();
    expect(screen.getByText('记录2')).toBeInTheDocument();
    expect(screen.getByText('记录3')).toBeInTheDocument();
  });

  it('shows empty message when project has no records', () => {
    render(
      <RecordTree
        projects={[{ id: 'p3', name: '空项目' }]}
        records={[]}
        selectedId=""
        onSelect={vi.fn()}
      />
    );
    expect(screen.getByText('暂无匹配记录')).toBeInTheDocument();
  });
});
