package com.bionote.common;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.http.HttpStatus;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("ApiException 测试")
class ApiExceptionTest {

    @Test
    @DisplayName("三参数构造器应正确设置 status、code、message")
    void shouldConstructWithThreeArgs() {
        ApiException ex = new ApiException(HttpStatus.NOT_FOUND, "NOT_FOUND", "资源未找到");

        assertEquals(HttpStatus.NOT_FOUND, ex.status());
        assertEquals("NOT_FOUND", ex.code());
        assertEquals("资源未找到", ex.getMessage());
        assertTrue(ex.fieldErrors().isEmpty());
    }

    @Test
    @DisplayName("四参数构造器（含 fieldErrors）应正确设置所有字段")
    void shouldConstructWithFieldErrors() {
        Map<String, String> fields = Map.of("name", "不能为空", "age", "必须为正数");
        ApiException ex = new ApiException(HttpStatus.BAD_REQUEST, "VALIDATION_ERROR", "校验失败", fields);

        assertEquals(HttpStatus.BAD_REQUEST, ex.status());
        assertEquals("VALIDATION_ERROR", ex.code());
        assertEquals("校验失败", ex.getMessage());
        assertEquals(2, ex.fieldErrors().size());
        assertEquals("不能为空", ex.fieldErrors().get("name"));
    }

    @Test
    @DisplayName("fieldErrors 为 null 时应初始化为空 Map")
    void shouldInitEmptyMapWhenFieldErrorsNull() {
        ApiException ex = new ApiException(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL_ERROR", "错误", null);

        assertNotNull(ex.fieldErrors());
        assertTrue(ex.fieldErrors().isEmpty());
    }

    @Test
    @DisplayName("应继承 RuntimeException")
    void shouldExtendRuntimeException() {
        ApiException ex = new ApiException(HttpStatus.BAD_REQUEST, "ERR", "msg");

        assertInstanceOf(RuntimeException.class, ex);
    }

    @Test
    @DisplayName("try-catch 应能正确捕获")
    void shouldBeCatchableAsRuntimeException() {
        try {
            throw new ApiException(HttpStatus.CONFLICT, "DUPLICATE", "重复资源");
        } catch (ApiException ex) {
            assertEquals(HttpStatus.CONFLICT, ex.status());
            assertEquals("DUPLICATE", ex.code());
        }
    }
}
