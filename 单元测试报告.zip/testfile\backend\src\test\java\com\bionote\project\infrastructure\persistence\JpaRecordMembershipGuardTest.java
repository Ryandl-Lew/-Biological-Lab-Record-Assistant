package com.bionote.project.infrastructure.persistence;

import com.bionote.project.RecordMembershipGuard;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JpaRecordMembershipGuardTest {

    @Mock private JpaProjectPersistenceAdapter persistence;

    private JpaRecordMembershipGuard guard;
    private final UUID projectId = UUID.randomUUID();
    private final UUID userId = UUID.randomUUID();

    @BeforeEach
    void setUp() {
        guard = new JpaRecordMembershipGuard(persistence);
    }

    @Test
    void shouldReturnBlockingItemsForArchive() {
        ProjectRecordReadEntity entity = new ProjectRecordReadEntity();
        entity.id = UUID.randomUUID();
        entity.title = "未完成记录";
        entity.status = "IN_PROGRESS";

        when(persistence.blockingArchive(projectId)).thenReturn(List.of(entity));

        List<RecordMembershipGuard.BlockingItem> result = guard.recordsBlockingArchive(projectId);

        assertEquals(1, result.size());
        assertEquals("未完成记录", result.get(0).title());
        assertEquals("IN_PROGRESS", result.get(0).status());
    }

    @Test
    void shouldReturnEmptyListWhenNoBlockingItems() {
        when(persistence.blockingArchive(projectId)).thenReturn(List.of());

        List<RecordMembershipGuard.BlockingItem> result = guard.recordsBlockingArchive(projectId);

        assertTrue(result.isEmpty());
    }

    @Test
    void shouldReturnBlockingItemsForMemberChange() {
        ProjectRecordReadEntity entity = new ProjectRecordReadEntity();
        entity.id = UUID.randomUUID();
        entity.title = "审核中的记录";
        entity.status = "IN_REVIEW";

        when(persistence.blockingMember(projectId, userId)).thenReturn(List.of(entity));

        List<RecordMembershipGuard.BlockingItem> result = guard.recordsBlockingMemberChange(projectId, userId);

        assertEquals(1, result.size());
        assertEquals("审核中的记录", result.get(0).title());
    }

    @Test
    void shouldReturnEmptyForMemberChangeWithNoBlocking() {
        when(persistence.blockingMember(projectId, userId)).thenReturn(List.of());

        List<RecordMembershipGuard.BlockingItem> result = guard.recordsBlockingMemberChange(projectId, userId);

        assertTrue(result.isEmpty());
    }
}
