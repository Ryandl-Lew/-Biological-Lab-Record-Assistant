import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import AgentArtifactView from '@/components/agent/AgentArtifactView';

vi.mock('@/components/ui', () => ({
  Badge: ({ children }) => <span data-testid="badge">{children}</span>,
  Surface: ({ title, children, extra }) => (
    <section>
      <h2>{title}</h2>
      {extra && <div data-testid="extra">{extra}</div>}
      {children}
    </section>
  ),
  EmptyState: ({ title, description }) => (
    <div>
      <h3>{title}</h3>
      <p>{description}</p>
    </div>
  ),
}));

vi.mock('@/components/agent/EvidenceLink', () => ({
  default: ({ evidence }) => <span data-testid="evidence">{evidence.label}</span>,
}));

describe('AgentArtifactView', () => {
  it('renders empty state when no artifact', () => {
    render(<AgentArtifactView artifact={null} run={null} onEvidence={vi.fn()} />);
    expect(screen.getByText('尚无已验证报告')).toBeInTheDocument();
  });

  it('renders artifact headline and summary', () => {
    const artifact = {
      id: 'a1',
      artifactKind: 'RECORD_SUMMARY',
      createdAt: '2025-06-01T10:00:00Z',
      content: {
        headline: '实验总结报告',
        executiveSummary: '这是一份摘要内容',
        period: { start: '2025-01', end: '2025-06' },
        progress: [],
        risks: [],
        nextActions: [],
        limitations: [],
        evidence: [],
      },
    };
    render(<AgentArtifactView artifact={artifact} run={null} onEvidence={vi.fn()} />);
    expect(screen.getByText('实验总结报告')).toBeInTheDocument();
    expect(screen.getByText('这是一份摘要内容')).toBeInTheDocument();
  });

  it('renders badge with artifact kind', () => {
    const artifact = {
      id: 'a1',
      artifactKind: 'RECORD_SUMMARY',
      createdAt: '2025-06-01T10:00:00Z',
      content: {
        headline: '报告',
        executiveSummary: '摘要',
        period: { start: '2025-01', end: '2025-06' },
        progress: [],
        risks: [],
        nextActions: [],
        limitations: [],
        evidence: [],
      },
    };
    render(<AgentArtifactView artifact={artifact} run={null} onEvidence={vi.fn()} />);
    const badges = screen.getAllByTestId('badge');
    const kindBadge = badges.find((b) => b.textContent === 'RECORD_SUMMARY');
    expect(kindBadge).toBeTruthy();
  });

  it('renders model info in badge when run is provided', () => {
    const artifact = {
      id: 'a1',
      artifactKind: 'RECORD_SUMMARY',
      createdAt: '2025-06-01T10:00:00Z',
      content: {
        headline: '报告',
        executiveSummary: '摘要',
        period: { start: '2025-01', end: '2025-06' },
        progress: [],
        risks: [],
        nextActions: [],
        limitations: [],
        evidence: [],
      },
    };
    const run = { provider: 'openai', model: 'gpt-4' };
    render(<AgentArtifactView artifact={artifact} run={run} onEvidence={vi.fn()} />);
    const badges = screen.getAllByTestId('badge');
    const modelBadge = badges.find((b) => b.textContent.includes('gpt-4'));
    expect(modelBadge).toBeTruthy();
  });

  it('renders limitations section', () => {
    const artifact = {
      id: 'a1',
      artifactKind: 'RECORD_SUMMARY',
      createdAt: '2025-06-01T10:00:00Z',
      content: {
        headline: '报告',
        executiveSummary: '摘要',
        period: { start: '2025-01', end: '2025-06' },
        progress: [],
        risks: [],
        nextActions: [],
        limitations: ['数据不完整', '样本量有限'],
        evidence: [],
      },
    };
    render(<AgentArtifactView artifact={artifact} run={null} onEvidence={vi.fn()} />);
    expect(screen.getByText('数据不完整')).toBeInTheDocument();
    expect(screen.getByText('样本量有限')).toBeInTheDocument();
  });
});
