package com.bionote.export.infrastructure.persistence;

import com.bionote.common.ApiException;
import com.bionote.export.ExportReportStore;
import com.bionote.export.RecordReportModel;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.*;
import java.sql.Timestamp;
import java.time.Instant;
import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JdbcExportReportAdapterTest {

    @Mock
    private JdbcTemplate jdbc;

    @Mock
    private ObjectMapper json;

    @InjectMocks
    private JdbcExportReportAdapter adapter;

    private static final UUID USER_ID = UUID.randomUUID();
    private static final UUID RECORD_ID = UUID.randomUUID();
    private static final UUID PROJECT_ID = UUID.randomUUID();
    private static final UUID REVISION_ID = UUID.randomUUID();

    @Test
    void loadCompleted_shouldThrowWhenNoAccess() {
        when(jdbc.queryForList(anyString(), eq(Map.class), any()))
                .thenReturn(List.of());

        ApiException ex = assertThrows(ApiException.class, () ->
                adapter.loadCompleted(USER_ID, RECORD_ID));

        assertEquals("RESOURCE_NOT_FOUND", ex.code());
        assertEquals(org.springframework.http.HttpStatus.NOT_FOUND, ex.status());
    }

    @Test
    void loadCompleted_shouldThrowWhenStatusNotCompleted() {
        Map<String, Object> accessRow = new HashMap<>();
        accessRow.put("status", "DRAFT");
        when(jdbc.queryForList(anyString(), eq(Map.class), any()))
                .thenReturn(List.of(accessRow));

        ApiException ex = assertThrows(ApiException.class, () ->
                adapter.loadCompleted(USER_ID, RECORD_ID));

        assertEquals("EXPORT_NOT_AVAILABLE", ex.code());
        assertEquals(org.springframework.http.HttpStatus.CONFLICT, ex.status());
    }

    @Test
    void loadCompleted_shouldThrowWhenAccessReturnsEmpty() {
        when(jdbc.queryForList(eq("SELECT r.status FROM experiment_records r JOIN project_members pm ON pm.project_id=r.project_id AND pm.user_id=? WHERE r.id=? AND r.deleted_at IS NULL"), eq(Map.class), any()))
                .thenReturn(List.of());

        ApiException ex = assertThrows(ApiException.class, () ->
                adapter.loadCompleted(USER_ID, RECORD_ID));
        assertEquals("RESOURCE_NOT_FOUND", ex.code());
    }

    @Test
    void loadCompleted_shouldThrowWhenSnapshotDecodingFails() throws Exception {
        Map<String, Object> accessRow = new HashMap<>();
        accessRow.put("status", "COMPLETED");
        when(jdbc.queryForList(eq("SELECT r.status FROM experiment_records r JOIN project_members pm ON pm.project_id=r.project_id AND pm.user_id=? WHERE r.id=? AND r.deleted_at IS NULL"), eq(Map.class), any()))
                .thenReturn(List.of(accessRow));

        Map<String, Object> detailRow = new HashMap<>();
        detailRow.put("project_id", PROJECT_ID.toString());
        detailRow.put("project_name", "TestProject");
        detailRow.put("creator_name", "Creator");
        detailRow.put("revision_no", 1);
        detailRow.put("reviewer_name", "Reviewer");
        detailRow.put("decided_at", Timestamp.from(Instant.now()));
        detailRow.put("decision_comment", "Approved");
        detailRow.put("final_revision_id", REVISION_ID.toString());
        detailRow.put("snapshot_json", "{\"bad json");

        when(jdbc.queryForList(contains("SELECT r.*"), eq(Map.class), any()))
                .thenReturn(List.of(detailRow));

        ApiException ex = assertThrows(ApiException.class, () ->
                adapter.loadCompleted(USER_ID, RECORD_ID));
        assertEquals("INVALID_REVISION_SNAPSHOT", ex.code());
    }

    @Test
    void loadCompleted_shouldReturnLoadedReportWhenAccessible() throws Exception {
        Map<String, Object> accessRow = new HashMap<>();
        accessRow.put("status", "COMPLETED");
        when(jdbc.queryForList(eq("SELECT r.status FROM experiment_records r JOIN project_members pm ON pm.project_id=r.project_id AND pm.user_id=? WHERE r.id=? AND r.deleted_at IS NULL"), eq(Map.class), any()))
                .thenReturn(List.of(accessRow));

        String snapshotJson = "{\"title\":\"Test\",\"code\":\"EXP-1\",\"experimentType\":\"Chem\",\"experimentDate\":\"2025-06-15\",\"purpose\":\"Testp\",\"contentHtml\":\"<h1>Hi</h1>\",\"contentPlainText\":\"Hi\",\"templateSnapshot\":{\"fields\":[{\"fieldKey\":\"temp\",\"label\":\"Temperature\"}]},\"fieldValues\":{\"temp\":\"25\"}}";
        Map<String, Object> detailRow = new HashMap<>();
        detailRow.put("project_id", PROJECT_ID.toString());
        detailRow.put("project_name", "TestProject");
        detailRow.put("creator_name", "Creator");
        detailRow.put("revision_no", 2);
        detailRow.put("reviewer_name", "Reviewer");
        detailRow.put("decided_at", Timestamp.from(Instant.now()));
        detailRow.put("decision_comment", null);
        detailRow.put("final_revision_id", REVISION_ID.toString());
        detailRow.put("snapshot_json", snapshotJson);

        when(jdbc.queryForList(contains("SELECT r.*"), eq(Map.class), any()))
                .thenReturn(List.of(detailRow));

        // Setup snapshot decoding
        Map<String, Object> decoded = new HashMap<>();
        decoded.put("title", "Test");
        decoded.put("code", "EXP-1");
        decoded.put("experimentType", "Chem");
        decoded.put("experimentDate", "2025-06-15");
        decoded.put("purpose", "Testp");
        decoded.put("contentHtml", "<h1>Hi</h1>");
        decoded.put("contentPlainText", "Hi");

        Map<String, Object> templateSnapshot = new HashMap<>();
        List<Map<String, Object>> fields = List.of(Map.of("fieldKey", "temp", "label", "Temperature"));
        templateSnapshot.put("fields", fields);
        decoded.put("templateSnapshot", templateSnapshot);

        Map<String, Object> fieldValues = new HashMap<>();
        fieldValues.put("temp", "25");
        decoded.put("fieldValues", fieldValues);

        when(json.readValue(eq(snapshotJson), any(com.fasterxml.jackson.core.type.TypeReference.class)))
                .thenReturn(decoded);

        // Attachments
        when(jdbc.query(anyString(), any(RowMapper.class), any()))
                .thenReturn(List.of());

        ExportReportStore.LoadedReport result = adapter.loadCompleted(USER_ID, RECORD_ID);

        assertNotNull(result);
        assertEquals(PROJECT_ID, result.projectId());
        assertNotNull(result.report());
        assertEquals(2, result.report().revisionNo());
        assertEquals("TestProject", result.report().projectName());
    }
}
