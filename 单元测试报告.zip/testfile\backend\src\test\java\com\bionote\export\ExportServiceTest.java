package com.bionote.export;

import com.bionote.collaboration.CollaborationEvents;
import com.bionote.common.ApiException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ExportServiceTest {

    @Mock
    private ExportReportStore reports;

    @Mock
    private CollaborationEvents events;

    @InjectMocks
    private ExportService service;

    private static final UUID USER_ID = UUID.randomUUID();
    private static final UUID RECORD_ID = UUID.randomUUID();
    private static final UUID PROJECT_ID = UUID.randomUUID();

    private ExportReportStore.LoadedReport createLoadedReport() {
        RecordReportModel model = new RecordReportModel(
                "Experiment Title", "EXP-001", "Project Name",
                "Chemical", LocalDate.of(2025, 1, 15),
                "Alice", "To test something",
                List.of(new RecordReportModel.Field("Temperature", "25°C")),
                "<h1>Content</h1>", "Content text",
                1, "Bob Reviewer", Instant.now(),
                "Looks good", List.of()
        );
        return new ExportReportStore.LoadedReport(PROJECT_ID, model);
    }

    @Test
    void preview_shouldReturnHtmlAndModel() {
        var loaded = createLoadedReport();
        when(reports.loadCompleted(USER_ID, RECORD_ID)).thenReturn(loaded);

        ExportDtos.Preview result = service.preview(USER_ID, RECORD_ID);

        assertNotNull(result);
        assertNotNull(result.html());
        assertTrue(result.html().contains("<!doctype html>"));
        assertTrue(result.html().contains("Experiment Title"));
        assertNotNull(result.report());
        verify(events).audit(eq(USER_ID), eq(PROJECT_ID), eq(RECORD_ID),
                eq("RECORD_EXPORT_PREVIEW"), anyString(), any(), anyMap());
    }

    @Test
    void markdown_shouldReturnMarkdownBytesAndFilename() {
        var loaded = createLoadedReport();
        when(reports.loadCompleted(USER_ID, RECORD_ID)).thenReturn(loaded);

        ExportDtos.FileExport result = service.markdown(USER_ID, RECORD_ID);

        assertNotNull(result);
        assertTrue(result.bytes().length > 0);
        String md = new String(result.bytes());
        assertTrue(md.contains("# Experiment Title"));
        assertTrue(md.contains("EXP-001"));
        assertTrue(result.filename().endsWith(".md"));
        assertTrue(result.mediaType().contains("markdown"));
        verify(events).audit(eq(USER_ID), eq(PROJECT_ID), eq(RECORD_ID),
                eq("RECORD_EXPORT_MARKDOWN"), anyString(), any(), anyMap());
    }

    @Test
    void pdf_shouldReturnPdfBytesAndFilename() {
        var loaded = createLoadedReport();
        when(reports.loadCompleted(USER_ID, RECORD_ID)).thenReturn(loaded);

        ExportDtos.FileExport result = service.pdf(USER_ID, RECORD_ID);

        assertNotNull(result);
        assertTrue(result.bytes().length > 0);
        assertEquals("application/pdf", result.mediaType());
        assertTrue(result.filename().endsWith(".pdf"));
        verify(events).audit(eq(USER_ID), eq(PROJECT_ID), eq(RECORD_ID),
                eq("RECORD_EXPORT_PDF"), anyString(), any(), anyMap());
    }

    @Test
    void preview_shouldThrowWhenLoadCompletedFails() {
        when(reports.loadCompleted(USER_ID, RECORD_ID))
                .thenThrow(new ApiException(org.springframework.http.HttpStatus.NOT_FOUND, "RESOURCE_NOT_FOUND", "记录不存在"));

        assertThrows(ApiException.class, () -> service.preview(USER_ID, RECORD_ID));
    }

    @Test
    void markdown_shouldThrowWhenLoadCompletedFails() {
        when(reports.loadCompleted(USER_ID, RECORD_ID))
                .thenThrow(new ApiException(org.springframework.http.HttpStatus.CONFLICT, "EXPORT_NOT_AVAILABLE", "只有已完成记录可以导出"));

        assertThrows(ApiException.class, () -> service.markdown(USER_ID, RECORD_ID));
    }

    @Test
    void preview_shouldHandleEmptyFieldsAndAttachments() {
        RecordReportModel model = new RecordReportModel(
                "Simple", "S-001", "Proj", "Type",
                LocalDate.now(), "Creator", "Purpose",
                List.of(), "<p>hi</p>", "hi",
                0, "Reviewer", Instant.now(), null, List.of()
        );
        when(reports.loadCompleted(USER_ID, RECORD_ID))
                .thenReturn(new ExportReportStore.LoadedReport(PROJECT_ID, model));

        ExportDtos.Preview result = service.preview(USER_ID, RECORD_ID);

        assertNotNull(result.html());
        assertTrue(result.html().contains("Simple"));
    }
}
