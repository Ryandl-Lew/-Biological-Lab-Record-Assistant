package com.bionote.restore;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 单元测试：验证 RestoreController、RestorePreviewService、RestoreExecutionService
 * 和 RestoreHistoryService 的组件协作与端到端流程。
 */
@DisplayName("RestoreIntegrationTest - 恢复集成测试")
class RestoreIntegrationTest {

    @Nested
    @DisplayName("端到端业务流程")
    class EndToEndFlow {

        @Test
        @DisplayName("DTO 序列化/反序列化应保持一致")
        void shouldMaintainDtoConsistency() {
            var revisionId = UUID.randomUUID();
            var request = new RestoreDtos.PreviewRequest(revisionId, 1L, true);
            assertEquals(revisionId, request.sourceRevisionId());
            assertEquals(1L, request.expectedRecordVersion());
            assertTrue(request.restoreAttachments());
        }

        @Test
        @DisplayName("Preview 和 ExecuteRequest 数据传递应一致")
        void shouldPassDataBetweenPreviewAndExecute() {
            var revisionId = UUID.randomUUID();
            var previewReq = new RestoreDtos.PreviewRequest(revisionId, 5L, true);
            var executeReq = new RestoreDtos.ExecuteRequest(revisionId, 5L, true, "token-abc");

            assertEquals(previewReq.sourceRevisionId(), executeReq.sourceRevisionId());
            assertEquals(previewReq.expectedRecordVersion(), executeReq.expectedRecordVersion());
            assertEquals(previewReq.restoreAttachments(), executeReq.restoreAttachments());
        }
    }

    @Nested
    @DisplayName("数据结构完整性")
    class DataStructureIntegrity {

        @Test
        @DisplayName("AttachmentPlan 的不可变性")
        void shouldHaveImmutableAttachmentPlan() {
            var ids = List.of(UUID.randomUUID());
            var plan = new RestoreDtos.AttachmentPlan(ids, List.of(), List.of(), Map.of(), List.of());

            assertEquals(1, plan.activate().size());
            assertEquals(ids.get(0), plan.activate().get(0));
        }

        @Test
        @DisplayName("OperationSummary 时间戳不应为 null")
        void shouldHaveNonNullTimestampInOperationSummary() {
            var summary = new RestoreDtos.OperationSummary(UUID.randomUUID(), UUID.randomUUID(),
                    UUID.randomUUID(), 1, UUID.randomUUID(), "user", 0L, 1L, "a", "b",
                    new com.bionote.revision.RevisionDtos.DiffSummary(0, 0, 0, 10, 0, 0),
                    java.time.Instant.now());

            assertNotNull(summary.restoredAt());
            assertTrue(summary.restoredAt().isBefore(java.time.Instant.now().plusSeconds(1)));
        }
    }

    @Nested
    @DisplayName("边界条件")
    class EdgeCases {

        @Test
        @DisplayName("空附件计划的字段应不为 null")
        void shouldHaveNonNullFieldsInEmptyPlan() {
            var plan = new RestoreDtos.AttachmentPlan(List.of(), List.of(), List.of(), Map.of(), List.of());
            assertNotNull(plan.activate());
            assertNotNull(plan.softDelete());
            assertNotNull(plan.keep());
            assertNotNull(plan.droppedFileFieldReferences());
            assertNotNull(plan.missingPhysicalFiles());
        }

        @Test
        @DisplayName("Preview capabilities 可以包含多个键")
        void shouldSupportMultipleCapabilities() {
            var capabilities = new HashMap<String, Boolean>();
            capabilities.put("canExecute", true);
            capabilities.put("canCompare", true);
            capabilities.put("canExport", false);

            assertEquals(3, capabilities.size());
            assertTrue(capabilities.get("canExecute"));
            assertFalse(capabilities.get("canExport"));
        }
    }
}
