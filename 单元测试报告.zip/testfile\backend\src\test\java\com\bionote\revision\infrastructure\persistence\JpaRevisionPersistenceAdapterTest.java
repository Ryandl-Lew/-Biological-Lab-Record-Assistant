package com.bionote.revision.infrastructure.persistence;

import com.bionote.revision.RevisionAppender;
import com.bionote.revision.RevisionLookup;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("JpaRevisionPersistenceAdapter - 修订持久化适配器测试")
class JpaRevisionPersistenceAdapterTest {

    @Mock private RecordRevisionJpaRepository revisions;
    @InjectMocks private JpaRevisionPersistenceAdapter adapter;

    private final UUID revisionId = UUID.randomUUID();
    private final UUID recordId = UUID.randomUUID();
    private final UUID userId = UUID.randomUUID();
    private final String idemKey = UUID.randomUUID().toString();

    @Nested
    @DisplayName("append - 追加修订")
    class AppendTests {

        @Test
        @DisplayName("追加成功应调用 saveAndFlush")
        void shouldSaveAndFlush() {
            var record = new RevisionAppender.RevisionRecord(revisionId, recordId, 1, "snapshot",
                    1, "hash", "note", userId, Instant.now(), idemKey);

            adapter.append(record);

            verify(revisions).saveAndFlush(any(RecordRevisionEntity.class));
        }

        @Test
        @DisplayName("追加操作应正确映射字段")
        void shouldMapAllFields() {
            var now = Instant.now();
            var record = new RevisionAppender.RevisionRecord(revisionId, recordId, 5, "{\"data\":\"value\"}",
                    1, "sha256hash", "submit note", userId, now, idemKey);

            adapter.append(record);

            verify(revisions).saveAndFlush(any(RecordRevisionEntity.class));
        }
    }

    @Nested
    @DisplayName("findById - 按 ID 查找")
    class FindByIdTests {

        @Test
        @DisplayName("找到应返回 RevisionRecord")
        void shouldReturnRevisionRecordWhenFound() {
            var entity = createEntity();
            when(revisions.findById(revisionId)).thenReturn(Optional.of(entity));

            var result = adapter.findById(revisionId);

            assertTrue(result.isPresent());
            assertEquals(revisionId, result.get().id());
            assertEquals(recordId, result.get().recordId());
        }

        @Test
        @DisplayName("未找到应返回 empty")
        void shouldReturnEmptyWhenNotFound() {
            when(revisions.findById(revisionId)).thenReturn(Optional.empty());

            var result = adapter.findById(revisionId);

            assertTrue(result.isEmpty());
        }
    }

    @Nested
    @DisplayName("findByRecordAndIdempotencyKey - 按记录和幂等键查找")
    class FindByRecordAndIdempotencyKeyTests {

        @Test
        @DisplayName("找到应返回 RevisionRecord")
        void shouldReturnWhenFound() {
            var entity = createEntity();
            when(revisions.findByRecordIdAndIdempotencyKey(recordId, idemKey)).thenReturn(Optional.of(entity));

            var result = adapter.findByRecordAndIdempotencyKey(recordId, idemKey);

            assertTrue(result.isPresent());
            assertEquals(idemKey, result.get().idempotencyKey());
        }

        @Test
        @DisplayName("未找到应返回 empty")
        void shouldReturnEmptyWhenNotFoundByKey() {
            when(revisions.findByRecordIdAndIdempotencyKey(recordId, idemKey)).thenReturn(Optional.empty());

            var result = adapter.findByRecordAndIdempotencyKey(recordId, idemKey);

            assertTrue(result.isEmpty());
        }
    }

    @Nested
    @DisplayName("findIdsByRecordOrderByRevisionNo - 按修订号排序查找")
    class FindIdsByRecordTests {

        @Test
        @DisplayName("应按修订号顺序返回 ID 列表")
        void shouldReturnIdsOrderedByRevisionNo() {
            var id1 = UUID.randomUUID();
            var id2 = UUID.randomUUID();
            var entity1 = entityWithId(id1, 1);
            var entity2 = entityWithId(id2, 2);
            when(revisions.findByRecordIdOrderByRevisionNoAsc(recordId)).thenReturn(List.of(entity1, entity2));

            var result = adapter.findIdsByRecordOrderByRevisionNo(recordId);

            assertEquals(2, result.size());
            assertEquals(id1, result.get(0));
            assertEquals(id2, result.get(1));
        }

        @Test
        @DisplayName("空结果应返回空列表")
        void shouldReturnEmptyListForNoRevisions() {
            when(revisions.findByRecordIdOrderByRevisionNoAsc(recordId)).thenReturn(List.of());

            var result = adapter.findIdsByRecordOrderByRevisionNo(recordId);

            assertTrue(result.isEmpty());
        }
    }

    private RecordRevisionEntity createEntity() {
        return new RecordRevisionEntity(revisionId, recordId, 1, "snapshot", 1, "hash",
                "note", userId, Instant.now(), idemKey);
    }

    private RecordRevisionEntity entityWithId(UUID id, int revisionNo) {
        return new RecordRevisionEntity(id, recordId, revisionNo, "{}", 1, "hash",
                "note", userId, Instant.now(), "key-" + revisionNo);
    }
}
