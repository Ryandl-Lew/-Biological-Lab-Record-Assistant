package com.bionote.project.infrastructure.persistence;

import org.junit.jupiter.api.Test;
import java.time.Instant;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class ProjectMemberEntityTest {

    @Test
    void shouldCreateProjectMemberEntity() {
        UUID projectId = UUID.randomUUID();
        UUID userId = UUID.randomUUID();
        Instant now = Instant.now();

        ProjectMemberEntity entity = new ProjectMemberEntity(projectId, userId, "OWNER", now, now);

        assertNotNull(entity.id);
        assertEquals(projectId, entity.id.projectId);
        assertEquals(userId, entity.id.userId);
        assertEquals("OWNER", entity.role);
        assertEquals(now, entity.joinedAt);
        assertEquals(now, entity.lastActiveAt);
    }

    @Test
    void shouldCreateMemberWithReviewerRole() {
        ProjectMemberEntity entity = new ProjectMemberEntity(UUID.randomUUID(), UUID.randomUUID(),
                "REVIEWER", Instant.now(), Instant.now());
        assertEquals("REVIEWER", entity.role);
    }

    @Test
    void shouldCreateMemberWithMemberRole() {
        ProjectMemberEntity entity = new ProjectMemberEntity(UUID.randomUUID(), UUID.randomUUID(),
                "MEMBER", Instant.now(), Instant.now());
        assertEquals("MEMBER", entity.role);
    }

    @Test
    void shouldHaveProtectedDefaultConstructor() throws Exception {
        var ctor = ProjectMemberEntity.class.getDeclaredConstructor();
        ctor.setAccessible(true);
        ProjectMemberEntity entity = ctor.newInstance();
        assertNull(entity.role);
    }
}
