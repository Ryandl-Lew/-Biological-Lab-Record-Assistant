package com.bionote.review;

import com.bionote.common.ApiResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.security.core.Authentication;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class ReviewControllerTest {

    @Mock private ReviewUseCase reviewUseCase;
    @Mock private Authentication authentication;

    @InjectMocks private ReviewController controller;

    private final UUID userId = UUID.randomUUID();
    private final UUID recordId = UUID.randomUUID();
    private final UUID reviewId = UUID.randomUUID();
    private final UUID revisionId = UUID.randomUUID();
    private final UUID reviewerId = UUID.randomUUID();
    private final Instant now = Instant.now();

    @Test
    void shouldGetReviewerCandidates() {
        when(authentication.getName()).thenReturn(userId.toString());
        ReviewDtos.Candidate candidate = new ReviewDtos.Candidate(reviewerId, "审核者", "REVIEWER");
        when(reviewUseCase.candidates(eq(userId), eq(recordId))).thenReturn(List.of(candidate));

        var result = controller.candidates(authentication, recordId);

        assertNotNull(result);
        assertEquals(1, result.getData().size());
        assertEquals("审核者", result.getData().get(0).displayName());
    }

    @Test
    void shouldSubmitForReview() {
        when(authentication.getName()).thenReturn(userId.toString());
        ReviewDtos.ReviewView reviewView = new ReviewDtos.ReviewView(
                reviewId, revisionId, reviewerId, "审核者", "PENDING",
                null, now, null, true);
        ReviewDtos.RevisionView revisionView = new ReviewDtos.RevisionView(
                revisionId, 1, Map.of(), "hash", "note",
                UUID.randomUUID(), "提交人", now, reviewView, List.of());
        when(reviewUseCase.submit(eq(userId), eq(recordId), any(), any())).thenReturn(revisionView);

        var request = new ReviewDtos.SubmitRequest(reviewerId, "请审核", 0L);
        var result = controller.submit(authentication, recordId, request, null);

        assertNotNull(result);
        assertEquals(1, result.getData().revisionNo());
    }

    @Test
    void shouldApproveReview() {
        when(authentication.getName()).thenReturn(userId.toString());
        ReviewDtos.ReviewView reviewView = new ReviewDtos.ReviewView(
                reviewId, revisionId, reviewerId, "审核者", "APPROVED",
                "approve", now, now, false);
        ReviewDtos.RevisionView revisionView = new ReviewDtos.RevisionView(
                revisionId, 1, Map.of(), "hash", "note",
                UUID.randomUUID(), "提交人", now, reviewView, List.of());
        when(reviewUseCase.approve(eq(userId), eq(recordId), eq(reviewId), any())).thenReturn(revisionView);

        var result = controller.approve(authentication, recordId, reviewId, new ReviewDtos.DecisionRequest("通过"));

        assertNotNull(result);
        assertEquals("APPROVED", result.getData().review().status());
    }

    @Test
    void shouldRequestChanges() {
        when(authentication.getName()).thenReturn(userId.toString());
        ReviewDtos.ReviewView reviewView = new ReviewDtos.ReviewView(
                reviewId, revisionId, reviewerId, "审核者", "CHANGES_REQUESTED",
                "需要修改", now, now, false);
        ReviewDtos.RevisionView revisionView = new ReviewDtos.RevisionView(
                revisionId, 1, Map.of(), "hash", "note",
                UUID.randomUUID(), "提交人", now, reviewView, List.of());
        when(reviewUseCase.requestChanges(eq(userId), eq(recordId), eq(reviewId), any())).thenReturn(revisionView);

        var result = controller.requestChanges(authentication, recordId, reviewId, new ReviewDtos.DecisionRequest("需要修改"));

        assertNotNull(result);
        assertEquals("CHANGES_REQUESTED", result.getData().review().status());
    }

    @Test
    void shouldGetPendingReviews() {
        when(authentication.getName()).thenReturn(userId.toString());
        when(reviewUseCase.pending(eq(userId))).thenReturn(List.of());

        var result = controller.pending(authentication);

        assertNotNull(result);
        assertTrue(result.getData().isEmpty());
    }

    @Test
    void shouldHandleApproveWithoutBody() {
        when(authentication.getName()).thenReturn(userId.toString());
        ReviewDtos.ReviewView reviewView = new ReviewDtos.ReviewView(
                reviewId, revisionId, reviewerId, "审核者", "APPROVED",
                null, now, now, false);
        ReviewDtos.RevisionView revisionView = new ReviewDtos.RevisionView(
                revisionId, 1, Map.of(), "hash", null,
                UUID.randomUUID(), "提交人", now, reviewView, List.of());
        when(reviewUseCase.approve(eq(userId), eq(recordId), eq(reviewId), isNull())).thenReturn(revisionView);

        var result = controller.approve(authentication, recordId, reviewId, null);

        assertNotNull(result);
        assertEquals("APPROVED", result.getData().review().status());
    }
}
