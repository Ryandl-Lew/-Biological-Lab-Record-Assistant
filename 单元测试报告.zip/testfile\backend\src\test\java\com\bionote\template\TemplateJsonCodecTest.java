package com.bionote.template;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.*;

class TemplateJsonCodecTest {

    @Test
    void encode_shouldReturnNullForNullInput() {
        TemplateJsonCodec codec = new TemplateJsonCodec(new com.fasterxml.jackson.databind.ObjectMapper());

        assertNull(codec.encode(null));
    }

    @Test
    void encode_shouldReturnJsonString() {
        TemplateJsonCodec codec = new TemplateJsonCodec(new com.fasterxml.jackson.databind.ObjectMapper());

        String result = codec.encode("hello");

        assertEquals("\"hello\"", result);
    }

    @Test
    void encode_shouldThrowForNonSerializable() {
        TemplateJsonCodec codec = new TemplateJsonCodec(new com.fasterxml.jackson.databind.ObjectMapper());

        // Object with circular reference
        assertThrows(IllegalArgumentException.class, () -> {
            Object circular = new Object() {
                @Override
                public String toString() { return this.toString(); }
            };
            codec.encode(circular);
        });
    }

    @Test
    void decodeValue_shouldReturnNullForNullInput() {
        TemplateJsonCodec codec = new TemplateJsonCodec(new com.fasterxml.jackson.databind.ObjectMapper());

        assertNull(codec.decodeValue(null));
    }

    @Test
    void decodeValue_shouldReturnObject() {
        TemplateJsonCodec codec = new TemplateJsonCodec(new com.fasterxml.jackson.databind.ObjectMapper());

        Object result = codec.decodeValue("42");

        assertEquals(42, result);
    }

    @Test
    void decodeValue_shouldReturnNullOnError() {
        TemplateJsonCodec codec = new TemplateJsonCodec(new com.fasterxml.jackson.databind.ObjectMapper());

        Object result = codec.decodeValue("invalid {{ json");

        assertNull(result);
    }

    @Test
    void decodeOptions_shouldReturnEmptyListForNull() {
        TemplateJsonCodec codec = new TemplateJsonCodec(new com.fasterxml.jackson.databind.ObjectMapper());

        var result = codec.decodeOptions(null);

        assertTrue(result.isEmpty());
    }

    @Test
    void decodeOptions_shouldReturnList() {
        TemplateJsonCodec codec = new TemplateJsonCodec(new com.fasterxml.jackson.databind.ObjectMapper());

        var result = codec.decodeOptions("[\"a\",\"b\",\"c\"]");

        assertEquals(3, result.size());
        assertEquals("a", result.get(0));
    }

    @Test
    void decodeOptions_shouldReturnEmptyListOnError() {
        TemplateJsonCodec codec = new TemplateJsonCodec(new com.fasterxml.jackson.databind.ObjectMapper());

        var result = codec.decodeOptions("not json");

        assertTrue(result.isEmpty());
    }
}
