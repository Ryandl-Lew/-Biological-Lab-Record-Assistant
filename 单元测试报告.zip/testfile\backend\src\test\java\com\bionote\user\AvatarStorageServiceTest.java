package com.bionote.user;

import com.bionote.common.ApiException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.springframework.http.HttpStatus;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

class AvatarStorageServiceTest {

    @TempDir Path tempDir;

    private AvatarStorageService service;

    @BeforeEach
    void setUp() throws IOException {
        service = new AvatarStorageService(tempDir.toString());
    }

    @Test
    void shouldStoreJpegImage() {
        byte[] jpegBytes = new byte[]{(byte)0xFF, (byte)0xD8, (byte)0xFF, (byte)0xE0, 0, 0, 'J', 'F', 'I', 'F', 0};
        MultipartFile file = new MockMultipartFile("file", "photo.jpg", "image/jpeg", jpegBytes);

        AvatarStorage.StoredAvatar result = service.store(file);

        assertNotNull(result);
        assertTrue(result.key().endsWith(".jpg"));
        assertEquals("image/jpeg", result.mime());
    }

    @Test
    void shouldStorePngImage() {
        byte[] pngBytes = new byte[]{(byte)0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A, 0, 0, 0};
        MultipartFile file = new MockMultipartFile("file", "icon.png", "image/png", pngBytes);

        AvatarStorage.StoredAvatar result = service.store(file);

        assertNotNull(result);
        assertTrue(result.key().endsWith(".png"));
    }

    @Test
    void shouldStoreWebpImage() {
        byte[] webpBytes = new byte[]{'R', 'I', 'F', 'F', 0, 0, 0, 0, 'W', 'E', 'B', 'P', 0, 0, 0};
        MultipartFile file = new MockMultipartFile("file", "img.webp", "image/webp", webpBytes);

        AvatarStorage.StoredAvatar result = service.store(file);

        assertNotNull(result);
        assertTrue(result.key().endsWith(".webp"));
    }

    @Test
    void shouldRejectNullFile() {
        ApiException ex = assertThrows(ApiException.class, () -> service.store(null));
        assertEquals(HttpStatus.BAD_REQUEST, ex.status());
        assertEquals("VALIDATION_ERROR", ex.code());
    }

    @Test
    void shouldRejectEmptyFile() {
        MultipartFile file = new MockMultipartFile("file", "empty.jpg", "image/jpeg", new byte[0]);
        ApiException ex = assertThrows(ApiException.class, () -> service.store(file));
        assertEquals(HttpStatus.BAD_REQUEST, ex.status());
    }

    @Test
    void shouldRejectFileTooLarge() {
        byte[] largeBytes = new byte[2 * 1024 * 1024 + 1];
        System.arraycopy(new byte[]{(byte)0xFF, (byte)0xD8, (byte)0xFF}, 0, largeBytes, 0, 3);
        MockMultipartFile file = new MockMultipartFile("file", "big.jpg", "image/jpeg", largeBytes);

        ApiException ex = assertThrows(ApiException.class, () -> service.store(file));
        assertEquals(HttpStatus.PAYLOAD_TOO_LARGE, ex.status());
    }

    @Test
    void shouldReadStoredFile() throws IOException {
        byte[] jpegBytes = new byte[]{(byte)0xFF, (byte)0xD8, (byte)0xFF, (byte)0xE0, 0, 0, 'J', 'F', 'I', 'F', 0};
        MultipartFile file = new MockMultipartFile("file", "photo.jpg", "image/jpeg", jpegBytes);
        AvatarStorage.StoredAvatar stored = service.store(file);

        byte[] read = service.read(stored.key());

        assertArrayEquals(jpegBytes, read);
    }

    @Test
    void shouldDeleteQuietly() throws IOException {
        byte[] jpegBytes = new byte[]{(byte)0xFF, (byte)0xD8, (byte)0xFF, (byte)0xE0, 0, 0, 'J', 'F', 'I', 'F', 0};
        MultipartFile file = new MockMultipartFile("file", "photo.jpg", "image/jpeg", jpegBytes);
        AvatarStorage.StoredAvatar stored = service.store(file);

        service.deleteQuietly(stored.key());

        assertThrows(IOException.class, () -> service.read(stored.key()));
    }

    @Test
    void shouldDeleteQuietlyWithNullKey() {
        assertDoesNotThrow(() -> service.deleteQuietly(null));
    }

    @Test
    void shouldRejectInvalidMagicBytes() {
        byte[] fakeBytes = new byte[]{0x00, 0x01, 0x02, 0x03, 0x04};
        MultipartFile file = new MockMultipartFile("file", "fake.jpg", "image/jpeg", fakeBytes);

        ApiException ex = assertThrows(ApiException.class, () -> service.store(file));
        assertEquals("INVALID_FILE_TYPE", ex.code());
    }
}
