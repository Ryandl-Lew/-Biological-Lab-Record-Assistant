package com.bionote.dashboard.infrastructure.persistence;

import com.bionote.dashboard.DashboardDtos;
import com.bionote.dashboard.DashboardQueryStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("JdbcDashboardQueryAdapter 测试")
class JdbcDashboardQueryAdapterTest {

    @Mock
    private JdbcTemplate jdbcTemplate;

    private JdbcDashboardQueryAdapter adapter;

    @BeforeEach
    void setUp() {
        adapter = new JdbcDashboardQueryAdapter(jdbcTemplate);
    }

    @Test
    @DisplayName("JdbcDashboardQueryAdapter 应实现 DashboardQueryStore 接口")
    void shouldImplementDashboardQueryStore() {
        assertInstanceOf(DashboardQueryStore.class, adapter);
    }

    @Test
    @DisplayName("tasks 返回空结果时应为空列表")
    void shouldReturnEmptyTaskListForNewUser() {
        UUID userId = UUID.randomUUID();
        when(jdbcTemplate.query(anyString(), any(RowMapper.class), any()))
                .thenReturn(java.util.Collections.emptyList());

        var result = adapter.tasks(userId);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    @DisplayName("summary 全零时应返回零值")
    void shouldReturnZeroSummaryForNewUser() {
        UUID userId = UUID.randomUUID();
        when(jdbcTemplate.queryForObject(anyString(), eq(Long.class), any()))
                .thenReturn(0L);

        DashboardDtos.Summary result = adapter.summary(userId);

        assertNotNull(result);
        assertEquals(0L, result.projectCount());
        assertEquals(0L, result.editableRecordCount());
        assertEquals(0L, result.changesRequestedCount());
        assertEquals(0L, result.pendingReviewCount());
        assertEquals(0L, result.pendingInvitationCount());
        assertEquals(0L, result.unreadNotificationCount());
    }

    @Test
    @DisplayName("summary 有数据时应返回正确汇总")
    void shouldReturnNonZeroSummary() {
        UUID userId = UUID.randomUUID();
        // First queryForObject returns project count (first query)
        when(jdbcTemplate.queryForObject(anyString(), eq(Long.class), any()))
                .thenReturn(5L)   // projectCount
                .thenReturn(3L)   // editableRecordCount
                .thenReturn(1L)   // changesRequestedCount
                .thenReturn(2L)   // pendingReviewCount
                .thenReturn(0L)   // pendingInvitationCount
                .thenReturn(10L); // unreadNotificationCount

        DashboardDtos.Summary result = adapter.summary(userId);

        assertNotNull(result);
        assertEquals(5L, result.projectCount());
        assertEquals(3L, result.editableRecordCount());
        assertEquals(1L, result.changesRequestedCount());
        assertEquals(2L, result.pendingReviewCount());
        assertEquals(0L, result.pendingInvitationCount());
        assertEquals(10L, result.unreadNotificationCount());
    }
}
