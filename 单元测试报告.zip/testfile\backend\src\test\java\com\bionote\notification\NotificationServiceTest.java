package com.bionote.notification;

import com.bionote.common.PagedResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificationServiceTest {

    @Mock
    private NotificationStore notifications;

    @Mock
    private NotificationJsonCodec json;

    @Mock
    private com.bionote.project.ProjectInvitationStore invitations;

    @Mock
    private com.bionote.project.ProjectStore projects;

    @Mock
    private com.bionote.project.ProjectMemberStore members;

    @Mock
    private com.bionote.record.RecordStore records;

    @Mock
    private com.bionote.review.ReviewStore reviews;

    @InjectMocks
    private NotificationService service;

    private static final UUID USER_ID = UUID.randomUUID();
    private static final UUID NOTIF_ID = UUID.randomUUID();

    @Test
    void list_shouldReturnPagedResponse() {
        when(invitations.expireDueForInvitee(eq(USER_ID), any(Instant.class))).thenReturn(0);
        NotificationStore.NotificationRecord record = new NotificationStore.NotificationRecord(
                NOTIF_ID, USER_ID, "INVITATION", "邀请", "你被邀请了",
                "{\"invitationId\":\"" + UUID.randomUUID() + "\"}", "dedup-key",
                Instant.now(), null
        );
        when(notifications.findByRecipient(USER_ID, false, 0, 20))
                .thenReturn(new NotificationStore.PageSlice(List.of(record), 1));
        when(json.decode("{\"invitationId\":\"" + record.payloadJson().substring(17, 53) + "\"}"))
                .thenReturn(Map.of("invitationId", record.payloadJson().substring(17, 53)));

        // Expect resolve to return minimal result
        PagedResponse<NotificationDtos.View> result = service.list(USER_ID, false, 0, 20);

        assertNotNull(result);
        assertEquals(1, result.meta().totalElements());
    }

    @Test
    void list_shouldReturnEmptyWhenNoNotifications() {
        when(invitations.expireDueForInvitee(eq(USER_ID), any(Instant.class))).thenReturn(0);
        when(notifications.findByRecipient(USER_ID, true, 0, 20))
                .thenReturn(new NotificationStore.PageSlice(List.of(), 0));

        PagedResponse<NotificationDtos.View> result = service.list(USER_ID, true, 0, 20);

        assertNotNull(result);
        assertEquals(0, result.meta().totalElements());
        assertTrue(result.data().isEmpty());
    }

    @Test
    void unread_shouldReturnCount() {
        when(notifications.countUnread(USER_ID)).thenReturn(5L);

        long count = service.unread(USER_ID);

        assertEquals(5L, count);
    }

    @Test
    void read_shouldMarkAsRead() {
        when(notifications.markRead(eq(NOTIF_ID), eq(USER_ID), any(Instant.class)))
                .thenReturn(true);

        assertDoesNotThrow(() -> service.read(USER_ID, NOTIF_ID));
    }

    @Test
    void read_shouldThrowWhenNotFound() {
        when(notifications.markRead(eq(NOTIF_ID), eq(USER_ID), any(Instant.class)))
                .thenReturn(false);

        com.bionote.common.ApiException ex = assertThrows(com.bionote.common.ApiException.class,
                () -> service.read(USER_ID, NOTIF_ID));

        assertEquals("RESOURCE_NOT_FOUND", ex.code());
        assertEquals(HttpStatus.NOT_FOUND, ex.status());
    }

    @Test
    void readAll_shouldMarkAllAsRead() {
        doNothing().when(notifications).markAllRead(eq(USER_ID), any(Instant.class));

        assertDoesNotThrow(() -> service.readAll(USER_ID));
        verify(notifications).markAllRead(eq(USER_ID), any(Instant.class));
    }

    @Test
    void list_shouldHandleNullPayloadFields() {
        when(invitations.expireDueForInvitee(eq(USER_ID), any(Instant.class))).thenReturn(0);
        NotificationStore.NotificationRecord record = new NotificationStore.NotificationRecord(
                NOTIF_ID, USER_ID, "SYSTEM", "系统通知", "内容",
                "{}", "dedup-1", Instant.now(), null
        );
        when(notifications.findByRecipient(USER_ID, false, 0, 20))
                .thenReturn(new NotificationStore.PageSlice(List.of(record), 1));
        when(json.decode("{}")).thenReturn(Map.of());

        PagedResponse<NotificationDtos.View> result = service.list(USER_ID, false, 0, 20);

        assertNotNull(result);
        assertEquals(1, result.data().size());
        assertNotNull(result.data().get(0).title());
    }
}
