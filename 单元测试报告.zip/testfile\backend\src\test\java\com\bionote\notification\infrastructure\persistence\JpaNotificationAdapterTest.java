package com.bionote.notification.infrastructure.persistence;

import com.bionote.notification.NotificationStore;
import com.bionote.notification.NotificationJsonCodec;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JpaNotificationAdapterTest {

    @Mock
    private NotificationJpaRepository repository;

    @Mock
    private NotificationJsonCodec json;

    @InjectMocks
    private JpaNotificationAdapter adapter;

    private static final UUID USER_ID = UUID.randomUUID();
    private static final UUID NOTIF_ID = UUID.randomUUID();

    private NotificationEntity createEntity() {
        return new NotificationEntity() {
            {
                // Using reflection to set fields would be cleaner, but for testing we test
                // through the adapter methods
            }
        };
    }

    @Test
    void findByRecipient_shouldReturnPagedResults() {
        NotificationEntity entity = createEntity();
        // We need to use reflection to set values or rely on mock behavior
        // Since entity has a protected no-arg constructor, let's test via mocks
        when(repository.findByRecipientIdAndReadAtIsNullOrderByCreatedAtDescIdDesc(
                eq(USER_ID), any(PageRequest.class)))
                .thenReturn(new PageImpl<>(List.of()));

        NotificationStore.PageSlice result = adapter.findByRecipient(USER_ID, true, 0, 10);

        assertNotNull(result);
        assertEquals(0, result.total());
    }

    @Test
    void countUnread_shouldDelegateToRepository() {
        when(repository.countByRecipientIdAndReadAtIsNull(USER_ID)).thenReturn(3L);

        long count = adapter.countUnread(USER_ID);

        assertEquals(3L, count);
    }

    @Test
    void markRead_shouldReturnTrueWhenUpdated() {
        when(repository.markRead(eq(NOTIF_ID), eq(USER_ID), any(Instant.class))).thenReturn(1);

        boolean result = adapter.markRead(NOTIF_ID, USER_ID, Instant.now());

        assertTrue(result);
    }

    @Test
    void markRead_shouldReturnFalseWhenNotUpdated() {
        when(repository.markRead(eq(NOTIF_ID), eq(USER_ID), any(Instant.class))).thenReturn(0);

        boolean result = adapter.markRead(NOTIF_ID, USER_ID, Instant.now());

        assertFalse(result);
    }

    @Test
    void markAllRead_shouldDelegateToRepository() {
        when(repository.markAllRead(eq(USER_ID), any(Instant.class))).thenReturn(5);

        assertDoesNotThrow(() -> adapter.markAllRead(USER_ID, Instant.now()));
    }

    @Test
    void appendIfAbsent_shouldEncodeAndAppend() {
        Map<String, ?> payload = Map.of("test", "value");
        when(json.encode(payload)).thenReturn("{\"test\":\"value\"}");
        when(repository.appendIfAbsent(anyString(), anyString(), anyString(), anyString(),
                anyString(), anyString(), anyString(), any(Instant.class))).thenReturn(1);

        assertDoesNotThrow(() -> adapter.appendIfAbsent(NOTIF_ID, USER_ID, "TYPE",
                "Title", "Body", payload, "dedup", Instant.now()));
    }
}
