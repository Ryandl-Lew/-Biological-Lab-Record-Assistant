import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import Badge from '@/components/ui/Badge';

describe('Badge', () => {
  it('renders children text', () => {
    render(<Badge>标签文字</Badge>);
    expect(screen.getByText('标签文字')).toBeInTheDocument();
  });

  it('applies default gray tone when no tone specified', () => {
    render(<Badge>默认灰色</Badge>);
    const badge = screen.getByText('默认灰色');
    expect(badge.className).toContain('bg-slate-100');
  });

  it('applies blue tone class', () => {
    render(<Badge tone="blue">蓝色标签</Badge>);
    const badge = screen.getByText('蓝色标签');
    expect(badge.className).toContain('bg-brand-50');
    expect(badge.className).toContain('text-brand-700');
  });

  it('renders dot indicator when dot is true', () => {
    render(<Badge tone="green" dot>带圆点</Badge>);
    const badge = screen.getByText('带圆点');
    const dot = badge.querySelector('span');
    expect(dot).toBeTruthy();
    expect(dot.className).toContain('bg-emerald-500');
  });

  it('does not render dot when dot is false', () => {
    render(<Badge tone="red">无圆点</Badge>);
    const badge = screen.getByText('无圆点');
    const dots = badge.querySelectorAll('span');
    expect(dots.length).toBe(0);
  });

  it('falls back to gray for unknown tone', () => {
    render(<Badge tone="unknown">未知色系</Badge>);
    const badge = screen.getByText('未知色系');
    expect(badge.className).toContain('bg-slate-100');
  });
});
