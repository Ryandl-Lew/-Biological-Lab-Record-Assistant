import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, act } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import RecentList from '@/components/dashboard/RecentList';

vi.mock('@/lib/recentTracker', () => ({
  getRecent: vi.fn(),
  clearRecent: vi.fn(),
}));

vi.mock('@/lib/formatRelativeTime', () => ({
  default: vi.fn(() => '1小时前'),
}));

const { getRecent, clearRecent } = vi.hoisted(() => {
  return { getRecent: vi.fn(), clearRecent: vi.fn() };
});

describe('RecentList', () => {
  const renderWithRouter = (ui) => render(<MemoryRouter>{ui}</MemoryRouter>);

  beforeEach(() => {
    vi.clearAllMocks();
    vi.mocked(getRecent).mockReturnValue([]);
  });

  it('renders empty state when no recent items', () => {
    getRecent.mockReturnValue([]);
    renderWithRouter(<RecentList />);
    expect(screen.getByText(/暂无最近访问/)).toBeInTheDocument();
  });

  it('renders recent items', () => {
    getRecent.mockReturnValue([
      { id: '1', type: 'record', title: '实验记录A', visitedAt: new Date().toISOString() },
      { id: '2', type: 'project', title: '项目B', visitedAt: new Date().toISOString() },
    ]);
    renderWithRouter(<RecentList />);
    expect(screen.getByText('实验记录A')).toBeInTheDocument();
    expect(screen.getByText('项目B')).toBeInTheDocument();
  });

  it('calls clearRecent when clear button clicked', () => {
    getRecent.mockReturnValue([{ id: '1', type: 'record', title: '记录', visitedAt: new Date().toISOString() }]);
    renderWithRouter(<RecentList />);
    fireEvent.click(screen.getByText('清除'));
    expect(clearRecent).toHaveBeenCalled();
  });

  it('renders heading text', () => {
    getRecent.mockReturnValue([]);
    renderWithRouter(<RecentList />);
    expect(screen.getByText('最近')).toBeInTheDocument();
  });
});
