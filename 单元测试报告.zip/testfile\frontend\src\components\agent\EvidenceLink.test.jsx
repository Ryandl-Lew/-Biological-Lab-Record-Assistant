import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import EvidenceLink from '@/components/agent/EvidenceLink';

describe('EvidenceLink', () => {
  const evidence = { label: '证据A', type: '文档', ref: 'ref-1' };

  it('renders label and type', () => {
    render(<EvidenceLink evidence={evidence} />);
    expect(screen.getByText(/证据A/)).toBeInTheDocument();
    expect(screen.getByText(/文档/)).toBeInTheDocument();
  });

  it('calls onNavigate when clicked', () => {
    const onNavigate = vi.fn();
    render(<EvidenceLink evidence={evidence} onNavigate={onNavigate} />);
    fireEvent.click(screen.getByRole('button'));
    expect(onNavigate).toHaveBeenCalledWith(evidence);
  });

  it('renders aria label', () => {
    render(<EvidenceLink evidence={evidence} />);
    expect(screen.getByRole('button')).toHaveAttribute('aria-label', '查看证据：证据A');
  });

  it('does not throw when no onNavigate provided', () => {
    render(<EvidenceLink evidence={evidence} />);
    fireEvent.click(screen.getByRole('button'));
    // Should not throw
    expect(screen.getByRole('button')).toBeInTheDocument();
  });
});
