import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('./client', () => ({ request: vi.fn() }))

import { request } from './client'
import {
  fetchRecords,
  fetchRecord,
  reserveRecord,
  discardRecordReservation,
  createRecord,
  updateRecord,
  deleteRecord,
} from './records'

describe('records API', () => {
  beforeEach(() => {
    request.mockReset()
  })

  describe('fetchRecords', () => {
    it('sends GET /records with object params', async () => {
      request.mockResolvedValueOnce([{ id: 'rec-1', title: '实验' }])
      await fetchRecords({ projectId: 'proj-1', page: 1 })
      expect(request).toHaveBeenCalledWith('/records?projectId=proj-1&page=1')
    })

    it('treats string param as projectId', async () => {
      request.mockResolvedValueOnce([])
      await fetchRecords('proj-1')
      expect(request).toHaveBeenCalledWith('/records?projectId=proj-1')
    })

    it('filters out falsy params', async () => {
      request.mockResolvedValueOnce([])
      await fetchRecords({ projectId: 'proj-1', keyword: '', page: undefined })
      expect(request).toHaveBeenCalledWith('/records?projectId=proj-1')
    })
  })

  describe('fetchRecord', () => {
    it('sends GET /records/:id', async () => {
      request.mockResolvedValueOnce({ id: 'rec-1', title: '实验记录A' })
      const record = await fetchRecord('rec-1')
      expect(request).toHaveBeenCalledWith('/records/rec-1')
      expect(record).toEqual({ id: 'rec-1', title: '实验记录A' })
    })
  })

  describe('reserveRecord', () => {
    it('sends POST /records/reservations with input', async () => {
      request.mockResolvedValueOnce({ id: 'res-1', number: 'R001' })
      const input = { projectId: 'proj-1', templateId: 'tpl-1' }
      await reserveRecord(input)
      expect(request).toHaveBeenCalledWith('/records/reservations', {
        method: 'POST',
        body: JSON.stringify(input),
      })
    })
  })

  describe('discardRecordReservation', () => {
    it('sends DELETE /records/:id/reservation', async () => {
      request.mockResolvedValueOnce(null)
      await discardRecordReservation('rec-1')
      expect(request).toHaveBeenCalledWith('/records/rec-1/reservation', { method: 'DELETE' })
    })
  })

  describe('createRecord', () => {
    it('sends POST /records with input', async () => {
      request.mockResolvedValueOnce({ id: 'rec-2', title: '新实验' })
      const input = { title: '新实验', projectId: 'proj-1' }
      await createRecord(input)
      expect(request).toHaveBeenCalledWith('/records', {
        method: 'POST',
        body: JSON.stringify(input),
      })
    })
  })

  describe('updateRecord', () => {
    it('sends PUT /records/:id with input', async () => {
      request.mockResolvedValueOnce({ id: 'rec-1', title: '已更新' })
      const input = { title: '已更新' }
      await updateRecord('rec-1', input)
      expect(request).toHaveBeenCalledWith('/records/rec-1', {
        method: 'PUT',
        body: JSON.stringify(input),
      })
    })
  })

  describe('deleteRecord', () => {
    it('sends DELETE /records/:id', async () => {
      request.mockResolvedValueOnce(null)
      await deleteRecord('rec-1')
      expect(request).toHaveBeenCalledWith('/records/rec-1', { method: 'DELETE' })
    })
  })
})
