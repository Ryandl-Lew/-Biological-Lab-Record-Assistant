package com.bionote.project.infrastructure.persistence;

import org.junit.jupiter.api.Test;
import java.time.Instant;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class ProjectEntityTest {

    @Test
    void shouldCreateProjectEntity() {
        UUID id = UUID.randomUUID();
        UUID ownerId = UUID.randomUUID();
        Instant now = Instant.now();

        ProjectEntity entity = new ProjectEntity(id, "项目", "描述", "详细", ownerId, now);

        assertEquals(id, entity.id);
        assertEquals("项目", entity.name);
        assertEquals("描述", entity.description);
        assertEquals("详细", entity.detailedDescription);
        assertEquals("ACTIVE", entity.status);
        assertEquals(ownerId, entity.ownerId);
        assertEquals(now, entity.createdAt);
        assertEquals(now, entity.updatedAt);
        assertNull(entity.archivedAt);
        assertEquals(0, entity.version);
    }

    @Test
    void shouldCreateEntityWithNullDescription() {
        UUID id = UUID.randomUUID();
        ProjectEntity entity = new ProjectEntity(id, "项目", null, null, UUID.randomUUID(), Instant.now());

        assertNull(entity.description);
        assertNull(entity.detailedDescription);
    }

    @Test
    void shouldHaveProtectedDefaultConstructor() throws Exception {
        var ctor = ProjectEntity.class.getDeclaredConstructor();
        ctor.setAccessible(true);
        ProjectEntity entity = ctor.newInstance();

        assertNull(entity.id);
        assertNull(entity.name);
    }

    @Test
    void shouldDefaultStatusToActive() {
        ProjectEntity entity = new ProjectEntity(UUID.randomUUID(), "测试", null, null,
                UUID.randomUUID(), Instant.now());
        assertEquals("ACTIVE", entity.status);
    }
}
