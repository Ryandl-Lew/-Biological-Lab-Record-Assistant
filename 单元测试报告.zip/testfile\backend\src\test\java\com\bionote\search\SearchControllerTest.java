package com.bionote.search;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class SearchControllerTest {

    @Mock
    private SearchUseCase service;

    @InjectMocks
    private SearchController controller;

    private static final UUID USER_ID = UUID.randomUUID();
    private static final UUID PROJECT_ID = UUID.randomUUID();

    @Test
    void search_shouldReturnResponseFromService() {
        SearchDtos.Result result = new SearchDtos.Result(
                "PROJECT", "p-1", "My Project", "description snippet",
                PROJECT_ID, "My Project", "ACTIVE", java.time.Instant.now(),
                Map.of("type", "PROJECT", "id", "p-1")
        );
        SearchDtos.Meta meta = new SearchDtos.Meta(0, 20, 1, Map.of("PROJECT", 1L));
        SearchDtos.Response expected = new SearchDtos.Response(List.of(result), meta);

        when(service.search(USER_ID, "project", "PROJECT", PROJECT_ID, null, "ACTIVE", 0, 20))
                .thenReturn(expected);

        SearchDtos.Response response = service.search(USER_ID, "project", "PROJECT", PROJECT_ID, null, "ACTIVE", 0, 20);

        assertNotNull(response);
        assertEquals(1, response.data().size());
        assertEquals("PROJECT", response.data().get(0).entityType());
        assertEquals("ACTIVE", response.data().get(0).status());
    }

    @Test
    void search_shouldReturnEmptyForNoMatch() {
        SearchDtos.Response expected = new SearchDtos.Response(
                List.of(), new SearchDtos.Meta(0, 20, 0, Map.of())
        );

        when(service.search(USER_ID, "zzzznotexist", "ALL", null, null, null, 0, 20))
                .thenReturn(expected);

        SearchDtos.Response response = service.search(USER_ID, "zzzznotexist", "ALL", null, null, null, 0, 20);

        assertNotNull(response);
        assertTrue(response.data().isEmpty());
        assertEquals(0, response.meta().total());
    }

    @Test
    void search_shouldHandleNullEntityType() {
        SearchDtos.Response expected = new SearchDtos.Response(
                List.of(), new SearchDtos.Meta(0, 20, 0, Map.of())
        );

        when(service.search(USER_ID, "", null, null, null, null, 0, 20))
                .thenReturn(expected);

        SearchDtos.Response response = service.search(USER_ID, "", null, null, null, null, 0, 20);

        assertNotNull(response);
    }

    @Test
    void search_shouldSupportPagination() {
        SearchDtos.Response expected = new SearchDtos.Response(
                List.of(), new SearchDtos.Meta(1, 10, 25, Map.of("RECORD", 25L))
        );

        when(service.search(USER_ID, "test", "ALL", null, null, null, 1, 10))
                .thenReturn(expected);

        SearchDtos.Response response = service.search(USER_ID, "test", "ALL", null, null, null, 1, 10);

        assertEquals(1, response.meta().page());
        assertEquals(10, response.meta().size());
        assertEquals(25, response.meta().total());
    }

    @Test
    void search_shouldReturnMultipleEntityTypesInCounts() {
        Map<String, Long> counts = Map.of("PROJECT", 3L, "RECORD", 10L, "TEMPLATE", 2L, "MEMBER", 5L, "ATTACHMENT", 1L);
        SearchDtos.Meta meta = new SearchDtos.Meta(0, 20, 21, counts);
        SearchDtos.Response expected = new SearchDtos.Response(List.of(), meta);

        when(service.search(USER_ID, "", "ALL", null, null, null, 0, 20))
                .thenReturn(expected);

        SearchDtos.Response response = service.search(USER_ID, "", "ALL", null, null, null, 0, 20);

        assertEquals(5, response.meta().counts().size());
        assertEquals(21, response.meta().total());
    }
}
