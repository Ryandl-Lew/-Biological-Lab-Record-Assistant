import { describe, it, expect } from 'vitest'
import * as domain from './index'

describe('domain/index', () => {
  it('re-exports all enums from enums.js', () => {
    expect(domain.PROJECT_ROLE_LABELS).toBeDefined()
    expect(domain.PROJECT_ROLE_TONES).toBeDefined()
    expect(domain.PROJECT_STATUS_LABELS).toBeDefined()
    expect(domain.PROJECT_STATUS_TONES).toBeDefined()
    expect(domain.RECORD_STATUS_LABELS).toBeDefined()
    expect(domain.RECORD_STATUS_TONES).toBeDefined()
    expect(domain.TEMPLATE_FIELD_TYPE_LABELS).toBeDefined()
    expect(domain.TEMPLATE_CATEGORY_LABELS).toBeDefined()
    expect(domain.SEARCH_ENTITY_LABELS).toBeDefined()
    expect(domain.SEARCH_ENTITY_TONES).toBeDefined()
    expect(domain.PERMISSION_VALUE_LABELS).toBeDefined()
    expect(domain.PERMISSION_VALUE_TONES).toBeDefined()
  })

  it('re-exports correct enum values', () => {
    expect(domain.PROJECT_ROLE_LABELS.OWNER).toBe('项目负责人')
    expect(domain.RECORD_STATUS_TONES.COMPLETED).toBe('green')
    expect(domain.SEARCH_ENTITY_LABELS.PROJECT).toBe('项目')
    expect(domain.PERMISSION_VALUE_LABELS.yes).toBe('是')
  })

  it('does not export common.js runtime values (JSDoc only)', () => {
    // common.js has `export {}`, so it should not add runtime keys
    const keys = Object.keys(domain)
    expect(keys).toContain('PROJECT_ROLE_LABELS')
    expect(keys).toContain('RECORD_STATUS_TONES')
  })
})
