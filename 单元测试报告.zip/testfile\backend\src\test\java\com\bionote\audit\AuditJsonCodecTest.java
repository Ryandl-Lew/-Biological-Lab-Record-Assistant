package com.bionote.audit;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.LinkedHashMap;
import java.util.Map;

import static com.fasterxml.jackson.databind.SerializationFeature.WRITE_DATES_AS_TIMESTAMPS;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("AuditJsonCodec 测试")
class AuditJsonCodecTest {

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private AuditJsonCodec codec;

    @Test
    @DisplayName("encode 成功应返回 JSON 字符串")
    void shouldEncodeMapToJson() throws Exception {
        Map<String, Object> map = Map.of("key", "value", "count", 42);
        when(objectMapper.writeValueAsString(map)).thenReturn("{\"key\":\"value\",\"count\":42}");

        String result = codec.encode(map);

        assertEquals("{\"key\":\"value\",\"count\":42}", result);
        verify(objectMapper).writeValueAsString(map);
    }

    @Test
    @DisplayName("encode 失败应抛 IllegalArgumentException")
    void shouldThrowWhenEncodeFails() throws Exception {
        Map<String, Object> map = Map.of("bad", new Object());
        when(objectMapper.writeValueAsString(map)).thenThrow(new RuntimeException("serialize error"));

        Exception ex = assertThrows(IllegalArgumentException.class, () -> codec.encode(map));
        assertEquals("Audit metadata cannot be encoded", ex.getMessage());
        assertNotNull(ex.getCause());
    }

    @Test
    @DisplayName("decode 成功应返回 Map")
    void shouldDecodeJsonToMap() throws Exception {
        Map<String, Object> expected = new LinkedHashMap<>();
        expected.put("name", "test");
        expected.put("count", 10);
        when(objectMapper.readValue(eq("{\"name\":\"test\"}"), any(TypeReference.class))).thenReturn(expected);

        Map<String, Object> result = codec.decode("{\"name\":\"test\"}");

        assertEquals(expected, result);
    }

    @Test
    @DisplayName("decode 失败应返回空 Map")
    void shouldReturnEmptyMapWhenDecodeFails() throws Exception {
        when(objectMapper.readValue(eq("invalid json"), any(TypeReference.class)))
                .thenThrow(new RuntimeException("parse error"));

        Map<String, Object> result = codec.decode("invalid json");

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    @DisplayName("encode 空 Map 应返回空 JSON 对象")
    void shouldEncodeEmptyMap() throws Exception {
        Map<String, Object> empty = Map.of();
        when(objectMapper.writeValueAsString(empty)).thenReturn("{}");

        String result = codec.encode(empty);

        assertEquals("{}", result);
    }
}
