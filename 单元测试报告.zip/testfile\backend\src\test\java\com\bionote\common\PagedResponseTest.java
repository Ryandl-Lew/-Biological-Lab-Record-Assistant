package com.bionote.common;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("PagedResponse 记录测试")
class PagedResponseTest {

    @Test
    @DisplayName("应正确构造 PagedResponse 及内嵌 Meta")
    void shouldConstructPagedResponseWithMeta() {
        PagedResponse.Meta meta = new PagedResponse.Meta(0, 10, 100L, 10);
        PagedResponse<String> response = new PagedResponse<>(List.of("a", "b", "c"), meta);

        assertEquals(3, response.data().size());
        assertEquals(0, response.meta().page());
        assertEquals(10, response.meta().size());
        assertEquals(100L, response.meta().totalElements());
        assertEquals(10, response.meta().totalPages());
    }

    @Test
    @DisplayName("of 静态工厂应正确计算 totalPages")
    void ofShouldComputeTotalPages() {
        PagedResponse<String> response = PagedResponse.of(
                List.of("a", "b", "c"), 0, 3, 10L);

        assertEquals(3, response.data().size());
        assertEquals(0, response.meta().page());
        assertEquals(3, response.meta().size());
        assertEquals(10L, response.meta().totalElements());
        assertEquals(4, response.meta().totalPages()); // ceil(10/3) = 4
    }

    @Test
    @DisplayName("size 为 0 时 totalPages 应为 0")
    void shouldReturnZeroTotalPagesWhenSizeIsZero() {
        PagedResponse<String> response = PagedResponse.of(
                List.of(), 0, 0, 5L);

        assertEquals(0, response.meta().totalPages());
        assertEquals(5L, response.meta().totalElements());
    }

    @Test
    @DisplayName("totalElements 为 0 时 totalPages 应为 0")
    void shouldReturnZeroTotalPagesWhenTotalElementsIsZero() {
        PagedResponse<String> response = PagedResponse.of(
                List.of(), 0, 10, 0L);

        assertEquals(0, response.meta().totalPages());
    }

    @Test
    @DisplayName("数据刚好整页时 totalPages 应正确")
    void shouldComputeExactTotalPages() {
        PagedResponse<Integer> response = PagedResponse.of(
                List.of(1, 2, 3, 4, 5), 0, 5, 25L);

        assertEquals(5, response.meta().totalPages()); // ceil(25/5) = 5
    }
}
