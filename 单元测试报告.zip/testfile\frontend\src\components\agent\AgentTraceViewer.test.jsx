import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import AgentTraceViewer from '@/components/agent/AgentTraceViewer';

vi.mock('@/api', () => ({
  fetchAgentSteps: vi.fn(),
}));

vi.mock('@/components/ui', () => ({
  Button: ({ children, onClick, disabled, size, variant }) => (
    <button onClick={onClick} disabled={disabled}>{children}</button>
  ),
  EmptyState: ({ title }) => <div>{title}</div>,
}));

const { fetchAgentSteps } = await import('@/api');

describe('AgentTraceViewer', () => {
  const run = {
    id: 'run-1',
    status: 'SUCCEEDED',
    triggerType: 'manual',
    provider: 'openai',
    model: 'gpt-4',
    inputTokens: 100,
    outputTokens: 200,
  };

  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('returns null when not open', () => {
    const { container } = render(
      <AgentTraceViewer run={run} open={false} onClose={vi.fn()} />
    );
    expect(container.innerHTML).toBe('');
  });

  it('returns null when no run', () => {
    const { container } = render(
      <AgentTraceViewer run={null} open={true} onClose={vi.fn()} />
    );
    expect(container.innerHTML).toBe('');
  });

  it('renders dialog with run info when open', async () => {
    fetchAgentSteps.mockResolvedValue({ items: [] });
    render(<AgentTraceViewer run={run} open={true} onClose={vi.fn()} />);
    expect(screen.getByText('运行轨迹')).toBeInTheDocument();
    expect(screen.getByText(/run-1/)).toBeInTheDocument();
  });

  it('shows no steps message when steps are empty', async () => {
    fetchAgentSteps.mockResolvedValue({ items: [] });
    render(<AgentTraceViewer run={run} open={true} onClose={vi.fn()} />);
    expect(await screen.findByText('该运行尚无可见步骤')).toBeInTheDocument();
  });

  it('shows steps when available', async () => {
    fetchAgentSteps.mockResolvedValue({
      items: [
        { id: 's1', stepNo: 1, stepType: 'tool', toolName: 'search', latencyMs: 150, request: {}, response: {} },
      ],
    });
    render(<AgentTraceViewer run={run} open={true} onClose={vi.fn()} />);
    expect(await screen.findByText(/#1.*tool.*search/)).toBeTruthy();
  });
});
