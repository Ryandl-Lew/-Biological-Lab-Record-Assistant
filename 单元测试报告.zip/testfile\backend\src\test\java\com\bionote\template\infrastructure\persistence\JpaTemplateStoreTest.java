package com.bionote.template.infrastructure.persistence;

import com.bionote.template.TemplateStore;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JpaTemplateStoreTest {

    @Mock
    private RecordTemplateJpaRepository templates;

    @Mock
    private TemplateFieldJpaRepository fields;

    @InjectMocks
    private JpaTemplateStore store;

    private static final UUID USER_ID = UUID.randomUUID();
    private static final UUID TEMPLATE_ID = UUID.randomUUID();
    private static final Instant NOW = Instant.now();

    private RecordTemplateEntity createEntity() {
        return new RecordTemplateEntity(
                TEMPLATE_ID, USER_ID, "测试模板", "测试模板",
                "active-key", "化学", "实验", "描述", NOW
        );
    }

    @Test
    void search_shouldReturnPagedResults() {
        RecordTemplateEntity entity = createEntity();
        when(templates.findAll(any(Specification.class), any(PageRequest.class)))
                .thenReturn(new PageImpl<>(List.of(entity), PageRequest.of(0, 20), 1));
        when(fields.findByTemplateIdOrderBySortOrderAsc(TEMPLATE_ID))
                .thenReturn(List.of());

        TemplateStore.PageSlice result = store.search(USER_ID, null, null, "", 0, 20);

        assertNotNull(result);
        assertEquals(1, result.total());
        assertEquals(1, result.items().size());
    }

    @Test
    void search_shouldFilterByScope() {
        when(templates.findAll(any(Specification.class), any(PageRequest.class)))
                .thenReturn(new PageImpl<>(List.of(), PageRequest.of(0, 10), 0));

        TemplateStore.PageSlice result = store.search(USER_ID, "SYSTEM", null, "", 0, 10);

        assertNotNull(result);
        assertEquals(0, result.total());
    }

    @Test
    void search_shouldFilterByCategory() {
        when(templates.findAll(any(Specification.class), any(PageRequest.class)))
                .thenReturn(new PageImpl<>(List.of(), PageRequest.of(0, 10), 0));

        TemplateStore.PageSlice result = store.search(USER_ID, null, "酸碱性", "", 0, 10);

        assertNotNull(result);
        assertEquals(0, result.total());
    }

    @Test
    void findVisible_shouldReturnTemplateWhenAccessible() {
        RecordTemplateEntity entity = createEntity();
        when(templates.findById(TEMPLATE_ID)).thenReturn(Optional.of(entity));
        when(fields.findByTemplateIdOrderBySortOrderAsc(TEMPLATE_ID))
                .thenReturn(List.of());

        Optional<TemplateStore.TemplateRecord> result = store.findVisible(USER_ID, TEMPLATE_ID);

        assertTrue(result.isPresent());
        assertEquals("测试模板", result.get().name());
    }

    @Test
    void findVisible_shouldReturnEmptyWhenDeleted() {
        RecordTemplateEntity entity = createEntity();
        entity.softDelete(NOW);
        when(templates.findById(TEMPLATE_ID)).thenReturn(Optional.of(entity));

        Optional<TemplateStore.TemplateRecord> result = store.findVisible(USER_ID, TEMPLATE_ID);

        assertTrue(result.isEmpty());
    }

    @Test
    void findVisible_shouldReturnEmptyWhenNotOwnerAndNotSystem() {
        UUID otherOwner = UUID.randomUUID();
        RecordTemplateEntity entity = new RecordTemplateEntity(
                TEMPLATE_ID, otherOwner, "他人模板", "他人模板",
                "key", "类型", "分类", "描述", NOW
        );
        when(templates.findById(TEMPLATE_ID)).thenReturn(Optional.of(entity));

        Optional<TemplateStore.TemplateRecord> result = store.findVisible(USER_ID, TEMPLATE_ID);

        assertTrue(result.isEmpty());
    }

    @Test
    void existsByActiveNameKey_shouldDelegateToRepository() {
        when(templates.existsByActiveNameKey("key")).thenReturn(true);

        assertTrue(store.existsByActiveNameKey("key"));
    }

    @Test
    void softDelete_shouldReturnFalseWhenNotFound() {
        when(templates.findById(TEMPLATE_ID)).thenReturn(Optional.empty());

        boolean result = store.softDelete(TEMPLATE_ID, USER_ID, 1L, NOW);

        assertFalse(result);
    }
}
