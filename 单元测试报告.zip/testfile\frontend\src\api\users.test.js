import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('./client', () => ({ request: vi.fn() }))

import { request } from './client'
import { updateMyProfile, uploadMyAvatar } from './users'

describe('users API', () => {
  beforeEach(() => {
    request.mockReset()
  })

  describe('updateMyProfile', () => {
    it('sends PUT /users/me with displayName', async () => {
      request.mockResolvedValueOnce({ id: 'user-1', displayName: '新名字' })
      const result = await updateMyProfile('新名字')
      expect(request).toHaveBeenCalledWith('/users/me', {
        method: 'PUT',
        body: JSON.stringify({ displayName: '新名字' }),
      })
      expect(result).toEqual({ id: 'user-1', displayName: '新名字' })
    })

    it('handles empty displayName', async () => {
      request.mockResolvedValueOnce({ id: 'user-1', displayName: '' })
      await updateMyProfile('')
      expect(request).toHaveBeenCalledWith('/users/me', {
        method: 'PUT',
        body: JSON.stringify({ displayName: '' }),
      })
    })
  })

  describe('uploadMyAvatar', () => {
    it('sends POST /users/me/avatar with FormData containing the file', async () => {
      request.mockResolvedValueOnce({ avatarUrl: '/avatars/user-1.png' })
      const file = new File(['avatar-data'], 'avatar.png', { type: 'image/png' })
      const result = await uploadMyAvatar(file)

      expect(request).toHaveBeenCalled()
      const [path, options] = request.mock.calls[0]
      expect(path).toBe('/users/me/avatar')
      expect(options.method).toBe('POST')
      expect(options.body).toBeInstanceOf(FormData)
      expect(options.body.get('file')).toBe(file)
      expect(result).toEqual({ avatarUrl: '/avatars/user-1.png' })
    })
  })
})
