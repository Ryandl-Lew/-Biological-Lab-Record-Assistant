package com.bionote.record.infrastructure.persistence;

import com.bionote.record.RecordStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JpaRecordStoreTest {

    @Mock private ExperimentRecordJpaRepository records;

    private JpaRecordStore recordStore;
    private final UUID recordId = UUID.randomUUID();
    private final UUID creatorId = UUID.randomUUID();
    private final UUID projectId = UUID.randomUUID();

    @BeforeEach
    void setUp() {
        recordStore = new JpaRecordStore(records);
    }

    @Test
    void shouldInsertRecord() {
        when(records.saveAndFlush(any())).thenReturn(null);
        RecordStore.NewRecord newRecord = new RecordStore.NewRecord(
                recordId, "EXP-001", projectId, creatorId, "标题", "实验",
                LocalDate.now(), "目的", false, "{}", "{}", "{}", "", "", Instant.now());

        assertDoesNotThrow(() -> recordStore.insert(newRecord));
        verify(records).saveAndFlush(any());
    }

    @Test
    void shouldFindActiveRecord() {
        ExperimentRecordEntity entity = createEntity();
        when(records.findById(recordId)).thenReturn(Optional.of(entity));

        Optional<RecordStore.RecordData> result = recordStore.findActive(recordId);
        assertTrue(result.isPresent());
        assertEquals(recordId, result.get().id());
    }

    @Test
    void shouldReturnEmptyForSoftDeleted() {
        ExperimentRecordEntity entity = createEntity();
        entity.softDelete(Instant.now());
        when(records.findById(recordId)).thenReturn(Optional.of(entity));

        Optional<RecordStore.RecordData> result = recordStore.findActive(recordId);
        assertFalse(result.isPresent());
    }

    @Test
    void shouldReturnEmptyForNotFound() {
        when(records.findById(recordId)).thenReturn(Optional.empty());

        Optional<RecordStore.RecordData> result = recordStore.findActive(recordId);
        assertFalse(result.isPresent());
    }

    @Test
    void shouldMarkSubmitted() {
        when(records.markSubmitted(anyString(), anyLong(), anyInt(), anyString(), any()))
                .thenReturn(1);

        boolean result = recordStore.markSubmitted(recordId, 0L, 1, UUID.randomUUID(), Instant.now());
        assertTrue(result);
    }

    @Test
    void shouldReturnFalseOnFailedMarkSubmitted() {
        when(records.markSubmitted(anyString(), anyLong(), anyInt(), anyString(), any()))
                .thenReturn(0);

        boolean result = recordStore.markSubmitted(recordId, 0L, 1, UUID.randomUUID(), Instant.now());
        assertFalse(result);
    }

    @Test
    void shouldMarkReviewApproved() {
        when(records.markReviewApproved(anyString(), anyString(), anyString(), any()))
                .thenReturn(1);

        boolean result = recordStore.markReviewApproved(recordId,
                UUID.randomUUID(), UUID.randomUUID(), Instant.now());
        assertTrue(result);
    }

    @Test
    void shouldMarkReviewChangesRequested() {
        when(records.markReviewChangesRequested(anyString(), anyString(), any()))
                .thenReturn(1);

        boolean result = recordStore.markReviewChangesRequested(recordId,
                UUID.randomUUID(), Instant.now());
        assertTrue(result);
    }

    @Test
    void shouldDeleteProvisional() {
        when(records.deleteProvisional(recordId, creatorId)).thenReturn(1);

        boolean result = recordStore.deleteProvisional(recordId, creatorId);
        assertTrue(result);
    }

    @Test
    void shouldNotDeleteProvisionalIfNotCreator() {
        UUID otherId = UUID.randomUUID();
        lenient().when(records.deleteProvisional(recordId, otherId)).thenReturn(0);

        boolean result = recordStore.deleteProvisional(recordId, otherId);
        assertFalse(result);
    }

    @Test
    void shouldReplaceFieldValuesWithoutVersion() {
        when(records.replaceFieldValuesWithoutVersion(anyString(), anyString())).thenReturn(1);
        assertDoesNotThrow(() -> recordStore.replaceFieldValuesWithoutVersion(recordId, "{\"key\":\"value\"}"));
    }

    private ExperimentRecordEntity createEntity() {
        return new ExperimentRecordEntity(recordId, "EXP-001", projectId, creatorId,
                "标题", "实验", LocalDate.now(), "目的", false,
                "{}", "{}", "{}", "", "", Instant.now());
    }
}
