package com.bionote.record;

import org.junit.jupiter.api.Test;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Map;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class RecordDtosTest {

    private final UUID projectId = UUID.randomUUID();
    private final UUID recordId = UUID.randomUUID();

    @Test
    void shouldCreateReserveRequest() {
        RecordDtos.ReserveRequest request = new RecordDtos.ReserveRequest(projectId, null);
        assertEquals(projectId, request.projectId());
        assertNull(request.templateId());
    }

    @Test
    void shouldCreateReserveRequestWithTemplate() {
        UUID templateId = UUID.randomUUID();
        RecordDtos.ReserveRequest request = new RecordDtos.ReserveRequest(projectId, templateId);
        assertEquals(templateId, request.templateId());
    }

    @Test
    void shouldCreateCreateRequest() {
        RecordDtos.CreateRequest request = new RecordDtos.CreateRequest(
                projectId, null, "实验标题", "生物实验", LocalDate.now(), "研究目的");
        assertEquals("实验标题", request.title());
        assertEquals("生物实验", request.experimentType());
        assertEquals("研究目的", request.purpose());
    }

    @Test
    void shouldCreateUpdateRequest() {
        Map<String, Object> fieldValues = Map.of("key1", "value1");
        RecordDtos.UpdateRequest request = new RecordDtos.UpdateRequest(
                0L, "更新标题", "实验类型", LocalDate.now(), "新目的",
                fieldValues, Map.of(), "<p>html</p>");
        assertEquals(0L, request.version());
        assertEquals("更新标题", request.title());
        assertEquals(fieldValues, request.fieldValues());
    }

    @Test
    void shouldCreateRecordView() {
        Instant now = Instant.now();
        RecordDtos.View view = new RecordDtos.View(
                recordId, "EXP-001", projectId, "项目名", UUID.randomUUID(), "创建人",
                "标题", "实验", LocalDate.now(), "目的", "IN_PROGRESS", false,
                Map.of("name", "模板"), Map.of("f1", "v1"), Map.of("content", true),
                "<p>html</p>", "text", 0, null, null, 0L, now, now,
                Map.of("canEdit", true, "canDelete", true));
        assertEquals(recordId, view.id());
        assertEquals("EXP-001", view.code());
        assertEquals("IN_PROGRESS", view.status());
        assertNotNull(view.capabilities());
    }

    @Test
    void shouldCreateCompletedRecordView() {
        Instant now = Instant.now();
        RecordDtos.View view = new RecordDtos.View(
                recordId, "EXP-002", projectId, "项目", UUID.randomUUID(), "创建人",
                "已完成标题", "实验", LocalDate.now(), "目的", "COMPLETED", false,
                Map.of(), Map.of(), Map.of(), "<p></p>", "", 3, null,
                Map.of("id", "rev-id", "revisionNo", 3), 3L, now, now,
                Map.of("canEdit", false, "canSubmit", false, "canRestore", false));
        assertEquals("COMPLETED", view.status());
        assertEquals(3, view.currentRevisionNo());
        assertNotNull(view.displayedRevision());
    }
}
