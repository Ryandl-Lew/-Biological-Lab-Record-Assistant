package com.bionote.attachment.infrastructure.persistence;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("RevisionAttachmentEntity 测试")
class RevisionAttachmentEntityTest {

    @Test
    @DisplayName("应正确构造 RevisionAttachmentEntity")
    void shouldConstructCorrectly() {
        UUID revisionId = UUID.randomUUID();
        UUID attachmentId = UUID.randomUUID();
        RevisionAttachmentId id = new RevisionAttachmentId(revisionId, attachmentId);
        RevisionAttachmentEntity entity = new RevisionAttachmentEntity(id, 0);

        assertNotNull(entity);
        assertEquals(id, entity.id);
        assertEquals(0, entity.sortOrder);
    }

    @Test
    @DisplayName("sortOrder 可设置为不同值")
    void shouldAllowDifferentSortOrders() {
        RevisionAttachmentId id = new RevisionAttachmentId(UUID.randomUUID(), UUID.randomUUID());
        RevisionAttachmentEntity entity = new RevisionAttachmentEntity(id, 5);

        assertEquals(5, entity.sortOrder);
    }

    @Test
    @DisplayName("protected 无参构造器应存在")
    void shouldHaveProtectedNoArgConstructor() throws Exception {
        java.lang.reflect.Constructor<RevisionAttachmentEntity> ctor =
                RevisionAttachmentEntity.class.getDeclaredConstructor();
        ctor.setAccessible(true);
        RevisionAttachmentEntity entity = ctor.newInstance();

        assertNotNull(entity);
        assertNull(entity.id);
    }

    @Test
    @DisplayName("不同类型实体的 RevisionAttachmentId 应不同")
    void shouldHaveDifferentCompositeKeys() {
        RevisionAttachmentEntity e1 = new RevisionAttachmentEntity(
                new RevisionAttachmentId(UUID.randomUUID(), UUID.randomUUID()), 0);
        RevisionAttachmentEntity e2 = new RevisionAttachmentEntity(
                new RevisionAttachmentId(UUID.randomUUID(), UUID.randomUUID()), 1);

        assertNotEquals(e1.id.revisionId, e2.id.revisionId);
        assertNotEquals(e1.id.attachmentId, e2.id.attachmentId);
    }
}
