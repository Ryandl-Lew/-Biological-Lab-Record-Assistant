import { describe, it, expect, vi, beforeAll } from 'vitest';

vi.mock('@/components/auth/ProtectedRoute', () => ({
  default: ({ children }) => children,
}));

vi.mock('@/components/layout/AppLayout', () => ({
  default: () => 'AppLayoutContent',
}));

vi.mock('@/pages', () => ({
  DashboardPage: () => 'DashboardPageRendered',
  ProjectsPage: () => 'ProjectsPageRendered',
  ProjectDetailPage: () => 'ProjectDetailPageRendered',
  AgentPage: () => 'AgentPageRendered',
  RecordsPage: () => 'RecordsPageRendered',
  RecordCreatePage: () => 'RecordCreatePageRendered',
  RecordEditorPage: () => 'RecordEditorPageRendered',
  RecordDetailPage: () => 'RecordDetailPageRendered',
  TemplatesPage: () => 'TemplatesPageRendered',
  SearchPage: () => 'SearchPageRendered',
  ProfilePage: () => 'ProfilePageRendered',
  NotFoundPage: () => 'NotFoundPageRendered',
  LoginPage: () => 'LoginPageRendered',
  RegisterPage: () => 'RegisterPageRendered',
}));

describe('router', () => {
  let router;

  beforeAll(async () => {
    const mod = await import('@/router/index.jsx');
    router = mod.router;
  });

  it('should create a router with routes', () => {
    expect(router).toBeDefined();
    expect(router.routes).toBeDefined();
    expect(router.routes).toHaveLength(3);
  });

  it('should have a /login route', () => {
    const loginRoute = router.routes.find((r) => r.path === '/login');
    expect(loginRoute).toBeDefined();
    expect(loginRoute.element).toBeDefined();
  });

  it('should have a /register route', () => {
    const registerRoute = router.routes.find((r) => r.path === '/register');
    expect(registerRoute).toBeDefined();
    expect(registerRoute.element).toBeDefined();
  });

  it('should have the root "/" route', () => {
    const rootRoute = router.routes.find((r) => r.path === '/');
    expect(rootRoute).toBeDefined();
    expect(rootRoute.element).toBeDefined();
  });

  it('should have children routes under the root "/" path', () => {
    const rootRoute = router.routes.find((r) => r.path === '/');
    expect(rootRoute.children).toBeDefined();
    expect(rootRoute.children.length).toBeGreaterThanOrEqual(12);
  });

  it('should have an index route under "/"', () => {
    const rootRoute = router.routes.find((r) => r.path === '/');
    const indexRoute = rootRoute.children.find((r) => r.index === true);
    expect(indexRoute).toBeDefined();
    expect(indexRoute.element).toBeDefined();
  });

  it('should include /projects and /projects/:projectId routes', () => {
    const rootRoute = router.routes.find((r) => r.path === '/');
    const projectsRoute = rootRoute.children.find((r) => r.path === 'projects');
    const projectDetailRoute = rootRoute.children.find(
      (r) => r.path === 'projects/:projectId',
    );
    expect(projectsRoute).toBeDefined();
    expect(projectsRoute.element).toBeDefined();
    expect(projectDetailRoute).toBeDefined();
    expect(projectDetailRoute.element).toBeDefined();
  });

  it('should include /agent route', () => {
    const rootRoute = router.routes.find((r) => r.path === '/');
    const agentRoute = rootRoute.children.find((r) => r.path === 'agent');
    expect(agentRoute).toBeDefined();
    expect(agentRoute.element).toBeDefined();
  });

  it('should include /records and nested record routes', () => {
    const rootRoute = router.routes.find((r) => r.path === '/');
    const recordsRoute = rootRoute.children.find((r) => r.path === 'records');
    expect(recordsRoute).toBeDefined();

    const recordNewRoute = rootRoute.children.find(
      (r) => r.path === 'records/new',
    );
    expect(recordNewRoute).toBeDefined();

    const recordNewEditRoute = rootRoute.children.find(
      (r) => r.path === 'records/new/edit',
    );
    expect(recordNewEditRoute).toBeDefined();

    const recordDetailRoute = rootRoute.children.find(
      (r) => r.path === 'records/:recordId',
    );
    expect(recordDetailRoute).toBeDefined();

    const recordEditRoute = rootRoute.children.find(
      (r) => r.path === 'records/:recordId/edit',
    );
    expect(recordEditRoute).toBeDefined();
  });

  it('should include /templates route', () => {
    const rootRoute = router.routes.find((r) => r.path === '/');
    const templatesRoute = rootRoute.children.find(
      (r) => r.path === 'templates',
    );
    expect(templatesRoute).toBeDefined();
    expect(templatesRoute.element).toBeDefined();
  });

  it('should include /search route', () => {
    const rootRoute = router.routes.find((r) => r.path === '/');
    const searchRoute = rootRoute.children.find((r) => r.path === 'search');
    expect(searchRoute).toBeDefined();
    expect(searchRoute.element).toBeDefined();
  });

  it('should include /profile route', () => {
    const rootRoute = router.routes.find((r) => r.path === '/');
    const profileRoute = rootRoute.children.find((r) => r.path === 'profile');
    expect(profileRoute).toBeDefined();
    expect(profileRoute.element).toBeDefined();
  });

  it('should include a catch-all "*" route for 404', () => {
    const rootRoute = router.routes.find((r) => r.path === '/');
    const wildcardRoute = rootRoute.children.find((r) => r.path === '*');
    expect(wildcardRoute).toBeDefined();
    expect(wildcardRoute.element).toBeDefined();
  });

  it('should have exact 3 top-level routes', () => {
    const topLevelPaths = router.routes.map((r) => r.path);
    expect(topLevelPaths).toContain('/login');
    expect(topLevelPaths).toContain('/register');
    expect(topLevelPaths).toContain('/');
    expect(topLevelPaths).toHaveLength(3);
  });
});
