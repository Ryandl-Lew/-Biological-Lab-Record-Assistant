import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, act } from '@testing-library/react';
import RecordSummaryPanel from '@/components/agent/RecordSummaryPanel';

vi.mock('@/api', () => ({
  createRecordAgentRun: vi.fn(),
  fetchAgentArtifact: vi.fn(),
  fetchAgentRun: vi.fn(),
  fetchRecordArtifacts: vi.fn(),
}));

vi.mock('@/api/agentTypes', () => ({
  AGENT_ARTIFACT_KIND: { RECORD_SUMMARY: 'RECORD_SUMMARY' },
}));

vi.mock('@/components/ui', () => ({
  Button: ({ children, onClick, loading }) => (
    <button onClick={onClick} disabled={loading}>{children}</button>
  ),
  Surface: ({ title, children, extra }) => (
    <section>
      <h2>{title}</h2>
      {extra && <div>{extra}</div>}
      {children}
    </section>
  ),
  EmptyState: ({ title, description }) => (
    <div>
      <h3>{title}</h3>
      <p>{description}</p>
    </div>
  ),
}));

vi.mock('@/components/agent/AgentArtifactView', () => ({
  default: () => <div data-testid="artifact-view">Artifact</div>,
}));

vi.mock('@/components/agent/AgentRunStatus', () => ({
  default: ({ runId, onTrace }) => (
    <div data-testid="run-status">{runId || 'no-run'}</div>
  ),
}));

vi.mock('@/components/agent/AgentTraceViewer', () => ({
  default: ({ open }) => (open ? <div data-testid="trace">Trace</div> : null),
}));

vi.mock('@/components/agent/RecordChatPanel', () => ({
  default: () => <div data-testid="chat-panel">Chat</div>,
}));

vi.mock('@/components/agent/messages', () => ({
  agentErrorMessage: vi.fn(() => '代理错误'),
}));

vi.mock('@/store/authStore', () => ({
  useAuthStore: vi.fn((s) => s({ currentUser: { id: 'u1' } })),
}));

const { fetchRecordArtifacts } = await import('@/api');

describe('RecordSummaryPanel', () => {
  const record = {
    id: 'r1',
    creatorId: 'u1',
    currentRevisionNo: 1,
  };

  beforeEach(() => {
    vi.clearAllMocks();
    fetchRecordArtifacts.mockResolvedValue({ items: [] });
  });

  it('renders "AI 记录总结" title', () => {
    render(<RecordSummaryPanel record={record} />);
    expect(screen.getByText('AI 记录总结')).toBeInTheDocument();
  });

  it('shows generate button for creator', () => {
    render(<RecordSummaryPanel record={record} />);
    expect(screen.getByText('生成总结')).toBeInTheDocument();
  });

  it('does not show generate button for non-creator', () => {
    render(
      <RecordSummaryPanel record={{ ...record, creatorId: 'u2' }} />
    );
    expect(screen.queryByText('生成总结')).toBeNull();
  });

  it('shows empty state for non-creator without artifacts', async () => {
    render(
      <RecordSummaryPanel record={{ ...record, creatorId: 'u2' }} />
    );
    expect(await screen.findByText('尚无记录总结')).toBeInTheDocument();
  });

  it('shows warning when currentRevisionNo is 0', () => {
    render(
      <RecordSummaryPanel record={{ ...record, currentRevisionNo: 0 }} />
    );
    expect(screen.getByText(/尚无正式提交版本/)).toBeInTheDocument();
  });

  it('renders RecordChatPanel', () => {
    render(<RecordSummaryPanel record={record} />);
    expect(screen.getByTestId('chat-panel')).toBeInTheDocument();
  });
});
