package com.bionote.restore.infrastructure.persistence;

import com.bionote.restore.RestoreDtos;
import com.bionote.restore.RestoreJsonCodec;
import com.bionote.restore.RestoreOperationStore;
import com.bionote.revision.RevisionDtos;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("JpaRestoreOperationStore - 恢复操作持久化测试")
class JpaRestoreOperationStoreTest {

    @Mock private RestoreOperationJpaRepository repository;
    @Mock private RestoreJsonCodec json;
    @InjectMocks private JpaRestoreOperationStore store;

    private final UUID recordId = UUID.randomUUID();
    private final UUID operationId = UUID.randomUUID();
    private final UUID revisionId = UUID.randomUUID();
    private final UUID actorId = UUID.randomUUID();
    private final String idemKey = UUID.randomUUID().toString();

    @Nested
    @DisplayName("find - 查找恢复操作")
    class FindTests {

        @Test
        @DisplayName("找到应返回 Stored 对象")
        void shouldReturnStoredWhenFound() {
            var projection = createProjection();
            when(repository.findStored(recordId.toString(), idemKey)).thenReturn(Optional.of(projection));
            var diffSummary = new RevisionDtos.DiffSummary(1, 2, 3, 4, 0, 0);
            when(json.decodeSummary(anyString())).thenReturn(diffSummary);

            var result = store.find(recordId, idemKey);

            assertNotNull(result);
            assertNotNull(result.summary());
            assertEquals(diffSummary, result.summary().diffSummary());
        }

        @Test
        @DisplayName("未找到应返回 null")
        void shouldReturnNullWhenNotFound() {
            when(repository.findStored(recordId.toString(), idemKey)).thenReturn(Optional.empty());

            var result = store.find(recordId, idemKey);

            assertNull(result);
        }
    }

    @Nested
    @DisplayName("append - 追加恢复操作")
    class AppendTests {

        @Test
        @DisplayName("追加成功应调用 saveAndFlush")
        void shouldSaveAndFlushOnAppend() {
            var diffSummary = new RevisionDtos.DiffSummary(0, 0, 1, 5, 0, 0);
            var operation = new RestoreOperationStore.OperationRecord(operationId, recordId, revisionId,
                    actorId, 0L, 1L, "bh", "ah", diffSummary, idemKey, "payload", Instant.now());
            when(json.encode(diffSummary)).thenReturn("{\"added\":0}");

            store.append(operation);

            verify(repository).saveAndFlush(any(RestoreOperationEntity.class));
        }

        @Test
        @DisplayName("追加操作应正确映射实体字段")
        void shouldMapFieldsCorrectly() {
            var diffSummary = new RevisionDtos.DiffSummary(2, 1, 0, 7, 0, 0);
            var operation = new RestoreOperationStore.OperationRecord(operationId, recordId, revisionId,
                    actorId, 10L, 11L, "beforeHash", "afterHash", diffSummary, idemKey, "hash123", Instant.now());
            when(json.encode(diffSummary)).thenReturn("{}");

            store.append(operation);

            verify(repository).saveAndFlush(any(RestoreOperationEntity.class));
        }
    }

    @Nested
    @DisplayName("list - 分页查询")
    class ListTests {

        @Test
        @DisplayName("分页查询应返回 PageSlice")
        void shouldReturnPageSlice() {
            var projection = createProjection();
            var diffSummary = new RevisionDtos.DiffSummary(1, 1, 1, 3, 0, 0);
            Page<RestoreOperationJpaRepository.StoredProjection> page = new PageImpl<>(List.of(projection));
            when(repository.listStored(eq(recordId.toString()), any(PageRequest.class))).thenReturn(page);
            when(json.decodeSummary(anyString())).thenReturn(diffSummary);

            var result = store.list(recordId, 0, 20);

            assertNotNull(result);
            assertEquals(1, result.items().size());
            assertEquals(1L, result.total());
        }

        @Test
        @DisplayName("空结果应返回空列表")
        void shouldReturnEmptyListWhenNoResults() {
            Page<RestoreOperationJpaRepository.StoredProjection> emptyPage = new PageImpl<>(List.of());
            when(repository.listStored(eq(recordId.toString()), any(PageRequest.class))).thenReturn(emptyPage);

            var result = store.list(recordId, 0, 20);

            assertTrue(result.items().isEmpty());
            assertEquals(0L, result.total());
        }
    }

    private RestoreOperationJpaRepository.StoredProjection createProjection() {
        return new RestoreOperationJpaRepository.StoredProjection() {
            public String getId() { return operationId.toString(); }
            public String getRecordId() { return recordId.toString(); }
            public String getSourceRevisionId() { return revisionId.toString(); }
            public int getRevisionNo() { return 1; }
            public String getActorId() { return actorId.toString(); }
            public String getActorName() { return "Alice"; }
            public long getBeforeVersion() { return 0L; }
            public long getAfterVersion() { return 1L; }
            public String getBeforeHash() { return "bh"; }
            public String getAfterHash() { return "ah"; }
            public String getDiffSummaryJson() { return "{}"; }
            public String getPayloadHash() { return "payload"; }
            public Instant getRestoredAt() { return Instant.now(); }
        };
    }
}
