import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import AppLayout from '@/components/layout/AppLayout';

vi.mock('@/components/layout/Sidebar', () => ({
  default: ({ onNavigate }) => (
    <div data-testid="mock-sidebar">
      Sidebar
      {onNavigate && <span data-testid="on-navigate">has-nav</span>}
    </div>
  ),
}));

vi.mock('@/components/layout/TopbarMvp', () => ({
  default: ({ onMenuClick }) => (
    <header data-testid="mock-topbar">
      <button data-testid="menu-btn" onClick={onMenuClick}>Menu</button>
    </header>
  ),
}));

vi.mock('@/hooks/useRecentTracker', () => ({
  default: vi.fn(),
}));

describe('AppLayout', () => {
  const renderWithRouter = (ui) => render(<MemoryRouter>{ui}</MemoryRouter>);

  it('renders sidebar', () => {
    renderWithRouter(<AppLayout />);
    expect(screen.getByTestId('mock-sidebar')).toBeInTheDocument();
  });

  it('renders topbar', () => {
    renderWithRouter(<AppLayout />);
    expect(screen.getByTestId('mock-topbar')).toBeInTheDocument();
  });

  it('renders main content area', () => {
    renderWithRouter(<AppLayout />);
    expect(document.querySelector('main')).toBeInTheDocument();
  });

  it('opens mobile nav on menu click', () => {
    renderWithRouter(<AppLayout />);
    fireEvent.click(screen.getByTestId('menu-btn'));
    // Mobile drawer should be open - we should have two sidebars now
    const sidebars = screen.getAllByTestId('mock-sidebar');
    expect(sidebars.length).toBeGreaterThanOrEqual(1);
  });
});
