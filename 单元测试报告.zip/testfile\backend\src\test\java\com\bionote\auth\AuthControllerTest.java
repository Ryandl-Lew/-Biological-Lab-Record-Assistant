package com.bionote.auth;

import com.bionote.common.ApiException;
import com.bionote.user.UserDtos;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;

import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("AuthController - 认证接口测试")
class AuthControllerTest {

    @Mock private AuthUseCase authUseCase;
    @Mock private Authentication authentication;

    @InjectMocks private AuthController controller;

    private final UUID userId = UUID.randomUUID();
    private final UserDtos.UserView userView = new UserDtos.UserView(userId, "Alice", "alice@example.com",
            null, Instant.now(), null);

    @Nested
    @DisplayName("POST /api/v1/auth/register")
    class RegisterTests {

        @Test
        @DisplayName("注册成功应返回 AuthResult")
        void shouldRegisterSuccessfully() {
            var request = new AuthDtos.RegisterRequest("Alice", "alice@example.com", "password123");
            var result = new AuthDtos.AuthResult("jwt-token", userView);
            when(authUseCase.register(any())).thenReturn(result);

            var response = controller.register(request);

            assertNotNull(response);
            assertEquals("jwt-token", response.getData().accessToken());
            assertEquals("Alice", response.getData().user().displayName());
        }

        @Test
        @DisplayName("邮箱重复注册应返回错误")
        void shouldReturnConflictForDuplicateEmail() {
            var request = new AuthDtos.RegisterRequest("Bob", "bob@example.com", "password123");
            when(authUseCase.register(any())).thenThrow(
                    new ApiException(HttpStatus.CONFLICT, "DUPLICATE_RESOURCE", "该邮箱已注册"));

            assertThrows(ApiException.class, () -> controller.register(request));
        }
    }

    @Nested
    @DisplayName("POST /api/v1/auth/login")
    class LoginTests {

        @Test
        @DisplayName("登录成功应返回 AuthResult")
        void shouldLoginSuccessfully() {
            var request = new AuthDtos.LoginRequest("alice@example.com", "password123");
            var result = new AuthDtos.AuthResult("jwt-login-token", userView);
            when(authUseCase.login(any())).thenReturn(result);

            var response = controller.login(request);

            assertNotNull(response);
            assertEquals("jwt-login-token", response.getData().accessToken());
        }

        @Test
        @DisplayName("凭据无效应返回错误")
        void shouldReturnUnauthorizedForInvalidCredentials() {
            var request = new AuthDtos.LoginRequest("alice@example.com", "wrong");
            when(authUseCase.login(any())).thenThrow(
                    new ApiException(HttpStatus.UNAUTHORIZED, "INVALID_CREDENTIALS", "邮箱或密码错误"));

            assertThrows(ApiException.class, () -> controller.login(request));
        }
    }

    @Nested
    @DisplayName("GET /api/v1/auth/me")
    class MeTests {

        @Test
        @DisplayName("已认证用户应返回用户信息")
        void shouldReturnCurrentUser() {
            when(authentication.getName()).thenReturn(userId.toString());
            when(authUseCase.currentUser(userId)).thenReturn(userView);

            var response = controller.me(authentication);

            assertNotNull(response);
            assertEquals("Alice", response.getData().displayName());
            assertEquals("alice@example.com", response.getData().email());
        }

        @Test
        @DisplayName("用户不存在应返回错误")
        void shouldReturnNotFoundForMissingUser() {
            when(authentication.getName()).thenReturn(userId.toString());
            when(authUseCase.currentUser(userId)).thenThrow(
                    new ApiException(HttpStatus.NOT_FOUND, "RESOURCE_NOT_FOUND", "用户不存在"));

            assertThrows(ApiException.class, () -> controller.me(authentication));
        }

        @Test
        @DisplayName("未认证请求应返回错误")
        void shouldReturnUnauthorizedForAnonymous() {
            when(authentication.getName()).thenReturn("not-a-valid-uuid");
            assertThrows(IllegalArgumentException.class, () -> controller.me(authentication));
        }
    }

    @Nested
    @DisplayName("POST /api/v1/auth/logout")
    class LogoutTests {

        @Test
        @DisplayName("登出应返回 204 No Content")
        void shouldReturnNoContent() {
            var response = controller.logout();
            assertNotNull(response);
            assertEquals(204, response.getStatusCode().value());
        }

        @Test
        @DisplayName("多次登出不影响结果")
        void shouldBeIdempotent() {
            var response1 = controller.logout();
            var response2 = controller.logout();
            assertEquals(204, response1.getStatusCode().value());
            assertEquals(204, response2.getStatusCode().value());
        }
    }
}
