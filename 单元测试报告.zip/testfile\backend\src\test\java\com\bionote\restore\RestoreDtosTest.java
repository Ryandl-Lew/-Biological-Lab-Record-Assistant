package com.bionote.restore;

import com.bionote.revision.RevisionDtos;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("RestoreDtos - DTO 测试")
class RestoreDtosTest {

    @Nested
    @DisplayName("PreviewRequest")
    class PreviewRequestTests {

        @Test
        @DisplayName("应该成功创建 PreviewRequest")
        void shouldCreatePreviewRequest() {
            var request = new RestoreDtos.PreviewRequest(UUID.randomUUID(), 1L, true);
            assertNotNull(request.sourceRevisionId());
            assertEquals(1L, request.expectedRecordVersion());
            assertTrue(request.restoreAttachments());
        }

        @Test
        @DisplayName("restoreAttachments 为 false 时可正常工作")
        void shouldWorkWithRestoreAttachmentsFalse() {
            var request = new RestoreDtos.PreviewRequest(UUID.randomUUID(), 100L, false);
            assertFalse(request.restoreAttachments());
            assertEquals(100L, request.expectedRecordVersion());
        }

        @Test
        @DisplayName("sourceRevisionId 和 expectedRecordVersion 不得为 null")
        void shouldHaveNonNullFields() {
            var request = new RestoreDtos.PreviewRequest(UUID.randomUUID(), 5L, true);
            assertNotNull(request.sourceRevisionId());
            assertNotNull(request.expectedRecordVersion());
        }
    }

    @Nested
    @DisplayName("ExecuteRequest")
    class ExecuteRequestTests {

        @Test
        @DisplayName("应该成功创建 ExecuteRequest")
        void shouldCreateExecuteRequest() {
            var request = new RestoreDtos.ExecuteRequest(UUID.randomUUID(), 3L, true, "preview-token-abc");
            assertNotNull(request.sourceRevisionId());
            assertEquals(3L, request.expectedRecordVersion());
            assertTrue(request.restoreAttachments());
            assertEquals("preview-token-abc", request.previewToken());
        }

        @Test
        @DisplayName("previewToken 不应为空白")
        void shouldHaveNonBlankPreviewToken() {
            var request = new RestoreDtos.ExecuteRequest(UUID.randomUUID(), 1L, false, "token");
            assertEquals("token", request.previewToken());
        }
    }

    @Nested
    @DisplayName("SourceRevision")
    class SourceRevisionTests {

        @Test
        @DisplayName("应该成功创建 SourceRevision")
        void shouldCreateSourceRevision() {
            var id = UUID.randomUUID();
            var sr = new RestoreDtos.SourceRevision(id, 42);
            assertEquals(id, sr.id());
            assertEquals(42, sr.revisionNo());
        }
    }

    @Nested
    @DisplayName("AttachmentPlan")
    class AttachmentPlanTests {

        @Test
        @DisplayName("空计划应该正确创建")
        void shouldCreateEmptyPlan() {
            var plan = new RestoreDtos.AttachmentPlan(List.of(), List.of(), List.of(), Map.of(), List.of());
            assertTrue(plan.activate().isEmpty());
            assertTrue(plan.softDelete().isEmpty());
            assertTrue(plan.keep().isEmpty());
            assertTrue(plan.droppedFileFieldReferences().isEmpty());
            assertTrue(plan.missingPhysicalFiles().isEmpty());
        }

        @Test
        @DisplayName("包含激活列表的计划应该正确创建")
        void shouldCreatePlanWithActivations() {
            var id = UUID.randomUUID();
            var plan = new RestoreDtos.AttachmentPlan(List.of(id), List.of(), List.of(id), Map.of(), List.of());
            assertEquals(1, plan.activate().size());
            assertEquals(id, plan.activate().get(0));
        }
    }

    @Nested
    @DisplayName("Preview")
    class PreviewTests {

        @Test
        @DisplayName("应该成功创建 Preview")
        void shouldCreatePreview() {
            var recordId = UUID.randomUUID();
            var sourceRev = new RestoreDtos.SourceRevision(UUID.randomUUID(), 1);
            var diffSummary = new RevisionDtos.DiffSummary(1, 2, 3, 4, 0, 0);
            var diffResult = new RevisionDtos.DiffResult(recordId, null, null, diffSummary, List.of(), false, List.of(), Instant.now());
            var plan = new RestoreDtos.AttachmentPlan(List.of(), List.of(), List.of(), Map.of(), List.of());
            var preview = new RestoreDtos.Preview(recordId, sourceRev, 5L, "token123", Instant.now().plusSeconds(300),
                    diffResult, plan, List.of("warning1"), Map.of("canExecute", true));

            assertEquals(recordId, preview.recordId());
            assertEquals("token123", preview.previewToken());
            assertEquals(1, preview.warnings().size());
            assertTrue(preview.capabilities().get("canExecute"));
        }
    }

    @Nested
    @DisplayName("OperationSummary")
    class OperationSummaryTests {

        @Test
        @DisplayName("应该成功创建 OperationSummary")
        void shouldCreateOperationSummary() {
            var id = UUID.randomUUID();
            var diffSummary = new RevisionDtos.DiffSummary(1, 0, 2, 5, 1, 0);
            var summary = new RestoreDtos.OperationSummary(id, UUID.randomUUID(), UUID.randomUUID(), 3,
                    UUID.randomUUID(), "Alice", 1L, 2L, "hash1", "hash2", diffSummary, Instant.now());

            assertEquals(id, summary.id());
            assertEquals("Alice", summary.actorName());
            assertEquals(3, summary.sourceRevisionNo());
            assertEquals(2L, summary.afterRecordVersion());
        }
    }

    @Nested
    @DisplayName("Result")
    class ResultTests {

        @Test
        @DisplayName("应该成功创建 Result")
        void shouldCreateResult() {
            var diffSummary = new RevisionDtos.DiffSummary(0, 0, 0, 10, 0, 0);
            var operation = new RestoreDtos.OperationSummary(UUID.randomUUID(), UUID.randomUUID(),
                    UUID.randomUUID(), 1, UUID.randomUUID(), "User", 0L, 1L, "a", "b", diffSummary, Instant.now());

            var result = new RestoreDtos.Result(null, operation);
            assertNotNull(result.operation());
            assertEquals("User", result.operation().actorName());
        }
    }
}
