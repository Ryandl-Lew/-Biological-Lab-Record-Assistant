package com.bionote.template.infrastructure.persistence;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.TestPropertySource;

import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@TestPropertySource(properties = {"spring.flyway.enabled=false", "spring.jpa.hibernate.ddl-auto=update"})
class RecordTemplateJpaRepositoryTest {

    @Autowired
    private RecordTemplateJpaRepository repository;

    @Autowired
    private TestEntityManager entityManager;

    @Test
    void save_shouldPersistEntity() {
        RecordTemplateEntity entity = new RecordTemplateEntity(
                UUID.randomUUID(), UUID.randomUUID(), "保存测试", "保存测试",
                "save-key", "化学", "实验", "测试保存", Instant.now()
        );

        RecordTemplateEntity saved = repository.save(entity);
        entityManager.flush();

        assertNotNull(saved);
        assertNotNull(entityManager.find(RecordTemplateEntity.class, entity.id));
    }

    @Test
    void findById_shouldReturnEntity() {
        UUID id = UUID.randomUUID();
        RecordTemplateEntity entity = new RecordTemplateEntity(
                id, UUID.randomUUID(), "查找测试", "查找测试",
                "find-key", "物理", "力学", "测试查找", Instant.now()
        );
        entityManager.persist(entity);
        entityManager.flush();

        var found = repository.findById(id);

        assertTrue(found.isPresent());
        assertEquals("查找测试", found.get().name);
    }

    @Test
    void existsByActiveNameKey_shouldReturnTrueWhenExists() {
        String key = "exists-test-key";
        RecordTemplateEntity entity = new RecordTemplateEntity(
                UUID.randomUUID(), UUID.randomUUID(), "存在测试", "存在测试",
                key, "生物", "细胞", "测试存在性", Instant.now()
        );
        repository.save(entity);
        entityManager.flush();

        assertTrue(repository.existsByActiveNameKey(key));
    }

    @Test
    void existsByActiveNameKey_shouldReturnFalseWhenNotExists() {
        assertFalse(repository.existsByActiveNameKey("nonexistent-key-" + UUID.randomUUID()));
    }

    @Test
    void save_shouldAssignVersion() {
        RecordTemplateEntity entity = new RecordTemplateEntity(
                UUID.randomUUID(), UUID.randomUUID(), "版本测试", "版本测试",
                "version-key", "化学", "实验", "版本", Instant.now()
        );

        RecordTemplateEntity saved = repository.save(entity);
        entityManager.flush();

        // Version should be 0 initially
        assertEquals(0L, saved.version);

        // Update and check version increments
        saved.update("版本测试2", "版本测试2", "version-key", "化学", "实验", "版本2", Instant.now());
        entityManager.flush();

        RecordTemplateEntity refetched = entityManager.find(RecordTemplateEntity.class, saved.id);
        assertTrue(refetched.version >= 0);
    }
}
