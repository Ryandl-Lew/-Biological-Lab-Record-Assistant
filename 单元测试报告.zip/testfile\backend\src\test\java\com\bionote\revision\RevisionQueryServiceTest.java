package com.bionote.revision;

import com.bionote.common.PagedResponse;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;

@ExtendWith(MockitoExtension.class)
@DisplayName("RevisionQueryService - 修订查询服务测试")
class RevisionQueryServiceTest {

    @Mock private RevisionStore repository;
    @InjectMocks private RevisionQueryService queryService;

    private final UUID actorId = UUID.randomUUID();
    private final UUID recordId = UUID.randomUUID();
    private final UUID revisionId = UUID.randomUUID();

    @Nested
    @DisplayName("list - 分页查询修订摘要")
    class ListTests {

        @Test
        @DisplayName("正常查询应返回分页结果")
        void shouldReturnPagedResult() {
            var page = PagedResponse.of(List.of(), 0, 20, 0L);
            doReturn(page).when(repository).list(actorId, recordId, 0, 20);

            var result = queryService.list(actorId, recordId, 0, 20);

            assertNotNull(result);
            assertEquals(0L, result.meta().totalElements());
        }

        @Test
        @DisplayName("应转发分页参数到 repository")
        void shouldForwardPaginationParams() {
            var page = PagedResponse.of(List.of(), 3, 50, 0L);
            doReturn(page).when(repository).list(actorId, recordId, 3, 50);

            var result = queryService.list(actorId, recordId, 3, 50);

            assertEquals(3, result.meta().page());
            assertEquals(50, result.meta().size());
        }

        @Test
        @DisplayName("repository 异常应向上传播")
        void shouldPropagateRepositoryException() {
            when(repository.list(actorId, recordId, 0, 20))
                    .thenThrow(new RuntimeException("DB error"));

            assertThrows(RuntimeException.class,
                    () -> queryService.list(actorId, recordId, 0, 20));
        }
    }

    @Nested
    @DisplayName("detail - 查询修订详情")
    class DetailTests {

        @Test
        @DisplayName("正常查询应返回详情")
        void shouldReturnDetail() {
            var review = new RevisionDtos.ReviewSummary(UUID.randomUUID(), UUID.randomUUID(),
                    "Reviewer", "APPROVED", null, Instant.now(), Instant.now(), false);
            var detail = new RevisionDtos.RevisionDetail(revisionId, recordId, 1, "R1", 1, null,
                    "hash", actorId, "Alice", Instant.now(), null, review, List.of(), true, false);
            when(repository.detail(actorId, recordId, revisionId)).thenReturn(detail);

            var result = queryService.detail(actorId, recordId, revisionId);

            assertNotNull(result);
            assertEquals(1, result.revisionNo());
            assertEquals("R1", result.label());
        }

        @Test
        @DisplayName("查询不存在的修订应传播异常")
        void shouldPropagateNotFound() {
            when(repository.detail(actorId, recordId, revisionId))
                    .thenThrow(new com.bionote.common.ApiException(org.springframework.http.HttpStatus.NOT_FOUND,
                            "REVISION_NOT_FOUND", "修订不存在"));

            assertThrows(com.bionote.common.ApiException.class,
                    () -> queryService.detail(actorId, recordId, revisionId));
        }
    }

    @Nested
    @DisplayName("legacyDetail - 兼容旧路径查询")
    class LegacyDetailTests {

        @Test
        @DisplayName("正常查询应返回详情 (recordId=null)")
        void shouldReturnLegacyDetail() {
            var review = new RevisionDtos.ReviewSummary(UUID.randomUUID(), UUID.randomUUID(),
                    "Reviewer", "PENDING", null, Instant.now(), null, true);
            var detail = new RevisionDtos.RevisionDetail(revisionId, UUID.randomUUID(), 2, "R2", 1, null,
                    "hash2", actorId, "Bob", Instant.now(), "note", review, List.of(), false, false);
            when(repository.detail(actorId, null, revisionId)).thenReturn(detail);

            var result = queryService.legacyDetail(actorId, revisionId);

            assertNotNull(result);
            assertEquals("Bob", result.submitterName());
            verify(repository).detail(actorId, null, revisionId);
        }
    }
}
