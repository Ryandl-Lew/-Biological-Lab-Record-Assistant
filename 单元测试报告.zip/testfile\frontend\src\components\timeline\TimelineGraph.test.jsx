import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import TimelineGraph from '@/components/timeline/TimelineGraph';
import { buildTimelineGraph, graphNodeLabel, graphNodeContext } from './timelineGraph';

vi.mock('./timelineGraph', () => ({
  buildTimelineGraph: vi.fn(() => ({
    nodes: [
      { id: 'n1', lane: 0, row: 0, events: [{ id: 'e1', eventType: 'RECORD_CREATED', actorName: '张三', createdAt: '2025-01-01T10:00:00Z' }], recordId: 'r1', color: { stroke: '#3b82f6', light: 'bg-blue-50' } },
      { id: 'n2', lane: 0, row: 1, events: [{ id: 'e2', eventType: 'RECORD_UPDATED', actorName: '李四', createdAt: '2025-01-02T10:00:00Z' }], recordId: null, color: { stroke: '#10b981', light: 'bg-emerald-50' } },
    ],
    lanes: [
      { index: 0, segments: [{ fromRow: 0, toRow: 1, color: { stroke: '#3b82f6' } }] },
    ],
    forks: [],
    merges: [],
    totalRows: 2,
  })),
  graphNodeLabel: vi.fn(() => '创建了记录'),
  graphNodeContext: vi.fn(() => null),
}));

describe('TimelineGraph', () => {
  const events = [
    { id: 'e1', eventType: 'RECORD_CREATED', actorId: 'u1', actorName: '张三', createdAt: '2025-01-01T10:00:00Z' },
    { id: 'e2', eventType: 'RECORD_UPDATED', actorId: 'u2', actorName: '李四', createdAt: '2025-01-02T10:00:00Z' },
  ];
  const labels = { RECORD_CREATED: '创建记录', RECORD_UPDATED: '更新记录' };
  const icons = {};
  const members = [
    { userId: 'u1', displayName: '张三' },
    { userId: 'u2', displayName: '李四' },
  ];

  it('renders event nodes', () => {
    render(
      <TimelineGraph
        events={events}
        labels={labels}
        icons={icons}
        members={members}
        onNavigateRecord={vi.fn()}
      />
    );
    expect(screen.getByText('张三')).toBeInTheDocument();
    expect(screen.getByText('李四')).toBeInTheDocument();
  });

  it('renders filter controls', () => {
    render(
      <TimelineGraph
        events={events}
        labels={labels}
        icons={icons}
        members={members}
        onNavigateRecord={vi.fn()}
      />
    );
    expect(screen.getByLabelText('事件类型')).toBeInTheDocument();
    expect(screen.getByLabelText('操作者')).toBeInTheDocument();
  });

  it('shows empty message when no events', () => {
    vi.mocked(buildTimelineGraph).mockReturnValueOnce({
      nodes: [],
      lanes: [],
      forks: [],
      merges: [],
      totalRows: 0,
    });
    render(
      <TimelineGraph
        events={[]}
        labels={labels}
        icons={icons}
        members={members}
        onNavigateRecord={vi.fn()}
        emptyMessage="暂无协作事件"
      />
    );
    expect(screen.getByText('暂无协作事件')).toBeInTheDocument();
  });

  it('renders clear filter button', () => {
    render(
      <TimelineGraph
        events={events}
        labels={labels}
        icons={icons}
        members={members}
        onNavigateRecord={vi.fn()}
      />
    );
    expect(screen.getByText('清除筛选')).toBeInTheDocument();
  });
});
