package com.bionote.project.infrastructure.persistence;

import org.junit.jupiter.api.Test;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class ProjectRecordReadEntityTest {

    @Test
    void shouldHaveAllFields() {
        // ProjectRecordReadEntity is an @Immutable entity, verify it can be created via constructor
        // It only has a default constructor and is read-only
        assertDoesNotThrow(() -> {
            var entity = new ProjectRecordReadEntity();
            assertNull(entity.id);
            assertNull(entity.projectId);
            assertNull(entity.creatorId);
            assertNull(entity.title);
            assertNull(entity.status);
            assertFalse(entity.provisional);
            assertNull(entity.deletedAt);
        });
    }

    @Test
    void shouldDefaultProvisionalToFalse() {
        ProjectRecordReadEntity entity = new ProjectRecordReadEntity();
        assertFalse(entity.provisional);
    }

    @Test
    void shouldHaveNullDeletedAtByDefault() {
        ProjectRecordReadEntity entity = new ProjectRecordReadEntity();
        assertNull(entity.deletedAt);
    }
}
