package com.bionote.record;

import com.bionote.common.ApiException;
import com.bionote.common.PagedResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class RecordControllerTest {

    @Mock private RecordUseCase recordUseCase;
    @Mock private Authentication authentication;

    @InjectMocks private RecordController controller;

    private final UUID userId = UUID.randomUUID();
    private final UUID recordId = UUID.randomUUID();
    private final UUID projectId = UUID.randomUUID();

    @Test
    void shouldListRecords() {
        when(authentication.getName()).thenReturn(userId.toString());
        PagedResponse<RecordDtos.View> page = PagedResponse.of(List.of(), 0, 20, 0);
        when(recordUseCase.list(eq(userId), isNull(), isNull(), isNull(), eq(""), eq(0), eq(20))).thenReturn(page);

        PagedResponse<RecordDtos.View> result = controller.list(authentication, null, null, null, "", 0, 20);

        assertNotNull(result);
        assertEquals(0, result.meta().totalElements());
    }

    @Test
    void shouldCreateRecordSuccessfully() {
        when(authentication.getName()).thenReturn(userId.toString());
        RecordDtos.View view = new RecordDtos.View(
                recordId, "EXP-001", projectId, "项目", UUID.randomUUID(), "创建者",
                "标题", "实验", LocalDate.now(), "目的", "IN_PROGRESS", false,
                Map.of(), Map.of(), Map.of(), "<p></p>", "", 0, null,
                null, 0L, Instant.now(), Instant.now(), Map.of());
        when(recordUseCase.create(eq(userId), any())).thenReturn(view);

        var result = controller.create(authentication,
                new RecordDtos.CreateRequest(projectId, "标题", "实验", LocalDate.of(2024, 1, 1), "目的", null));

        assertNotNull(result);
        assertEquals("标题", result.getData().title());
    }

    @Test
    void shouldGetRecordById() {
        when(authentication.getName()).thenReturn(userId.toString());
        RecordDtos.View view = new RecordDtos.View(
                recordId, "EXP-001", projectId, "项目", UUID.randomUUID(), "创建者",
                "标题", "实验", LocalDate.now(), "目的", "IN_PROGRESS", false,
                Map.of(), Map.of(), Map.of(), "<p></p>", "", 0, null,
                null, 0L, Instant.now(), Instant.now(), Map.of());
        when(recordUseCase.get(eq(userId), eq(recordId))).thenReturn(view);

        var result = controller.get(authentication, recordId);

        assertNotNull(result);
        assertEquals("EXP-001", result.getData().code());
    }

    @Test
    void shouldReturnNotFoundForNonexistentRecord() {
        when(authentication.getName()).thenReturn(userId.toString());
        when(recordUseCase.get(eq(userId), eq(recordId)))
                .thenThrow(new ApiException(HttpStatus.NOT_FOUND, "RESOURCE_NOT_FOUND", "记录不存在"));

        assertThrows(ApiException.class, () -> controller.get(authentication, recordId));
    }

    @Test
    void shouldUpdateRecord() {
        when(authentication.getName()).thenReturn(userId.toString());
        RecordDtos.View view = new RecordDtos.View(
                recordId, "EXP-001", projectId, "项目", UUID.randomUUID(), "创建者",
                "更新后标题", "实验", LocalDate.now(), "目的", "IN_PROGRESS", false,
                Map.of(), Map.of(), Map.of(), "<p></p>", "", 0, null,
                null, 1L, Instant.now(), Instant.now(), Map.of());
        when(recordUseCase.update(eq(userId), eq(recordId), any())).thenReturn(view);

        var result = controller.update(authentication, recordId,
                new RecordDtos.UpdateRequest(0, "更新后标题", "实验", LocalDate.of(2024, 1, 1), "目的", null, null, null));

        assertNotNull(result);
        assertEquals("更新后标题", result.getData().title());
    }

    @Test
    void shouldDeleteRecord() {
        when(authentication.getName()).thenReturn(userId.toString());
        var result = controller.delete(authentication, recordId);
        assertEquals(204, result.getStatusCode().value());
    }

    @Test
    void shouldReserveRecord() {
        when(authentication.getName()).thenReturn(userId.toString());
        RecordDtos.View view = new RecordDtos.View(
                recordId, "EXP-001", projectId, "项目", UUID.randomUUID(), "创建者",
                "未命名记录", "实验", LocalDate.now(), "", "IN_PROGRESS", true,
                Map.of(), Map.of(), Map.of(), "<p></p>", "", 0, null,
                null, 0L, Instant.now(), Instant.now(), Map.of());
        when(recordUseCase.reserve(eq(userId), any())).thenReturn(view);

        var result = controller.reserve(authentication, new RecordDtos.ReserveRequest(projectId));

        assertNotNull(result);
        assertTrue(result.getData().provisional());
    }
}
