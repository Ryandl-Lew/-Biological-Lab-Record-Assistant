import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('./client', () => ({
  request: vi.fn(),
  API_BASE_URL: '/api/v1',
  ApiError: class extends Error {
    constructor(message, code, fieldErrors, status) {
      super(message)
      this.name = 'ApiError'
      this.code = code
      this.fieldErrors = fieldErrors
      this.status = status
    }
  },
}))

import { request, API_BASE_URL } from './client'
import {
  sendRecordAgentChat,
  sendProjectAgentChat,
  uploadProjectAgentReference,
  deleteProjectAgentReference,
} from './agentChat'

describe('agentChat API', () => {
  beforeEach(() => {
    request.mockReset()
    localStorage.clear()
  })

  describe('sendRecordAgentChat', () => {
    it('sends POST /records/:id/agent-chat with input', async () => {
      request.mockResolvedValueOnce({ reply: 'Hello' })
      const result = await sendRecordAgentChat('rec-1', { message: '分析数据' })
      expect(request).toHaveBeenCalledWith('/records/rec-1/agent-chat', {
        method: 'POST',
        body: JSON.stringify({ message: '分析数据' }),
      })
      expect(result).toEqual({ reply: 'Hello' })
    })
  })

  describe('sendProjectAgentChat', () => {
    it('sends POST /projects/:id/agent-chat with input', async () => {
      request.mockResolvedValueOnce({ reply: '项目摘要' })
      await sendProjectAgentChat('proj-1', { message: '总结进度' })
      expect(request).toHaveBeenCalledWith('/projects/proj-1/agent-chat', {
        method: 'POST',
        body: JSON.stringify({ message: '总结进度' }),
      })
    })
  })

  describe('uploadProjectAgentReference', () => {
    it('uploads a file via XHR', async () => {
      const mockXHR = {
        open: vi.fn(),
        setRequestHeader: vi.fn(),
        send: vi.fn(),
        upload: { onprogress: null },
        status: 200,
        responseText: JSON.stringify({ data: { id: 'ref-1' } }),
      }

      const origXHR = globalThis.XMLHttpRequest
      globalThis.XMLHttpRequest = vi.fn(() => mockXHR)

      localStorage.setItem('auth_token', 'token-123')

      const file = new File(['content'], 'test.pdf', { type: 'application/pdf' })
      const onProgress = vi.fn()
      const promise = uploadProjectAgentReference('proj-1', file, onProgress)

      // Trigger onload
      mockXHR.onload()

      const result = await promise
      expect(result).toEqual({ id: 'ref-1' })
      expect(mockXHR.open).toHaveBeenCalledWith('POST', `${API_BASE_URL}/projects/proj-1/agent-chat/references`)
      expect(mockXHR.setRequestHeader).toHaveBeenCalledWith('Accept', 'application/json')
      expect(mockXHR.setRequestHeader).toHaveBeenCalledWith('Authorization', 'Bearer token-123')
      expect(onProgress).toHaveBeenCalledWith(100)

      globalThis.XMLHttpRequest = origXHR
    })
  })

  describe('deleteProjectAgentReference', () => {
    it('sends DELETE /projects/:id/agent-chat/references/:refId', async () => {
      request.mockResolvedValueOnce(null)
      await deleteProjectAgentReference('proj-1', 'ref-1')
      expect(request).toHaveBeenCalledWith('/projects/proj-1/agent-chat/references/ref-1', { method: 'DELETE' })
    })
  })
})
