import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import Surface from '@/components/ui/Surface';

describe('Surface', () => {
  it('renders children', () => {
    render(<Surface><p>内容区域</p></Surface>);
    expect(screen.getByText('内容区域')).toBeInTheDocument();
  });

  it('renders title when provided', () => {
    render(<Surface title="卡片标题"><p>内容</p></Surface>);
    expect(screen.getByText('卡片标题')).toBeInTheDocument();
  });

  it('renders extra area when provided', () => {
    render(
      <Surface title="标题" extra={<button>操作</button>}>
        <p>内容</p>
      </Surface>
    );
    expect(screen.getByRole('button', { name: '操作' })).toBeInTheDocument();
  });

  it('does not render header when no title or extra', () => {
    const { container } = render(<Surface><p>内容</p></Surface>);
    expect(container.querySelector('h2')).toBeNull();
  });

  it('applies custom className', () => {
    const { container } = render(<Surface className="custom-class"><p>内容</p></Surface>);
    expect(container.querySelector('section').className).toContain('custom-class');
  });

  it('applies custom style', () => {
    const { container } = render(<Surface style={{ marginTop: 20 }}><p>内容</p></Surface>);
    expect(container.querySelector('section').style.marginTop).toBe('20px');
  });
});
