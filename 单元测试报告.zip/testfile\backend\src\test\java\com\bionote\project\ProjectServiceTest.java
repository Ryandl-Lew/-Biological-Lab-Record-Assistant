package com.bionote.project;

import com.bionote.collaboration.CollaborationEvents;
import com.bionote.common.ApiException;
import com.bionote.common.PagedResponse;
import com.bionote.review.ReviewAssignmentUseCase;
import com.bionote.user.User;
import com.bionote.user.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ProjectServiceTest {

    @Mock private ProjectStore projects;
    @Mock private ProjectMemberStore members;
    @Mock private ProjectInvitationStore invitations;
    @Mock private UserRepository users;
    @Mock private CollaborationEvents events;
    @Mock private RecordMembershipGuard guard;
    @Mock private ReviewAssignmentUseCase reviewAssignments;

    private ProjectService projectService;
    private final UUID userId = UUID.randomUUID();
    private final UUID projectId = UUID.randomUUID();
    private final Instant now = Instant.now();

    @BeforeEach
    void setUp() {
        projectService = new ProjectService(projects, members, invitations, users,
                events, guard, reviewAssignments);
    }

    @Test
    void shouldCreateProject() {
        doAnswer(inv -> null).when(projects).insert(any());
        doAnswer(inv -> null).when(members).insert(any(), any(), any(), any(), any());
        doAnswer(inv -> null).when(events).audit(any(), any(), any(), any(), any(), any(), any());

        ProjectDtos.CreateProjectRequest request = new ProjectDtos.CreateProjectRequest("新项目", "项目描述", null);
        assertDoesNotThrow(() -> {
            try { projectService.create(userId, request); }
            catch (ApiException e) { /* expected: detail() won't find the project */ }
        });

        verify(projects, atLeastOnce()).insert(any());
    }

    @Test
    void shouldListProjects() {
        ProjectStore.PageSlice pageSlice = new ProjectStore.PageSlice(List.of(), 0L);
        when(projects.searchForMember(any(), any(), any(), anyInt(), anyInt()))
                .thenReturn(pageSlice);

        PagedResponse<ProjectDtos.ProjectView> result = projectService.list(userId, "", null, 0, 20);

        assertNotNull(result);
        assertEquals(0L, result.meta().totalElements());
    }

    @Test
    void shouldListProjectsWithNegativePage() {
        ProjectStore.PageSlice pageSlice = new ProjectStore.PageSlice(List.of(), 0L);
        when(projects.searchForMember(any(), any(), any(), eq(0), eq(10)))
                .thenReturn(pageSlice);

        PagedResponse<ProjectDtos.ProjectView> result = projectService.list(userId, "", null, -1, 10);

        assertEquals(0, result.meta().page());
    }

    @Test
    void shouldGetProjectDetail() {
        ProjectStore.ProjectRecord project = new ProjectStore.ProjectRecord(
                projectId, "项目1", "desc", "detail", "ACTIVE", userId,
                now, now, null, 0L);
        when(projects.findById(projectId)).thenReturn(Optional.of(project));
        when(members.findRole(projectId, userId)).thenReturn(Optional.of("OWNER"));
        when(members.count(projectId)).thenReturn(1L);
        when(projects.recordCount(projectId)).thenReturn(0L);
        doAnswer(inv -> null).when(members).touch(any(), any(), any());

        ProjectDtos.ProjectView result = projectService.detail(userId, projectId);

        assertNotNull(result);
        assertEquals(projectId, result.id());
        assertEquals("OWNER", result.currentUserRole());
    }

    @Test
    void shouldThrowWhenProjectNotFound() {
        when(projects.findById(projectId)).thenReturn(Optional.empty());

        assertThrows(ApiException.class, () -> projectService.detail(userId, projectId));
    }

    @Test
    void shouldThrowWhenNotMember() {
        ProjectStore.ProjectRecord project = new ProjectStore.ProjectRecord(
                projectId, "项目1", "desc", "detail", "ACTIVE", userId,
                now, now, null, 0L);
        when(projects.findById(projectId)).thenReturn(Optional.of(project));
        when(members.findRole(projectId, userId)).thenReturn(Optional.empty());

        ApiException ex = assertThrows(ApiException.class,
                () -> projectService.detail(userId, projectId));
        assertEquals(HttpStatus.NOT_FOUND, ex.status());
    }

    @Test
    void shouldGetMembers() {
        when(members.findRole(projectId, userId)).thenReturn(Optional.of("MEMBER"));
        when(members.list(projectId)).thenReturn(List.of());

        List<ProjectDtos.MemberView> result = projectService.members(userId, projectId);

        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void shouldInviteUser() {
        UUID inviteeId = UUID.randomUUID();
        String inviteeEmail = "invitee@test.com";

        ProjectStore.ProjectRecord project = new ProjectStore.ProjectRecord(
                projectId, "项目", "desc", null, "ACTIVE", userId,
                now, now, null, 0L);

        when(members.findRole(projectId, userId)).thenReturn(Optional.of("OWNER"));
        when(projects.findById(projectId)).thenReturn(Optional.of(project));
        when(users.findByEmailNormalized(inviteeEmail)).thenReturn(Optional.of(
                new User(inviteeId, "被邀请者", inviteeEmail, "hash", now)));
        when(members.exists(projectId, inviteeId)).thenReturn(false);
        doAnswer(inv -> null).when(invitations).expireDueForInvitee(any(), any());
        doAnswer(inv -> null).when(invitations).insert(any());

        ProjectDtos.InviteRequest request = new ProjectDtos.InviteRequest(inviteeEmail);
        assertDoesNotThrow(() -> {
            try { projectService.invite(userId, projectId, request); }
            catch (ApiException e) { /* expected due to mock not returning invitation */ }
        });
    }
}
