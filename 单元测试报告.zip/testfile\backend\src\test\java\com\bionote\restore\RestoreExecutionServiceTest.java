package com.bionote.restore;

import com.bionote.common.ApiException;
import com.bionote.revision.RevisionDtos;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("RestoreExecutionService - 恢复执行服务测试")
class RestoreExecutionServiceTest {

    @Mock private com.bionote.domain.record.RecordActionPolicy policy;
    @Mock private com.bionote.revision.RevisionStore revisions;
    @Mock private com.bionote.record.RecordStore recordStore;
    @Mock private com.bionote.project.ProjectStore projects;
    @Mock private com.bionote.project.ProjectMemberStore members;
    @Mock private com.bionote.attachment.AttachmentStore attachmentStore;
    @Mock private com.bionote.revision.SnapshotNormalizer normalizer;
    @Mock private com.bionote.revision.RevisionDiffUseCase diffs;
    @Mock private AttachmentRestorePlanner attachments;
    @Mock private WorkingCopySnapshotWriter writer;
    @Mock private RestorePreviewTokenService tokens;
    @Mock private RestoreOperationStore operations;
    @Mock private com.bionote.collaboration.event.DomainEventPublisher events;
    @Mock private com.bionote.record.RecordUseCase records;
    @InjectMocks private RestoreExecutionService executionService;

    private final UUID actorId = UUID.randomUUID();
    private final UUID recordId = UUID.randomUUID();
    private final UUID projectId = UUID.randomUUID();
    private final UUID revisionId = UUID.randomUUID();

    @Nested
    @DisplayName("restore - idempotencyKey 验证")
    class IdempotencyKeyTests {

        @Test
        @DisplayName("idempotencyKey 为 null 应抛出 BAD_REQUEST")
        void shouldThrowBadRequestForNullKey() {
            var request = new RestoreDtos.ExecuteRequest(revisionId, 1L, true, "token");
            var ex = assertThrows(ApiException.class, () -> executionService.restore(actorId, recordId, request, null));
            assertEquals("VALIDATION_ERROR", ex.code());
        }

        @Test
        @DisplayName("idempotencyKey 为空字符串应抛出 BAD_REQUEST")
        void shouldThrowBadRequestForBlankKey() {
            var request = new RestoreDtos.ExecuteRequest(revisionId, 1L, true, "token");
            var ex = assertThrows(ApiException.class, () -> executionService.restore(actorId, recordId, request, "   "));
            assertEquals("VALIDATION_ERROR", ex.code());
        }

        @Test
        @DisplayName("idempotencyKey 为非 UUID 格式应抛出 BAD_REQUEST")
        void shouldThrowBadRequestForNonUuidKey() {
            var request = new RestoreDtos.ExecuteRequest(revisionId, 1L, true, "token");
            var ex = assertThrows(ApiException.class, () -> executionService.restore(actorId, recordId, request, "not-a-uuid"));
            assertEquals("VALIDATION_ERROR", ex.code());
        }
    }

    @Nested
    @DisplayName("restore - 幂等返回")
    class IdempotentReturnTests {

        @Test
        @DisplayName("幂等 key 已存在且同一用户应返回已有结果")
        void shouldReturnExistingResultForSameUser() {
            var idemKey = UUID.randomUUID().toString();
            var request = new RestoreDtos.ExecuteRequest(revisionId, 1L, true, "token");
            String expectedHash = hash(recordId + "|" + revisionId + "|1|true");
            var summary = new RestoreDtos.OperationSummary(UUID.randomUUID(), recordId, revisionId, 1,
                    actorId, "Alice", 0L, 1L, "bh", "ah",
                    new RevisionDtos.DiffSummary(0, 0, 0, 5, 0, 0), Instant.now());
            var stored = new RestoreOperationStore.Stored(summary, expectedHash);
            when(operations.find(recordId, idemKey)).thenReturn(stored);
            when(records.get(eq(actorId), eq(recordId))).thenReturn(null);

            var result = executionService.restore(actorId, recordId, request, idemKey);

            assertNotNull(result);
            assertEquals(summary, result.operation());
        }

        @Test
        @DisplayName("幂等 key 属于不同用户应抛出 NOT_FOUND")
        void shouldThrowNotFoundForDifferentUser() {
            var idemKey = UUID.randomUUID().toString();
            var request = new RestoreDtos.ExecuteRequest(revisionId, 1L, true, "token");
            String expectedHash = hash(recordId + "|" + revisionId + "|1|true");
            var otherUserId = UUID.randomUUID();
            var summary = new RestoreDtos.OperationSummary(UUID.randomUUID(), recordId, revisionId, 1,
                    otherUserId, "Bob", 0L, 1L, "bh", "ah",
                    new RevisionDtos.DiffSummary(0, 0, 0, 5, 0, 0), Instant.now());
            var stored = new RestoreOperationStore.Stored(summary, expectedHash);
            when(operations.find(recordId, idemKey)).thenReturn(stored);

            var ex = assertThrows(ApiException.class, () -> executionService.restore(actorId, recordId, request, idemKey));
            assertEquals(HttpStatus.NOT_FOUND, ex.status());
        }
    }

    @Nested
    @DisplayName("restore - record 查找失败")
    class RecordLookupTests {

        @Test
        @DisplayName("记录不存在应抛出 NOT_FOUND")
        void shouldThrowNotFoundForMissingRecord() {
            var idemKey = UUID.randomUUID().toString();
            var request = new RestoreDtos.ExecuteRequest(revisionId, 1L, true, "token");
            when(operations.find(recordId, idemKey)).thenReturn(null);

            var claims = new RestorePreviewTokenService.Claims(actorId, recordId, projectId, revisionId,
                    1L, true, "hash1", "hash2", Instant.now().plusSeconds(300), UUID.randomUUID());
            when(tokens.verify("token")).thenReturn(claims);
            when(recordStore.findActiveForUpdate(recordId)).thenReturn(Optional.empty());

            var ex = assertThrows(ApiException.class, () -> executionService.restore(actorId, recordId, request, idemKey));
            assertEquals(HttpStatus.NOT_FOUND, ex.status());
        }
    }

    private static String hash(String input) {
        try {
            return java.util.HexFormat.of().formatHex(
                    MessageDigest.getInstance("SHA-256").digest(input.getBytes(StandardCharsets.UTF_8)));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}
