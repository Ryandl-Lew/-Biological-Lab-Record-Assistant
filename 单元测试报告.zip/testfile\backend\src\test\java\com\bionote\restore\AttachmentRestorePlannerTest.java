package com.bionote.restore;

import com.bionote.attachment.AttachmentStorage;
import com.bionote.attachment.AttachmentStore;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("AttachmentRestorePlanner - 附件恢复计划器测试")
class AttachmentRestorePlannerTest {

    @Mock private AttachmentStore attachments;
    @Mock private AttachmentStorage storage;
    @InjectMocks private AttachmentRestorePlanner planner;

    private final UUID recordId = UUID.randomUUID();
    private final UUID revisionId = UUID.randomUUID();

    @Nested
    @DisplayName("plan - 生成附件计划")
    class PlanTests {

        @Test
        @DisplayName("无附件时应返回空计划")
        void shouldReturnEmptyPlanWhenNoAttachments() {
            when(attachments.findAllByRecord(recordId)).thenReturn(List.of());
            when(attachments.findByRevision(revisionId)).thenReturn(List.of());

            var result = planner.plan(recordId, revisionId, snapshotMap(), true);

            assertNotNull(result);
            assertTrue(result.dto().activate().isEmpty());
            assertTrue(result.dto().softDelete().isEmpty());
            assertTrue(result.dto().keep().isEmpty());
        }

        @Test
        @DisplayName("恢复附件时应正确计算激活/软删除/保留列表")
        void shouldPlanActivationAndDeletion() {
            var id1 = UUID.randomUUID();
            var id2 = UUID.randomUUID();
            var id3 = UUID.randomUUID();

            when(attachments.findAllByRecord(recordId)).thenReturn(List.of(
                    attachment(id1, "a.pdf", false),
                    attachment(id2, "b.pdf", true)));
            when(attachments.findByRevision(revisionId)).thenReturn(List.of(
                    attachment(id2, "b.pdf", false),
                    attachment(id1, "a.pdf", false),
                    attachment(id3, "c.pdf", false)));
            when(storage.exists(any())).thenReturn(true);

            var result = planner.plan(recordId, revisionId, snapshotMap(), true);

            // id1 and id2 are in both: keep; id3 is in source but not active: activate
            assertEquals(1, result.dto().activate().size()); // id3
            assertEquals(0, result.dto().softDelete().size());
            assertEquals(2, result.dto().keep().size()); // id1, id2
        }

        @Test
        @DisplayName("不恢复附件时应保持当前活动附件")
        void shouldKeepActiveWhenNotRestoringAttachments() {
            var id1 = UUID.randomUUID();
            var id2 = UUID.randomUUID();

            when(attachments.findAllByRecord(recordId)).thenReturn(List.of(
                    attachment(id1, "a.pdf", false),
                    attachment(id2, "b.pdf", false)));
            when(attachments.findByRevision(revisionId)).thenReturn(List.of(
                    attachment(id1, "a.pdf", false)));

            var result = planner.plan(recordId, revisionId, snapshotMap(), false);

            assertTrue(result.dto().activate().isEmpty());
            assertTrue(result.dto().softDelete().isEmpty());
            assertEquals(2, result.dto().keep().size());
        }

        @Test
        @DisplayName("物理文件缺失应被检测")
        void shouldDetectMissingPhysicalFiles() {
            var id1 = UUID.randomUUID();
            when(attachments.findAllByRecord(recordId)).thenReturn(List.of(
                    attachment(id1, "a.pdf", false)));
            when(attachments.findByRevision(revisionId)).thenReturn(List.of(
                    attachment(id1, "a.pdf", false)));
            when(storage.exists(any())).thenReturn(false);

            var result = planner.plan(recordId, revisionId, snapshotMap(), true);

            assertFalse(result.dto().missingPhysicalFiles().isEmpty());
            assertTrue(result.dto().missingPhysicalFiles().contains(id1));
        }
    }

    private AttachmentStore.AttachmentRecord attachment(UUID id, String name, boolean deleted) {
        return new AttachmentStore.AttachmentRecord(id, recordId, UUID.randomUUID(), name,
                "storage-key-" + id, "application/pdf", 1024L, true, Instant.now(),
                deleted ? Instant.now() : null);
    }

    private Map<String, Object> snapshotMap() {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("templateSnapshot", Map.of());
        map.put("fieldValues", Map.of());
        return map;
    }
}
