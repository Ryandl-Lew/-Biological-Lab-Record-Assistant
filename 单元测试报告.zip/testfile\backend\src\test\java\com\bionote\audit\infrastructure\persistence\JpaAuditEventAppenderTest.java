package com.bionote.audit.infrastructure.persistence;

import com.bionote.audit.AuditJsonCodec;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;
import org.springframework.test.context.TestPropertySource;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@Import({JpaAuditEventAppender.class, AuditJsonCodec.class})
@TestPropertySource(properties = {"spring.flyway.enabled=false", "spring.jpa.hibernate.ddl-auto=update"})
@DisplayName("JpaAuditEventAppender 测试")
class JpaAuditEventAppenderTest {

    @Autowired
    private AuditEventJpaRepository repository;

    @Autowired
    private JpaAuditEventAppender appender;

    @Test
    @DisplayName("append 应成功保存审计事件")
    void shouldAppendEvent() {
        UUID eventId = UUID.randomUUID();
        UUID actorId = UUID.randomUUID();
        UUID projectId = UUID.randomUUID();
        UUID recordId = UUID.randomUUID();
        Instant now = Instant.now();

        assertDoesNotThrow(() ->
                appender.append(eventId, actorId, projectId, recordId, "RECORD_CREATED",
                        "RECORD", recordId, Map.of("name", "test"), now));

        var found = repository.findById(eventId);
        assertTrue(found.isPresent());
        assertEquals("RECORD_CREATED", found.get().eventType);
        assertEquals("RECORD", found.get().targetType);
    }

    @Test
    @DisplayName("appendOnce 应保存不重复的事件")
    void shouldAppendOnceWithoutDuplicate() {
        UUID eventId = UUID.randomUUID();
        UUID actorId = UUID.randomUUID();
        UUID projectId = UUID.randomUUID();
        Instant now = Instant.now();

        appender.appendOnce(eventId, actorId, projectId, null, "PROJECT_CREATED",
                "PROJECT", projectId, Map.of("name", "p1"), now);

        var found = repository.findById(eventId);
        assertTrue(found.isPresent());
        assertEquals("PROJECT_CREATED", found.get().eventType);
    }

    @Test
    @DisplayName("元数据为空的 append 应正常工作")
    void shouldAppendEventWithEmptyMetadata() {
        UUID eventId = UUID.randomUUID();
        UUID actorId = UUID.randomUUID();
        Instant now = Instant.now();

        appender.append(eventId, actorId, UUID.randomUUID(), null,
                "RECORD_DELETED", "RECORD", UUID.randomUUID(), Map.of(), now);

        var found = repository.findById(eventId);
        assertTrue(found.isPresent());
        assertEquals("RECORD_DELETED", found.get().eventType);
    }
}
