import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { API_BASE_URL, ApiError, request } from './client'

describe('client', () => {
  beforeEach(() => {
    localStorage.clear()
    globalThis.fetch = vi.fn()
  })

  describe('API_BASE_URL', () => {
    it('is defined as a string', () => {
      expect(typeof API_BASE_URL).toBe('string')
    })

    it('starts with /api', () => {
      expect(API_BASE_URL.startsWith('/api')).toBe(true)
    })
  })

  describe('ApiError', () => {
    it('creates an error with correct name and fields', () => {
      const err = new ApiError('错误消息', 'ERROR_CODE', { field: 'msg' }, 400)
      expect(err).toBeInstanceOf(Error)
      expect(err.name).toBe('ApiError')
      expect(err.message).toBe('错误消息')
      expect(err.code).toBe('ERROR_CODE')
      expect(err.fieldErrors).toEqual({ field: 'msg' })
      expect(err.status).toBe(400)
    })

    it('creates an error with null fieldErrors', () => {
      const err = new ApiError('网络错误', 'NETWORK_ERROR', null, 0)
      expect(err.fieldErrors).toBeNull()
      expect(err.status).toBe(0)
    })
  })

  describe('request', () => {
    it('sends GET request with correct URL and headers', async () => {
      fetch.mockResolvedValueOnce({
        ok: true,
        status: 200,
        json: async () => ({ data: { id: 1, name: 'test' } }),
      })

      const result = await request('/projects')
      expect(fetch).toHaveBeenCalledWith('/api/v1/projects', expect.objectContaining({
        headers: expect.any(Headers),
      }))
      expect(result).toEqual({ id: 1, name: 'test' })
    })

    it('sends POST request with JSON body and Content-Type', async () => {
      fetch.mockResolvedValueOnce({
        ok: true,
        status: 201,
        json: async () => ({ data: { id: 'new-id' } }),
      })

      const result = await request('/projects', {
        method: 'POST',
        body: JSON.stringify({ name: '新项目' }),
      })
      const [, options] = fetch.mock.calls[0]
      expect(options.method).toBe('POST')
      expect(options.headers.get('Content-Type')).toBe('application/json')
      expect(result).toEqual({ id: 'new-id' })
    })

    it('includes Authorization header when token exists', async () => {
      localStorage.setItem('auth_token', 'test-token-123')
      fetch.mockResolvedValueOnce({
        ok: true,
        status: 200,
        json: async () => ({ data: { id: 1 } }),
      })

      await request('/auth/me')
      const [, options] = fetch.mock.calls[0]
      expect(options.headers.get('Authorization')).toBe('Bearer test-token-123')
    })

    it('does not set Content-Type for FormData body', async () => {
      localStorage.setItem('auth_token', 'token')
      fetch.mockResolvedValueOnce({
        ok: true,
        status: 200,
        json: async () => ({ data: { ok: true } }),
      })

      const formData = new FormData()
      await request('/upload', { method: 'POST', body: formData })
      const [, options] = fetch.mock.calls[0]
      expect(options.headers.has('Content-Type')).toBe(false)
    })

    it('throws ApiError on network failure', async () => {
      fetch.mockRejectedValueOnce(new TypeError('Failed to fetch'))

      await expect(request('/projects')).rejects.toBeInstanceOf(ApiError)
      await expect(request('/projects')).rejects.toMatchObject({
        message: '无法连接服务器，请稍后重试',
        code: 'NETWORK_ERROR',
        status: 0,
      })
    })

    it('throws ApiError on non-ok response', async () => {
      fetch.mockResolvedValueOnce({
        ok: false,
        status: 404,
        json: async () => ({ message: '未找到', code: 'NOT_FOUND' }),
      })

      await expect(request('/projects/999')).rejects.toBeInstanceOf(ApiError)
      await expect(request('/projects/999')).rejects.toMatchObject({
        message: '未找到',
        code: 'NOT_FOUND',
        status: 404,
      })
    })

    it('handles 401 by removing token and dispatching unauthorized event', async () => {
      localStorage.setItem('auth_token', 'expired-token')
      const dispatchSpy = vi.spyOn(window, 'dispatchEvent')

      fetch.mockResolvedValueOnce({
        ok: false,
        status: 401,
        json: async () => ({ message: '未授权', code: 'UNAUTHORIZED' }),
      })

      await expect(request('/auth/me')).rejects.toBeInstanceOf(ApiError)
      expect(localStorage.getItem('auth_token')).toBeNull()
      expect(dispatchSpy).toHaveBeenCalled()
      const event = dispatchSpy.mock.calls.find(c => c[0] instanceof Event && c[0].type === 'bionote:unauthorized')
      expect(event).toBeDefined()
    })

    it('handles blob responseType', async () => {
      const mockBlob = new Blob(['test'], { type: 'text/plain' })
      const mockHeaders = new Headers({ 'Content-Disposition': 'attachment; filename="test.txt"' })
      fetch.mockResolvedValueOnce({
        ok: true,
        status: 200,
        blob: async () => mockBlob,
        headers: mockHeaders,
      })

      const result = await request('/exports/pdf', { responseType: 'blob' })
      expect(result.blob).toBeInstanceOf(Blob)
      expect(result.headers).toBe(mockHeaders)
    })

    it('handles 204 No Content response', async () => {
      fetch.mockResolvedValueOnce({
        ok: true,
        status: 204,
        json: vi.fn(),
      })

      const result = await request('/some-resource', { method: 'DELETE' })
      expect(result).toBeNull()
    })

    it('returns raw data when no meta in payload', async () => {
      fetch.mockResolvedValueOnce({
        ok: true,
        status: 200,
        json: async () => ({ data: [1, 2, 3] }),
      })

      const result = await request('/items')
      expect(result).toEqual([1, 2, 3])
    })

    it('returns { items, meta } when meta exists in payload', async () => {
      fetch.mockResolvedValueOnce({
        ok: true,
        status: 200,
        json: async () => ({
          data: [{ id: 1 }, { id: 2 }],
          meta: { total: 100, page: 1, pageSize: 10 },
        }),
      })

      const result = await request('/items')
      expect(result).toEqual({
        items: [{ id: 1 }, { id: 2 }],
        meta: { total: 100, page: 1, pageSize: 10 },
      })
    })

    it('falls back to generic error message when payload has no message', async () => {
      fetch.mockResolvedValueOnce({
        ok: false,
        status: 500,
        json: async () => ({ code: 'SERVER_ERROR' }),
      })

      await expect(request('/projects')).rejects.toMatchObject({
        message: '请求失败，请稍后重试',
        code: 'SERVER_ERROR',
      })
    })
  })
})
