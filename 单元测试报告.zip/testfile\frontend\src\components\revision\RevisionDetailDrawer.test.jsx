import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import RevisionDetailDrawer from '@/components/revision/RevisionDetailDrawer';

vi.mock('@/components/ui', () => ({
  Button: ({ children, onClick, variant, ref }) => (
    <button onClick={onClick} ref={ref}>{children}</button>
  ),
  StatusBadge: ({ kind, status }) => <span data-testid="status-badge">{kind}:{status}</span>,
}));

describe('RevisionDetailDrawer', () => {
  const detail = {
    id: 'r1',
    label: '版本 v2',
    submitterName: '张三',
    submittedAt: '2025-05-01T10:00:00Z',
    current: true,
    finalRevision: false,
    review: { status: 'pending', reviewerName: null, decisionComment: null },
    snapshot: {
      title: '实验A',
      experimentType: '细胞实验',
      experimentDate: '2025-04-30',
      purpose: '测试细胞活力',
      fieldValues: { key1: 'value1' },
      contentPlainText: '实验正文内容',
    },
    submitNote: '第一次提交',
    attachments: [],
  };

  it('renders null when no detail, loading, or error', () => {
    const { container } = render(
      <RevisionDetailDrawer detail={null} loading={false} error="" onClose={vi.fn()} />
    );
    expect(container.innerHTML).toBe('');
  });

  it('renders content when detail is provided', () => {
    render(<RevisionDetailDrawer detail={detail} loading={false} error="" onClose={vi.fn()} />);
    expect(screen.getByText('版本 v2')).toBeInTheDocument();
  });

  it('renders submitter and date', () => {
    render(<RevisionDetailDrawer detail={detail} loading={false} error="" onClose={vi.fn()} />);
    expect(screen.getByText(/张三/)).toBeInTheDocument();
  });

  it('calls onClose when close button clicked', () => {
    const onClose = vi.fn();
    render(<RevisionDetailDrawer detail={detail} loading={false} error="" onClose={onClose} />);
    fireEvent.click(screen.getByText('关闭'));
    expect(onClose).toHaveBeenCalled();
  });

  it('shows loading state', () => {
    render(<RevisionDetailDrawer detail={null} loading={true} error="" onClose={vi.fn()} />);
    expect(screen.getByText('加载版本详情中…')).toBeInTheDocument();
  });

  it('shows error message', () => {
    render(
      <RevisionDetailDrawer detail={null} loading={false} error="加载失败" onClose={vi.fn()} />
    );
    expect(screen.getByText('加载失败')).toBeInTheDocument();
  });
});
