package com.bionote.review;

import com.bionote.collaboration.CollaborationEvents;
import com.bionote.common.ApiException;
import com.bionote.attachment.AttachmentStore;
import com.bionote.domain.record.Decision;
import com.bionote.domain.record.RecordActionPolicy;
import com.bionote.project.ProjectMemberStore;
import com.bionote.project.ProjectStore;
import com.bionote.record.RecordJsonCodec;
import com.bionote.record.RecordStore;
import com.bionote.revision.RevisionAppender;
import com.bionote.revision.RevisionAttachmentAppender;
import com.bionote.revision.RevisionLookup;
import com.bionote.user.User;
import com.bionote.user.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ReviewServiceTest {

    @Mock private RecordStore records;
    @Mock private ProjectStore projects;
    @Mock private ProjectMemberStore members;
    @Mock private AttachmentStore attachments;
    @Mock private RevisionAppender revisionAppender;
    @Mock private RevisionLookup revisionLookup;
    @Mock private RevisionAttachmentAppender revisionAttachments;
    @Mock private ReviewStore reviews;
    @Mock private UserRepository users;
    @Mock private RecordJsonCodec json;
    @Mock private CollaborationEvents events;
    @Mock private RecordActionPolicy actionPolicy;

    private ReviewService reviewService;
    private final UUID userId = UUID.randomUUID();
    private final UUID recordId = UUID.randomUUID();
    private final UUID projectId = UUID.randomUUID();

    @BeforeEach
    void setUp() {
        reviewService = new ReviewService(records, projects, members, attachments,
                revisionAppender, revisionLookup, revisionAttachments, reviews, users,
                json, events, actionPolicy);
    }

    @Test
    void shouldGetCandidates() {
        RecordStore.RecordData recordData = createRecordData();
        when(records.findActive(recordId)).thenReturn(Optional.of(recordData));
        when(members.exists(projectId, userId)).thenReturn(true);
        when(members.list(projectId)).thenReturn(java.util.List.of());

        var candidates = reviewService.candidates(userId, recordId);
        assertNotNull(candidates);
        assertTrue(candidates.isEmpty());
    }

    @Test
    void shouldThrowWhenRecordNotFoundForCandidates() {
        when(records.findActive(recordId)).thenReturn(Optional.empty());

        ApiException ex = assertThrows(ApiException.class,
                () -> reviewService.candidates(userId, recordId));
        assertEquals(HttpStatus.NOT_FOUND, ex.status());
    }

    @Test
    void shouldGetPendingReviews() {
        when(reviews.pendingForReviewer(userId)).thenReturn(java.util.List.of());

        var pending = reviewService.pending(userId);
        assertNotNull(pending);
        assertTrue(pending.isEmpty());
    }

    @Test
    void shouldThrowWhenApprovingNonOwnReview() {
        UUID reviewId = UUID.randomUUID();
        RecordStore.RecordData recordData = createRecordData();
        when(records.findActiveForUpdate(recordId)).thenReturn(Optional.of(recordData));
        when(reviews.findByIdForUpdate(reviewId))
                .thenReturn(Optional.empty());

        ApiException ex = assertThrows(ApiException.class,
                () -> reviewService.approve(userId, recordId, reviewId, "通过"));
        assertEquals(HttpStatus.NOT_FOUND, ex.status());
    }

    @Test
    void shouldThrowWhenRequestingChangesWithoutComment() {
        ApiException ex = assertThrows(ApiException.class,
                () -> reviewService.requestChanges(userId, recordId, UUID.randomUUID(), null));
        assertEquals(HttpStatus.BAD_REQUEST, ex.status());
    }

    @Test
    void shouldThrowWhenRequestingChangesWithBlankComment() {
        ApiException ex = assertThrows(ApiException.class,
                () -> reviewService.requestChanges(userId, recordId, UUID.randomUUID(), "   "));
        assertEquals(HttpStatus.BAD_REQUEST, ex.status());
    }

    @Test
    void shouldGetRevisions() {
        RecordStore.RecordData recordData = createRecordData();
        when(records.findActive(recordId)).thenReturn(Optional.of(recordData));
        when(members.exists(projectId, userId)).thenReturn(true);
        when(revisionLookup.findIdsByRecordOrderByRevisionNo(recordId))
                .thenReturn(java.util.List.of());

        var revisions = reviewService.revisions(userId, recordId);
        assertNotNull(revisions);
        assertTrue(revisions.isEmpty());
    }

    private RecordStore.RecordData createRecordData() {
        return new RecordStore.RecordData(
                recordId, "EXP-001", projectId, userId, "标题", "实验",
                LocalDate.now(), "目的", "IN_PROGRESS", false,
                "{}", "{}", "{}", "<p></p>", "", 0, null, null,
                0L, Instant.now(), Instant.now(), null);
    }
}
