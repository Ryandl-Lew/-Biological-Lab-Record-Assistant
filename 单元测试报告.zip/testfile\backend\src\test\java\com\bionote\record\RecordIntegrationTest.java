package com.bionote.record;

import com.bionote.record.infrastructure.persistence.ExperimentRecordEntity;
import com.bionote.record.infrastructure.persistence.ExperimentRecordJpaRepository;
import com.bionote.record.infrastructure.persistence.JpaRecordStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;

import java.time.Instant;
import java.time.LocalDate;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@Import(JpaRecordStore.class)
class RecordIntegrationTest {

    @Autowired private ExperimentRecordJpaRepository repository;
    @Autowired private JpaRecordStore recordStore;

    private final UUID recordId = UUID.randomUUID();
    private final UUID projectId = UUID.randomUUID();
    private final UUID creatorId = UUID.randomUUID();

    @BeforeEach
    void setUp() {
        repository.deleteAll();
    }

    @Test
    void shouldInsertAndFindRecord() {
        RecordStore.NewRecord newRecord = new RecordStore.NewRecord(
                recordId, "EXP-001", projectId, creatorId, "标题", "实验类型",
                LocalDate.now(), "目的", false, "{}", "{}", "{}", "", "", Instant.now());
        recordStore.insert(newRecord);

        Optional<RecordStore.RecordData> found = recordStore.findActive(recordId);
        assertTrue(found.isPresent());
        assertEquals("标题", found.get().title());
        assertEquals("IN_PROGRESS", found.get().status());
    }

    @Test
    void shouldReturnEmptyForSoftDeletedRecord() {
        recordStore.insert(new RecordStore.NewRecord(
                recordId, "EXP-001", projectId, creatorId, "标题", "实验",
                LocalDate.now(), "目的", false, "{}", "{}", "{}", "", "", Instant.now()));

        ExperimentRecordEntity entity = repository.findById(recordId).orElseThrow();
        entity.softDelete(Instant.now());
        repository.saveAndFlush(entity);

        Optional<RecordStore.RecordData> found = recordStore.findActive(recordId);
        assertFalse(found.isPresent());
    }

    @Test
    void shouldReturnFalseForUpdateWithWrongVersion() {
        recordStore.insert(new RecordStore.NewRecord(
                recordId, "EXP-001", projectId, creatorId, "标题", "实验",
                LocalDate.now(), "目的", false, "{}", "{}", "{}", "", "", Instant.now()));

        RecordStore.UpdateRecord update = new RecordStore.UpdateRecord(
                "新标题", "类型", LocalDate.now(), "目的",
                "{}", "{}", "", "", false, Instant.now());

        // Wrong version
        boolean result = recordStore.updateWorkingCopy(recordId, 999L, update);
        assertFalse(result);
    }

    @Test
    void shouldDeleteProvisional() {
        recordStore.insert(new RecordStore.NewRecord(
                recordId, "EXP-TMP", projectId, creatorId, "草稿", "实验",
                LocalDate.now(), "", true, "{}", "{}", "{}", "", "", Instant.now()));

        boolean deleted = recordStore.deleteProvisional(recordId, creatorId);
        assertTrue(deleted);

        Optional<RecordStore.RecordData> found = recordStore.findActive(recordId);
        assertFalse(found.isPresent());
    }

    @Test
    void shouldNotDeleteProvisionalWithWrongCreator() {
        recordStore.insert(new RecordStore.NewRecord(
                recordId, "EXP-TMP", projectId, creatorId, "草稿", "实验",
                LocalDate.now(), "", true, "{}", "{}", "{}", "", "", Instant.now()));

        boolean deleted = recordStore.deleteProvisional(recordId, UUID.randomUUID());
        assertFalse(deleted);

        Optional<RecordStore.RecordData> found = recordStore.findActive(recordId);
        assertTrue(found.isPresent());
    }
}
