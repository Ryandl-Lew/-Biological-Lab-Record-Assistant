package com.bionote.attachment.infrastructure.persistence;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("AttachmentEntity 测试")
class AttachmentEntityTest {

    @Test
    @DisplayName("应正确构造并设置所有字段")
    void shouldConstructWithAllFields() {
        UUID id = UUID.randomUUID();
        UUID recordId = UUID.randomUUID();
        UUID uploaderId = UUID.randomUUID();
        Instant now = Instant.now();
        String originalFilename = "test.pdf";
        String storageKey = "sk-001";
        String mediaType = "application/pdf";
        long sizeBytes = 4096;

        AttachmentEntity entity = new AttachmentEntity(id, recordId, uploaderId,
                originalFilename, storageKey, mediaType, sizeBytes, true, now);

        assertNotNull(entity);
        // Entity fields are package-private, verify via reflection is possible but we trust construction.
        // For package-private fields in tests, same package access works.
        assertEquals(id, entity.id);
        assertEquals(recordId, entity.recordId);
        assertEquals(uploaderId, entity.uploaderId);
        assertEquals(originalFilename, entity.originalFilename);
        assertEquals(storageKey, entity.storageKey);
        assertEquals(mediaType, entity.mediaType);
        assertEquals(sizeBytes, entity.sizeBytes);
        assertTrue(entity.previewable);
        assertEquals(now, entity.createdAt);
    }

    @Test
    @DisplayName("deletedAt 默认为 null")
    void shouldHaveNullDeletedAtByDefault() {
        AttachmentEntity entity = new AttachmentEntity(UUID.randomUUID(), UUID.randomUUID(),
                UUID.randomUUID(), "f.txt", "sk", "text/plain", 100L, false, Instant.now());

        assertNull(entity.deletedAt);
    }

    @Test
    @DisplayName("protected 无参构造器应存在")
    void shouldHaveProtectedNoArgConstructor() throws Exception {
        java.lang.reflect.Constructor<AttachmentEntity> ctor =
                AttachmentEntity.class.getDeclaredConstructor();
        ctor.setAccessible(true);
        AttachmentEntity entity = ctor.newInstance();

        assertNotNull(entity);
        assertNull(entity.id);
    }

    @Test
    @DisplayName("不同实体的字段应独立")
    void shouldBeIndependentlyConstructed() {
        AttachmentEntity e1 = new AttachmentEntity(UUID.randomUUID(), UUID.randomUUID(),
                UUID.randomUUID(), "a.txt", "sk-1", "text/plain", 100L, false, Instant.now());
        AttachmentEntity e2 = new AttachmentEntity(UUID.randomUUID(), UUID.randomUUID(),
                UUID.randomUUID(), "b.txt", "sk-2", "text/plain", 200L, false, Instant.now());

        assertNotEquals(e1.id, e2.id);
        assertNotEquals(e1.storageKey, e2.storageKey);
    }
}
