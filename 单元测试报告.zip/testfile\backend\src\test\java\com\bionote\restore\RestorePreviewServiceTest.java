package com.bionote.restore;

import com.bionote.common.ApiException;
import com.bionote.domain.record.Decision;
import com.bionote.domain.record.RecordActionPolicy;
import com.bionote.domain.record.RecordContext;
import com.bionote.project.ProjectMemberStore;
import com.bionote.project.ProjectStore;
import com.bionote.record.RecordStore;
import com.bionote.revision.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.time.Instant;
import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("RestorePreviewService - 恢复预览服务测试")
class RestorePreviewServiceTest {

    @Mock private RecordActionPolicy policy;
    @Mock private RevisionStore revisions;
    @Mock private RecordStore records;
    @Mock private ProjectStore projects;
    @Mock private ProjectMemberStore members;
    @Mock private SnapshotNormalizer normalizer;
    @Mock private RevisionDiffUseCase diffs;
    @Mock private AttachmentRestorePlanner attachments;
    @Mock private WorkingCopySnapshotWriter writer;
    @Mock private RestorePreviewTokenService tokens;
    @InjectMocks private RestorePreviewService previewService;

    private final UUID actorId = UUID.randomUUID();
    private final UUID recordId = UUID.randomUUID();
    private final UUID projectId = UUID.randomUUID();
    private final UUID revisionId = UUID.randomUUID();

    @Nested
    @DisplayName("preview - 预览恢复")
    class PreviewTests {

        @Test
        @DisplayName("预览成功应返回完整 Preview 对象")
        void shouldReturnFullPreview() {
            var request = new RestoreDtos.PreviewRequest(revisionId, 1L, true);
            var record = recordData(1L);
            when(records.findActive(recordId)).thenReturn(Optional.of(record));
            when(members.findRole(projectId, actorId)).thenReturn(Optional.of("OWNER"));
            when(projects.findById(projectId)).thenReturn(Optional.of(projectRecord()));
            when(policy.canRestore(any(RecordContext.class), eq(actorId))).thenReturn(Decision.allow());

            var sourceRef = new RevisionDtos.SnapshotSourceRef("REVISION", revisionId, 1, null, "hash1");
            var sourceRecord = new RevisionStore.SourceRecord(sourceRef, 1, snapshotMap(), List.of(), null, null, null);
            var currentRef = new RevisionDtos.SnapshotSourceRef("WORKING_COPY", null, null, 1L, "hash2");
            var currentRecord = new RevisionStore.SourceRecord(currentRef, 1, snapshotMap(), List.of(), null, null, 1L);
            when(revisions.revisionSource(actorId, recordId, revisionId)).thenReturn(sourceRecord);
            when(revisions.workingCopySource(actorId, recordId)).thenReturn(currentRecord);

            var normalized1 = createSnapshot(sourceRef, "hashA");
            var normalized2 = createSnapshot(currentRef, "hashB");
            lenient().when(normalizer.normalize(sourceRecord)).thenReturn(normalized1);
            lenient().when(normalizer.normalize(currentRecord)).thenReturn(normalized2);
            lenient().when(normalizer.normalize(any())).thenReturn(createSnapshot(sourceRef, "hashC"));

            var plan = new AttachmentRestorePlanner.Plan(
                    new RestoreDtos.AttachmentPlan(List.of(), List.of(), List.of(), Map.of(), List.of()),
                    Set.of(), Set.of());
            when(attachments.plan(eq(recordId), eq(revisionId), anyMap(), eq(true))).thenReturn(plan);

            when(writer.prepare(any(), anyMap(), anySet())).thenReturn(prepared());
            var diffResult = new RevisionDtos.DiffResult(recordId, null, null,
                    new RevisionDtos.DiffSummary(0, 0, 0, 5, 0, 0), List.of(), false, List.of(), Instant.now());
            when(diffs.compareWorkingCopyToRevision(actorId, recordId, revisionId, false)).thenReturn(diffResult);

            var issued = new RestorePreviewTokenService.Issued("token123", Instant.now().plusSeconds(300));
            when(tokens.issue(any(), any(), any(), any(), anyLong(), anyBoolean(), anyString(), anyString())).thenReturn(issued);

            var result = previewService.preview(actorId, recordId, request);

            assertNotNull(result);
            assertEquals(recordId, result.recordId());
            assertEquals("token123", result.previewToken());
            assertNotNull(result.diff());
            assertNotNull(result.attachmentPlan());
        }

        @Test
        @DisplayName("乐观锁版本不匹配应抛出 CONFLICT")
        void shouldThrowConflictOnVersionMismatch() {
            var request = new RestoreDtos.PreviewRequest(revisionId, 1L, true);
            var record = recordData(5L);
            when(records.findActive(recordId)).thenReturn(Optional.of(record));
            when(members.findRole(projectId, actorId)).thenReturn(Optional.of("OWNER"));
            when(projects.findById(projectId)).thenReturn(Optional.of(projectRecord()));
            when(policy.canRestore(any(RecordContext.class), eq(actorId))).thenReturn(Decision.allow());

            var ex = assertThrows(ApiException.class, () -> previewService.preview(actorId, recordId, request));
            assertEquals(HttpStatus.CONFLICT, ex.status());
            assertEquals("OPTIMISTIC_LOCK_CONFLICT", ex.code());
        }

        @Test
        @DisplayName("记录不存在应抛出 NOT_FOUND")
        void shouldThrowNotFoundForMissingRecord() {
            var request = new RestoreDtos.PreviewRequest(revisionId, 1L, true);
            when(records.findActive(recordId)).thenReturn(Optional.empty());

            var ex = assertThrows(ApiException.class, () -> previewService.preview(actorId, recordId, request));
            assertEquals(HttpStatus.NOT_FOUND, ex.status());
        }

        @Test
        @DisplayName("无权限应抛出异常")
        void shouldThrowWhenNotAuthorized() {
            var request = new RestoreDtos.PreviewRequest(revisionId, 1L, true);
            var record = recordData(1L);
            when(records.findActive(recordId)).thenReturn(Optional.of(record));
            when(members.findRole(projectId, actorId)).thenReturn(Optional.of("VIEWER"));
            when(projects.findById(projectId)).thenReturn(Optional.of(projectRecord()));
            when(policy.canRestore(any(RecordContext.class), eq(actorId)))
                    .thenReturn(Decision.deny("ACCESS_DENIED", "无权恢复"));

            var ex = assertThrows(ApiException.class, () -> previewService.preview(actorId, recordId, request));
            assertEquals("ACCESS_DENIED", ex.code());
        }
    }

    @Nested
    @DisplayName("policyException - 策略异常转换")
    class PolicyExceptionTests {

        @Test
        @DisplayName("ACCESS_DENIED 映射到 FORBIDDEN")
        void shouldMapAccessDeniedToForbidden() {
            var ex = RestorePreviewService.policyException(Decision.deny("ACCESS_DENIED", "msg"));
            assertEquals(HttpStatus.FORBIDDEN, ex.status());
        }

        @Test
        @DisplayName("RESOURCE_NOT_FOUND 映射到 NOT_FOUND")
        void shouldMapResourceNotFoundToNotFound() {
            var ex = RestorePreviewService.policyException(Decision.deny("RESOURCE_NOT_FOUND", "msg"));
            assertEquals(HttpStatus.NOT_FOUND, ex.status());
        }

        @Test
        @DisplayName("其他错误码映射到 CONFLICT")
        void shouldMapOtherToConflict() {
            var ex = RestorePreviewService.policyException(Decision.deny("LOCKED", "locked"));
            assertEquals(HttpStatus.CONFLICT, ex.status());
        }
    }

    private RecordStore.RecordData recordData(long version) {
        return new RecordStore.RecordData(recordId, "REC001", projectId, actorId,
                "Test Title", "TYPE", LocalDate.now(), "test purpose",
                "IN_PROGRESS", false, "{}", "{}", "{}", "<p></p>", "",
                0, null, null, version, Instant.now(), Instant.now(), null);
    }

    private ProjectStore.ProjectRecord projectRecord() {
        Instant now = Instant.now();
        return new ProjectStore.ProjectRecord(projectId, "project", "desc", "detail desc", "ACTIVE",
                UUID.randomUUID(), now, now, null, 0L);
    }

    private Map<String, Object> snapshotMap() {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id", recordId);
        map.put("code", "REC001");
        map.put("projectId", projectId);
        map.put("creatorId", actorId);
        map.put("title", "Test");
        map.put("experimentType", "TYPE");
        map.put("experimentDate", "2025-01-01");
        map.put("purpose", "test");
        map.put("templateSnapshot", Map.of());
        map.put("fieldValues", Map.of());
        map.put("contentJson", Map.of());
        map.put("contentHtml", "<p>test</p>");
        return map;
    }

    private NormalizedRecordSnapshot createSnapshot(RevisionDtos.SnapshotSourceRef ref, String hash) {
        return new NormalizedRecordSnapshot(ref, recordId, Map.of(), Map.of(), List.of(), List.of(),
                List.of(), null, hash, List.of());
    }

    private WorkingCopySnapshotWriter.Prepared prepared() {
        return new WorkingCopySnapshotWriter.Prepared("title", "TYPE", java.time.LocalDate.now(),
                "purpose", "{}", "{}", "{}", "<p>test</p>", "test", Map.of());
    }
}
