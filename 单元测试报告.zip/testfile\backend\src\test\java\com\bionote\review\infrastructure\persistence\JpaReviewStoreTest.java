package com.bionote.review.infrastructure.persistence;

import com.bionote.review.ReviewStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JpaReviewStoreTest {

    @Mock private ReviewJpaRepository reviews;

    private JpaReviewStore reviewStore;
    private final UUID reviewId = UUID.randomUUID();
    private final UUID recordId = UUID.randomUUID();
    private final UUID revisionId = UUID.randomUUID();
    private final UUID reviewerId = UUID.randomUUID();
    private final UUID projectId = UUID.randomUUID();

    @BeforeEach
    void setUp() {
        reviewStore = new JpaReviewStore(reviews);
    }

    @Test
    void shouldAppendReview() {
        when(reviews.saveAndFlush(any())).thenReturn(null);
        ReviewStore.ReviewRecord review = new ReviewStore.ReviewRecord(
                reviewId, recordId, revisionId, reviewerId, "PENDING",
                null, Instant.now(), null);

        assertDoesNotThrow(() -> reviewStore.append(review));
        verify(reviews).saveAndFlush(any());
    }

    @Test
    void shouldCheckExistsPending() {
        when(reviews.existsByRecordIdAndStatus(recordId, "PENDING")).thenReturn(true);
        assertTrue(reviewStore.existsPending(recordId));

        when(reviews.existsByRecordIdAndStatus(recordId, "PENDING")).thenReturn(false);
        assertFalse(reviewStore.existsPending(recordId));
    }

    @Test
    void shouldFindByRevisionId() {
        ReviewEntity entity = createReviewEntity();
        when(reviews.findByRevisionId(revisionId)).thenReturn(Optional.of(entity));

        Optional<ReviewStore.ReviewRecord> result = reviewStore.findByRevisionId(revisionId);
        assertTrue(result.isPresent());
        assertEquals(revisionId, result.get().revisionId());
        assertEquals("PENDING", result.get().status());
    }

    @Test
    void shouldReturnEmptyWhenRevisionNotFound() {
        when(reviews.findByRevisionId(revisionId)).thenReturn(Optional.empty());
        Optional<ReviewStore.ReviewRecord> result = reviewStore.findByRevisionId(revisionId);
        assertFalse(result.isPresent());
    }

    @Test
    void shouldFindById() {
        ReviewEntity entity = createReviewEntity();
        when(reviews.findById(reviewId)).thenReturn(Optional.of(entity));

        Optional<ReviewStore.ReviewRecord> result = reviewStore.findById(reviewId);
        assertTrue(result.isPresent());
        assertEquals(reviewId, result.get().id());
    }

    @Test
    void shouldFindByIdForUpdate() {
        ReviewEntity entity = createReviewEntity();
        when(reviews.findByIdForUpdate(reviewId)).thenReturn(Optional.of(entity));

        Optional<ReviewStore.ReviewRecord> result = reviewStore.findByIdForUpdate(reviewId);
        assertTrue(result.isPresent());
    }

    @Test
    void shouldDecidePending() {
        when(reviews.decidePending(eq(reviewId), eq("APPROVED"), any(), any())).thenReturn(1);
        boolean result = reviewStore.decidePending(reviewId, "APPROVED", "通过", Instant.now());
        assertTrue(result);
    }

    @Test
    void shouldReturnFalseWhenDecidePendingFails() {
        when(reviews.decidePending(eq(reviewId), anyString(), any(), any())).thenReturn(0);
        boolean result = reviewStore.decidePending(reviewId, "APPROVED", "通过", Instant.now());
        assertFalse(result);
    }

    @Test
    void shouldGetPendingForReviewer() {
        when(reviews.pendingForReviewer(anyString())).thenReturn(List.of());

        List<ReviewStore.PendingReviewRecord> result = reviewStore.pendingForReviewer(reviewerId);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void shouldGetPendingAssignments() {
        when(reviews.pendingAssignments(anyString(), anyString())).thenReturn(List.of());

        List<ReviewStore.PendingAssignmentRecord> result = reviewStore.pendingAssignments(projectId, reviewerId);
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void shouldReassignPending() {
        UUID nextReviewerId = UUID.randomUUID();
        when(reviews.reassignPending(reviewId, reviewerId, nextReviewerId)).thenReturn(1);

        boolean result = reviewStore.reassignPending(reviewId, reviewerId, nextReviewerId);
        assertTrue(result);
    }

    @Test
    void shouldReturnFalseWhenReassignFails() {
        UUID nextReviewerId = UUID.randomUUID();
        when(reviews.reassignPending(reviewId, reviewerId, nextReviewerId)).thenReturn(0);

        boolean result = reviewStore.reassignPending(reviewId, reviewerId, nextReviewerId);
        assertFalse(result);
    }

    private ReviewEntity createReviewEntity() {
        return new ReviewEntity(reviewId, recordId, revisionId, reviewerId, "PENDING",
                null, Instant.now(), null);
    }
}
