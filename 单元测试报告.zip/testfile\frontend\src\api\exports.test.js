import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('./client', () => ({ request: vi.fn() }))

import { request } from './client'
import { fetchExportPreview, downloadMarkdown, downloadPdf } from './exports'

describe('exports API', () => {
  beforeEach(() => {
    request.mockReset()
  })

  describe('fetchExportPreview', () => {
    it('sends GET /records/:id/exports/preview', async () => {
      request.mockResolvedValueOnce({ sections: [] })
      await fetchExportPreview('rec-1')
      expect(request).toHaveBeenCalledWith('/records/rec-1/exports/preview')
    })
  })

  describe('downloadMarkdown', () => {
    it('sends GET /records/:id/exports/markdown with blob responseType', async () => {
      request.mockResolvedValueOnce({ blob: new Blob(), headers: new Headers() })
      await downloadMarkdown('rec-1')
      expect(request).toHaveBeenCalledWith('/records/rec-1/exports/markdown', { responseType: 'blob' })
    })
  })

  describe('downloadPdf', () => {
    it('sends GET /records/:id/exports/pdf with blob responseType', async () => {
      request.mockResolvedValueOnce({ blob: new Blob(), headers: new Headers() })
      await downloadPdf('rec-1')
      expect(request).toHaveBeenCalledWith('/records/rec-1/exports/pdf', { responseType: 'blob' })
    })
  })
})
