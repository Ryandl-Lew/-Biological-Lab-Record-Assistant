import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest'
import { renderHook } from '@testing-library/react'

const mockTrackVisitByPath = vi.fn()
vi.mock('@/lib/recentTracker', async (importOriginal) => ({
  ...(await importOriginal()),
  trackVisitByPath: mockTrackVisitByPath,
}))

function createMockLocation(pathname) {
  return { pathname, search: '', hash: '', state: null, key: 'default' }
}

describe('useRecentTracker', () => {
  beforeEach(() => {
    vi.resetModules()
    vi.clearAllMocks()
  })

  it('calls trackVisitByPath with current pathname on mount', async () => {
    vi.doMock('react-router-dom', () => ({
      useLocation: () => createMockLocation('/projects/proj-1'),
    }))
    const { default: hook } = await import('./useRecentTracker')
    renderHook(() => hook())
    expect(mockTrackVisitByPath).toHaveBeenCalledWith('/projects/proj-1')
  })

  it('calls trackVisitByPath when location pathname changes', async () => {
    let pathname = '/dashboard'
    vi.doMock('react-router-dom', () => ({
      useLocation: () => createMockLocation(pathname),
    }))
    const { default: hook } = await import('./useRecentTracker')

    const { rerender } = renderHook(() => hook())
    expect(mockTrackVisitByPath).toHaveBeenCalledWith('/dashboard')

    mockTrackVisitByPath.mockClear()
    pathname = '/records/rec-1'
    rerender()

    expect(mockTrackVisitByPath).toHaveBeenCalledWith('/records/rec-1')
  })

  it('does not call trackVisitByPath when pathname stays the same', async () => {
    let pathname = '/projects/proj-1'
    vi.doMock('react-router-dom', () => ({
      useLocation: () => createMockLocation(pathname),
    }))
    const { default: hook } = await import('./useRecentTracker')

    const { rerender } = renderHook(() => hook())
    expect(mockTrackVisitByPath).toHaveBeenCalledTimes(1)

    mockTrackVisitByPath.mockClear()
    rerender()
    expect(mockTrackVisitByPath).not.toHaveBeenCalled()
  })

  it('handles rejected trackVisitByPath gracefully', async () => {
    mockTrackVisitByPath.mockRejectedValueOnce(new Error('Not found'))
    vi.doMock('react-router-dom', () => ({
      useLocation: () => createMockLocation('/records/deleted-id'),
    }))
    const { default: hook } = await import('./useRecentTracker')

    expect(() => renderHook(() => hook())).not.toThrow()
  })
})
