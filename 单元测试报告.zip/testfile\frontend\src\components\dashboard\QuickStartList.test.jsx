import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import QuickStartList from '@/components/dashboard/QuickStartList';

describe('QuickStartList', () => {
  const renderWithRouter = (ui) => render(<MemoryRouter>{ui}</MemoryRouter>);

  it('renders all quick start items', () => {
    renderWithRouter(<QuickStartList />);
    expect(screen.getByText('新建实验记录')).toBeInTheDocument();
    expect(screen.getByText('新建项目')).toBeInTheDocument();
    expect(screen.getByText('全局搜索')).toBeInTheDocument();
  });

  it('renders heading text', () => {
    renderWithRouter(<QuickStartList />);
    expect(screen.getByText('开始')).toBeInTheDocument();
  });

  it('renders keyboard shortcut for search', () => {
    renderWithRouter(<QuickStartList />);
    expect(screen.getByText('⌘K')).toBeInTheDocument();
  });

  it('has correct aria label for nav', () => {
    renderWithRouter(<QuickStartList />);
    expect(screen.getByRole('navigation')).toHaveAttribute('aria-label', '快速开始');
  });
});
