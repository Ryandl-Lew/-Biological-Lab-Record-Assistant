import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import ProgressReportPanel from '@/components/agent/ProgressReportPanel';

vi.mock('@/api', () => ({
  createProjectAgentRun: vi.fn(),
  fetchAgentArtifact: vi.fn(),
  fetchAgentRun: vi.fn(),
  fetchProjectArtifacts: vi.fn(),
}));

vi.mock('@/api/agentTypes', () => ({
  AGENT_ARTIFACT_KIND: { PROJECT_PROGRESS: 'PROJECT_PROGRESS' },
}));

vi.mock('@/components/ui', () => ({
  Button: ({ children, onClick, loading }) => (
    <button onClick={onClick} disabled={loading}>{children}</button>
  ),
  Surface: ({ title, children, extra }) => (
    <section data-testid={`surface-${title}`}>
      <h2>{title}</h2>
      {extra && <div>{extra}</div>}
      {children}
    </section>
  ),
}));

vi.mock('@/components/agent/AgentArtifactView', () => ({
  default: ({ artifact }) => <div data-testid="artifact-view">{artifact?.content?.headline}</div>,
}));

vi.mock('@/components/agent/AgentRunStatus', () => ({
  default: ({ runId, onTrace }) => (
    <div data-testid="run-status" onClick={() => onTrace?.({ id: runId, status: 'RUNNING' })}>
      RunStatus {runId}
    </div>
  ),
}));

vi.mock('@/components/agent/AgentTraceViewer', () => ({
  default: ({ open }) => (open ? <div data-testid="trace-viewer">Trace</div> : null),
}));

vi.mock('@/components/agent/messages', () => ({
  agentErrorMessage: vi.fn(() => '代理错误'),
}));

const { fetchProjectArtifacts } = await import('@/api');

describe('ProgressReportPanel', () => {
  const project = {
    id: 'p1',
    currentUserRole: 'OWNER',
  };

  beforeEach(() => {
    vi.clearAllMocks();
    fetchProjectArtifacts.mockResolvedValue({ items: [] });
  });

  it('renders "智能进展" title', () => {
    render(<ProgressReportPanel project={project} />);
    expect(screen.getByText('智能进展')).toBeInTheDocument();
  });

  it('shows generate button when user is OWNER', () => {
    render(<ProgressReportPanel project={project} />);
    expect(screen.getByText('生成进展报告')).toBeInTheDocument();
  });

  it('does not show generate button for non-owner', () => {
    render(
      <ProgressReportPanel project={{ ...project, currentUserRole: 'MEMBER' }} />
    );
    expect(screen.queryByText('生成进展报告')).toBeNull();
  });

  it('renders date inputs', () => {
    render(<ProgressReportPanel project={project} />);
    expect(screen.getByLabelText('报告开始日期')).toBeInTheDocument();
    expect(screen.getByLabelText('报告结束日期')).toBeInTheDocument();
  });

  it('renders project Q&A link', () => {
    render(<ProgressReportPanel project={project} />);
    expect(screen.getByText(/打开 Agent助手/)).toBeInTheDocument();
  });
});
