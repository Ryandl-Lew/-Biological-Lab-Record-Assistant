package com.bionote.revision;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

/**
 * 单元测试：验证 RevisionController、RevisionQueryService、RevisionDiffEngine
 * 和 SnapshotSourceResolver 的组件协作与端到端流程。
 */
@DisplayName("RevisionIntegrationTest - 修订集成测试")
class RevisionIntegrationTest {

    @Nested
    @DisplayName("端到端数据流")
    class EndToEndDataFlow {

        @Test
        @DisplayName("RevisionSummary 到 RevisionDetail 的 ID 传递")
        void shouldPassIdBetweenSummaryAndDetail() {
            var id = UUID.randomUUID();
            var recordId = UUID.randomUUID();
            var review = new RevisionDtos.ReviewSummary(UUID.randomUUID(), UUID.randomUUID(),
                    "Reviewer", "APPROVED", null, Instant.now(), Instant.now(), false);
            var summary = new RevisionDtos.RevisionSummary(id, recordId, 1, "R1",
                    UUID.randomUUID(), "Alice", Instant.now(), "note", "hash", review, 3, true, false);

            assertNotNull(summary.id());
            assertEquals(recordId, summary.recordId());
            assertEquals("R1", summary.label());
        }

        @Test
        @DisplayName("SnapshotSourceRef 的 WORKING_COPY 和 REVISION 类型区分")
        void shouldDistinguishSourceRefTypes() {
            var revisionRef = new RevisionDtos.SnapshotSourceRef("REVISION",
                    UUID.randomUUID(), 3, null, "hash1");
            var wcRef = new RevisionDtos.SnapshotSourceRef("WORKING_COPY",
                    null, null, 10L, "hash2");

            assertEquals("REVISION", revisionRef.type());
            assertEquals("WORKING_COPY", wcRef.type());
            assertNotNull(revisionRef.revisionId());
            assertNotNull(wcRef.recordVersion());
        }
    }

    @Nested
    @DisplayName("数据结构完整性")
    class DataStructureIntegrity {

        @Test
        @DisplayName("DiffResult 的字段不可变性")
        void shouldHaveImmutableDiffResult() {
            var from = new RevisionDtos.SnapshotSourceRef("REVISION", UUID.randomUUID(), 1, null, "h1");
            var to = new RevisionDtos.SnapshotSourceRef("WORKING_COPY", null, null, 2L, "h2");
            var summary = new RevisionDtos.DiffSummary(1, 0, 2, 3, 0, 0);
            var section = new RevisionDtos.DiffSection("key", "Label", "fixed", "text",
                    "MODIFIED", "old", "new", List.of(), Map.of());
            var result = new RevisionDtos.DiffResult(UUID.randomUUID(), from, to, summary,
                    List.of(section), false, List.of(), Instant.now());

            assertEquals(1, result.sections().size());
            assertEquals("MODIFIED", result.sections().get(0).status());
        }
    }

    @Nested
    @DisplayName("边界条件")
    class EdgeCases {

        @Test
        @DisplayName("空的 DiffResult section 列表")
        void shouldHandleEmptySections() {
            var summary = new RevisionDtos.DiffSummary(0, 0, 0, 0, 0, 0);
            var result = new RevisionDtos.DiffResult(UUID.randomUUID(), null, null, summary,
                    List.of(), false, List.of(), Instant.now());

            assertTrue(result.sections().isEmpty());
            assertEquals(0, result.summary().unchanged());
        }

        @Test
        @DisplayName("TextOperation 的类型完整性")
        void shouldMaintainTextOperationIntegrity() {
            var insert = new RevisionDtos.TextOperation("INSERT", "new text");
            var delete = new RevisionDtos.TextOperation("DELETE", "old text");
            var equal = new RevisionDtos.TextOperation("EQUAL", "same text");

            assertEquals("INSERT", insert.operation());
            assertEquals("DELETE", delete.operation());
            assertEquals("EQUAL", equal.operation());
        }

        @Test
        @DisplayName("DiffSummary 的全零值")
        void shouldHandleAllZeroSummary() {
            var summary = new RevisionDtos.DiffSummary(0, 0, 0, 0, 0, 0);
            assertEquals(0, summary.added() + summary.removed() + summary.modified());
        }
    }
}
