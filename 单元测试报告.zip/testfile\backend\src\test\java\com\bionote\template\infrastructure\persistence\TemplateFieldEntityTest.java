package com.bionote.template.infrastructure.persistence;

import org.junit.jupiter.api.Test;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class TemplateFieldEntityTest {

    private static final UUID ID = UUID.randomUUID();
    private static final UUID TEMPLATE_ID = UUID.randomUUID();

    @Test
    void constructor_shouldInitializeAllFields() {
        TemplateFieldEntity entity = new TemplateFieldEntity(
                ID, TEMPLATE_ID, "temperature", "Temperature", "NUMBER",
                true, 0, "Enter temperature", "25.0", null
        );

        assertEquals(ID, entity.id);
        assertEquals(TEMPLATE_ID, entity.templateId);
        assertEquals("temperature", entity.fieldKey);
        assertEquals("Temperature", entity.label);
        assertEquals("NUMBER", entity.fieldType);
        assertTrue(entity.required);
        assertEquals(0, entity.sortOrder);
        assertEquals("Enter temperature", entity.placeholder);
        assertEquals("25.0", entity.defaultValueJson);
        assertNull(entity.optionsJson);
    }

    @Test
    void constructor_withSelectType_shouldHaveOptions() {
        TemplateFieldEntity entity = new TemplateFieldEntity(
                ID, TEMPLATE_ID, "method", "Method", "SELECT",
                true, 1, "Choose method", null, "[\"A\",\"B\",\"C\"]"
        );

        assertEquals("SELECT", entity.fieldType);
        assertEquals("[\"A\",\"B\",\"C\"]", entity.optionsJson);
        assertNull(entity.defaultValueJson);
    }

    @Test
    void protectedConstructor_shouldCreateEmptyEntity() {
        try {
            var constructor = TemplateFieldEntity.class.getDeclaredConstructor();
            constructor.setAccessible(true);
            TemplateFieldEntity entity = constructor.newInstance();

            assertNotNull(entity);
            assertNull(entity.id);
            assertNull(entity.templateId);
            assertFalse(entity.required);
            assertEquals(0, entity.sortOrder);
        } catch (Exception e) {
            fail("Should create entity via protected constructor: " + e.getMessage());
        }
    }

    @Test
    void entityShouldHaveTableAnnotation() {
        var tableAnnotation = TemplateFieldEntity.class.getAnnotation(jakarta.persistence.Table.class);
        assertNotNull(tableAnnotation);
        assertEquals("template_fields", tableAnnotation.name());
    }

    @Test
    void entityShouldHaveEntityAnnotation() {
        var entityAnnotation = TemplateFieldEntity.class.getAnnotation(jakarta.persistence.Entity.class);
        assertNotNull(entityAnnotation);
    }

    @Test
    void columnAnnotationsShouldBePresent() throws Exception {
        var templateIdField = TemplateFieldEntity.class.getDeclaredField("templateId");
        var column = templateIdField.getAnnotation(jakarta.persistence.Column.class);
        assertNotNull(column);
        assertEquals("template_id", column.name());
        assertFalse(column.nullable());
    }
}
