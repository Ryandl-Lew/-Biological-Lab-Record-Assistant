import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('./client', () => ({
  request: vi.fn(),
  API_BASE_URL: '/api/v1',
  ApiError: class extends Error {
    constructor(message, code, fieldErrors, status) {
      super(message)
      this.name = 'ApiError'
      this.code = code
      this.fieldErrors = fieldErrors
      this.status = status
    }
  },
}))

import { request } from './client'
import {
  fetchAttachments,
  fetchRevisionAttachments,
  deleteAttachment,
  previewAttachment,
  downloadAttachment,
  uploadAttachment,
  saveBlob,
} from './attachments'

describe('attachments API', () => {
  beforeEach(() => {
    request.mockReset()
    localStorage.clear()
  })

  describe('fetchAttachments', () => {
    it('sends GET /records/:id/attachments', async () => {
      request.mockResolvedValueOnce([{ id: 'att-1', name: 'file.pdf' }])
      const result = await fetchAttachments('rec-1')
      expect(request).toHaveBeenCalledWith('/records/rec-1/attachments')
      expect(result).toEqual([{ id: 'att-1', name: 'file.pdf' }])
    })
  })

  describe('fetchRevisionAttachments', () => {
    it('sends GET /revisions/:id/attachments', async () => {
      request.mockResolvedValueOnce([])
      await fetchRevisionAttachments('rev-1')
      expect(request).toHaveBeenCalledWith('/revisions/rev-1/attachments')
    })
  })

  describe('deleteAttachment', () => {
    it('sends DELETE /attachments/:id', async () => {
      request.mockResolvedValueOnce(null)
      await deleteAttachment('att-1')
      expect(request).toHaveBeenCalledWith('/attachments/att-1', { method: 'DELETE' })
    })
  })

  describe('previewAttachment', () => {
    it('sends GET /attachments/:id/preview with blob responseType', async () => {
      request.mockResolvedValueOnce({ blob: new Blob(), headers: new Headers() })
      await previewAttachment('att-1')
      expect(request).toHaveBeenCalledWith('/attachments/att-1/preview', { responseType: 'blob' })
    })
  })

  describe('downloadAttachment', () => {
    it('sends GET /attachments/:id/download with blob responseType', async () => {
      request.mockResolvedValueOnce({ blob: new Blob(), headers: new Headers() })
      await downloadAttachment('att-1')
      expect(request).toHaveBeenCalledWith('/attachments/att-1/download', { responseType: 'blob' })
    })
  })

  describe('uploadAttachment', () => {
    it('uploads a file via XHR and resolves with response data', async () => {
      const mockXHR = {
        open: vi.fn(),
        setRequestHeader: vi.fn(),
        send: vi.fn(),
        upload: { onprogress: null },
        status: 200,
        responseText: JSON.stringify({ data: { id: 'att-1', name: 'file.pdf' } }),
      }

      const origXHR = globalThis.XMLHttpRequest
      globalThis.XMLHttpRequest = vi.fn(() => mockXHR)

      localStorage.setItem('auth_token', 'token-123')

      const file = new File(['content'], 'test.pdf')
      const onProgress = vi.fn()
      const promise = uploadAttachment('rec-1', file, onProgress)

      mockXHR.onload()

      const result = await promise
      expect(result).toEqual({ id: 'att-1', name: 'file.pdf' })
      expect(mockXHR.open).toHaveBeenCalledWith('POST', '/api/v1/records/rec-1/attachments')
      expect(onProgress).toHaveBeenCalledWith(100)

      globalThis.XMLHttpRequest = origXHR
    })
  })

  describe('saveBlob', () => {
    it('creates a download link and triggers click', () => {
      const blob = new Blob(['data'], { type: 'text/plain' })
      const headers = new Headers()
      const createObjectURL = vi.fn().mockReturnValue('blob:test-url')
      const revokeObjectURL = vi.fn()
      const appendChild = vi.fn()
      const remove = vi.fn()
      const click = vi.fn()

      const origCreateObjectURL = URL.createObjectURL
      const origRevokeObjectURL = URL.revokeObjectURL
      const origCreateElement = document.createElement
      const origAppendChild = document.body.appendChild

      URL.createObjectURL = createObjectURL
      URL.revokeObjectURL = revokeObjectURL

      const anchor = {
        href: '',
        download: '',
        click,
        remove,
        setAttribute: vi.fn(),
      }

      document.createElement = vi.fn().mockReturnValue(anchor)
      document.body.appendChild = appendChild

      saveBlob(blob, headers, 'download.pdf')

      expect(createObjectURL).toHaveBeenCalledWith(blob)
      expect(anchor.download).toBe('download.pdf')
      expect(anchor.href).toBe('blob:test-url')
      expect(appendChild).toHaveBeenCalledWith(anchor)
      expect(click).toHaveBeenCalled()
      expect(remove).toHaveBeenCalled()

      URL.createObjectURL = origCreateObjectURL
      URL.revokeObjectURL = origRevokeObjectURL
      document.createElement = origCreateElement
      document.body.appendChild = origAppendChild
    })
  })
})
