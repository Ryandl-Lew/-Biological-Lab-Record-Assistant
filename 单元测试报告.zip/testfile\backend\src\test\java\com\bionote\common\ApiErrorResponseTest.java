package com.bionote.common;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("ApiErrorResponse 记录测试")
class ApiErrorResponseTest {

    @Test
    @DisplayName("应正确构造并读取所有字段")
    void shouldConstructAndReadAllFields() {
        Instant now = Instant.now();
        Map<String, String> fieldErrors = Map.of("email", "格式不正确");
        ApiErrorResponse response = new ApiErrorResponse(now, 400, "VALIDATION_ERROR",
                "请求参数无效", fieldErrors, "trace-123");

        assertAll(
                () -> assertEquals(now, response.timestamp()),
                () -> assertEquals(400, response.status()),
                () -> assertEquals("VALIDATION_ERROR", response.code()),
                () -> assertEquals("请求参数无效", response.message()),
                () -> assertEquals(fieldErrors, response.fieldErrors()),
                () -> assertEquals("trace-123", response.traceId())
        );
    }

    @Test
    @DisplayName("fieldErrors 为空 Map 时应正常工作")
    void shouldWorkWithEmptyFieldErrors() {
        ApiErrorResponse response = new ApiErrorResponse(Instant.now(), 500, "INTERNAL_ERROR",
                "服务器错误", Map.of(), "trace-456");

        assertNotNull(response.fieldErrors());
        assertTrue(response.fieldErrors().isEmpty());
    }

    @Test
    @DisplayName("相同值的两个记录应相等")
    void shouldBeEqualWhenSameValues() {
        Instant now = Instant.now();
        ApiErrorResponse r1 = new ApiErrorResponse(now, 404, "NOT_FOUND", "未找到", Map.of(), "t1");
        ApiErrorResponse r2 = new ApiErrorResponse(now, 404, "NOT_FOUND", "未找到", Map.of(), "t1");

        assertEquals(r1, r2);
        assertEquals(r1.hashCode(), r2.hashCode());
    }

    @Test
    @DisplayName("不同值的记录应不相等")
    void shouldNotBeEqualWhenDifferentValues() {
        ApiErrorResponse r1 = new ApiErrorResponse(Instant.now(), 400, "ERR", "msg", Map.of(), "t1");
        ApiErrorResponse r2 = new ApiErrorResponse(Instant.now(), 500, "ERR2", "msg2", Map.of(), "t2");

        assertNotEquals(r1, r2);
    }
}
