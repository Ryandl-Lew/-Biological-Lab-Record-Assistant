package com.bionote.record;

import com.bionote.attachment.AttachmentStorage;
import com.bionote.attachment.AttachmentStore;
import com.bionote.collaboration.CollaborationEvents;
import com.bionote.common.ApiException;
import com.bionote.common.PagedResponse;
import com.bionote.domain.record.RecordActionPolicy;
import com.bionote.domain.record.Decision;
import com.bionote.domain.record.RecordContext;
import com.bionote.project.ProjectMemberStore;
import com.bionote.project.ProjectStore;
import com.bionote.template.TemplateUseCase;
import com.bionote.user.UserRepository;
import com.bionote.user.User;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RecordServiceTest {

    @Mock private RecordStore records;
    @Mock private AttachmentStore attachments;
    @Mock private RecordRevisionDisplayReader revisions;
    @Mock private RecordJsonCodec json;
    @Mock private TemplateUseCase templates;
    @Mock private ProjectStore projects;
    @Mock private ProjectMemberStore members;
    @Mock private UserRepository users;
    @Mock private CollaborationEvents events;
    @Mock private AttachmentStorage storage;
    @Mock private RecordActionPolicy actionPolicy;

    private RecordService recordService;
    private final UUID userId = UUID.randomUUID();
    private final UUID recordId = UUID.randomUUID();
    private final UUID projectId = UUID.randomUUID();

    @BeforeEach
    void setUp() {
        recordService = new RecordService(records, attachments, revisions, json,
                templates, projects, members, users, events, storage, actionPolicy);
    }

    @Test
    void shouldThrowWhenRecordNotFound() {
        when(records.findActive(recordId)).thenReturn(Optional.empty());

        ApiException ex = assertThrows(ApiException.class, () -> recordService.get(userId, recordId));
        assertEquals(HttpStatus.NOT_FOUND, ex.status());
        assertEquals("RESOURCE_NOT_FOUND", ex.code());
    }

    @Test
    void shouldThrowWhenNotMember() {
        RecordStore.RecordData data = createRecordData();
        lenient().when(records.findActive(recordId)).thenReturn(Optional.of(data));
        when(projects.findById(projectId)).thenReturn(Optional.of(
                new ProjectStore.ProjectRecord(projectId, "项目", null, null, "ACTIVE",
                        userId, Instant.now(), Instant.now(), null, 0L)));
        lenient().when(members.findRole(projectId, userId)).thenReturn(Optional.empty());

        ApiException ex = assertThrows(ApiException.class, () -> recordService.get(userId, recordId));
        assertEquals(HttpStatus.NOT_FOUND, ex.status());
    }

    @Test
    void shouldGetRecordSuccessfully() {
        RecordStore.RecordData data = createRecordData();
        when(records.findActive(recordId)).thenReturn(Optional.of(data));
        when(projects.findById(projectId)).thenReturn(Optional.of(
                new ProjectStore.ProjectRecord(projectId, "项目", null, null, "ACTIVE",
                        userId, Instant.now(), Instant.now(), null, 0L)));
        when(members.findRole(projectId, userId)).thenReturn(Optional.of("MEMBER"));
        when(users.findById(data.creatorId())).thenReturn(Optional.of(
                new User(data.creatorId(), "创建者", "creator@test.com", "hash", Instant.now())));
        when(json.decode(anyString())).thenReturn(Map.of());
        when(json.decodeMap(anyString())).thenReturn(new java.util.LinkedHashMap<>());
        when(actionPolicy.canEdit(any(), any())).thenReturn(Decision.allow());
        when(actionPolicy.canSubmit(any(), any())).thenReturn(Decision.allow());
        when(actionPolicy.canRestore(any(), any())).thenReturn(Decision.allow());

        RecordDtos.View result = recordService.get(userId, recordId);
        assertNotNull(result);
        assertEquals(recordId, result.id());
    }

    @Test
    void shouldListRecords() {
        RecordStore.PageSlice pageSlice = new RecordStore.PageSlice(List.of(), 0L);
        when(records.searchVisible(any(), any(), any(), any(), any(), anyInt(), anyInt()))
                .thenReturn(pageSlice);

        PagedResponse<RecordDtos.View> result = recordService.list(userId, null, null, null, "", 0, 20);

        assertNotNull(result);
        assertEquals(0L, result.meta().totalElements());
    }

    @Test
    void shouldNormalizePageParameters() {
        when(records.searchVisible(any(), any(), any(), any(), any(), eq(0), eq(1)))
                .thenReturn(new RecordStore.PageSlice(List.of(), 0L));

        PagedResponse<RecordDtos.View> result = recordService.list(userId, null, null, null, "", -5, 0);
        assertNotNull(result);
    }

    @Test
    void shouldThrowOnDeleteWhenNotMember() {
        RecordStore.RecordData data = createRecordData();
        when(records.findActive(recordId)).thenReturn(Optional.of(data));
        when(projects.findById(projectId)).thenReturn(Optional.of(
                new ProjectStore.ProjectRecord(projectId, "项目", null, null, "ACTIVE",
                        userId, Instant.now(), Instant.now(), null, 0L)));
        when(members.findRole(projectId, userId)).thenReturn(Optional.empty());

        ApiException ex = assertThrows(ApiException.class, () -> recordService.delete(userId, recordId));
        assertEquals(HttpStatus.NOT_FOUND, ex.status());
    }

    @Test
    void shouldThrowOnCreateWhenReviewer() {
        when(projects.findById(projectId)).thenReturn(Optional.of(
                new ProjectStore.ProjectRecord(projectId, "项目", null, null, "ACTIVE",
                        userId, Instant.now(), Instant.now(), null, 0L)));
        when(members.findRole(projectId, userId)).thenReturn(Optional.of("REVIEWER"));

        RecordDtos.CreateRequest request = new RecordDtos.CreateRequest(
                projectId, null, "标题", "实验", LocalDate.now(), "目的");

        ApiException ex = assertThrows(ApiException.class, () -> recordService.create(userId, request));
        assertEquals(HttpStatus.FORBIDDEN, ex.status());
    }

    private RecordStore.RecordData createRecordData() {
        return new RecordStore.RecordData(
                recordId, "EXP-001", projectId, userId, "标题", "实验",
                LocalDate.now(), "目的", "IN_PROGRESS", false,
                "{\"name\":\"模板\"}", "{\"f1\":\"v1\"}", "{}",
                "<p></p>", "", 0, null, null, 0L, Instant.now(), Instant.now(), null);
    }
}
