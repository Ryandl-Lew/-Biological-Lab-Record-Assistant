import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import StatusBadge from '@/components/ui/StatusBadge';

vi.mock('@/domain', () => ({
  PROJECT_STATUS_LABELS: { active: '进行中', archived: '已归档' },
  PROJECT_STATUS_TONES: { active: 'green', archived: 'gray' },
  RECORD_STATUS_LABELS: { draft: '草稿', submitted: '已提交' },
  RECORD_STATUS_TONES: { draft: 'amber', submitted: 'blue' },
}));

describe('StatusBadge', () => {
  it('renders project status label', () => {
    render(<StatusBadge kind="project" status="active" />);
    expect(screen.getByText('进行中')).toBeInTheDocument();
  });

  it('renders record status label', () => {
    render(<StatusBadge kind="record" status="draft" />);
    expect(screen.getByText('草稿')).toBeInTheDocument();
  });

  it('falls back to raw status when label not found', () => {
    render(<StatusBadge kind="project" status="unknown_status" />);
    expect(screen.getByText('unknown_status')).toBeInTheDocument();
  });

  it('uses correct tone for project status', () => {
    render(<StatusBadge kind="project" status="archived" />);
    const badge = screen.getByText('已归档').closest('span');
    expect(badge.className).toContain('text-slate-600');
  });
});
