import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import AgentRunStatus from '@/components/agent/AgentRunStatus';

vi.mock('@/api', () => ({
  fetchAgentRun: vi.fn(),
  cancelAgentRun: vi.fn(),
  rerunAgent: vi.fn(),
}));

vi.mock('@/api/agentTypes', () => ({
  AGENT_RUN_STATUS: {
    QUEUED: 'QUEUED',
    RUNNING: 'RUNNING',
    SUCCEEDED: 'SUCCEEDED',
    FAILED: 'FAILED',
    CANCELLED: 'CANCELLED',
    LIMIT_EXCEEDED: 'LIMIT_EXCEEDED',
    INVALID_OUTPUT: 'INVALID_OUTPUT',
  },
  ACTIVE_AGENT_RUN_STATUSES: new Set(['QUEUED', 'RUNNING']),
}));

vi.mock('@/components/agent/messages', () => ({
  agentErrorMessage: vi.fn(() => '代理错误'),
}));

const { fetchAgentRun } = await import('@/api');

describe('AgentRunStatus', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    fetchAgentRun.mockResolvedValue({ id: 'run1', status: 'SUCCEEDED' });
  });

  it('returns null when no runId', () => {
    const { container } = render(
      <AgentRunStatus runId="" />
    );
    expect(container.innerHTML).toBe('');
  });

  it('shows status label when run is loaded', async () => {
    render(<AgentRunStatus runId="run1" />);
    expect(await screen.findByText('已生成')).toBeInTheDocument();
  });

  it('shows "查看运行轨迹" button when run is available', async () => {
    const onTrace = vi.fn();
    render(<AgentRunStatus runId="run1" onTrace={onTrace} />);
    expect(await screen.findByText('查看运行轨迹')).toBeInTheDocument();
    fireEvent.click(screen.getByText('查看运行轨迹'));
    expect(onTrace).toHaveBeenCalled();
  });

  it('shows "重新运行" button for failed status', async () => {
    fetchAgentRun.mockResolvedValue({ id: 'run1', status: 'FAILED', errorMessage: '失败' });
    render(<AgentRunStatus runId="run1" />);
    expect(await screen.findByText('重新运行')).toBeInTheDocument();
  });
});
