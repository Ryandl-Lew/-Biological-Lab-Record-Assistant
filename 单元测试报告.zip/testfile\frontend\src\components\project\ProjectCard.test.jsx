import { describe, it, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import ProjectCard from '@/components/project/ProjectCard';

vi.mock('@/domain', () => ({
  PROJECT_ROLE_LABELS: { OWNER: '负责人', MEMBER: '成员', VIEWER: '观察者' },
  PROJECT_ROLE_TONES: { OWNER: 'blue', MEMBER: 'green', VIEWER: 'gray' },
  PROJECT_STATUS_LABELS: { active: '进行中' },
  PROJECT_STATUS_TONES: { active: 'green' },
}));

describe('ProjectCard', () => {
  const renderWithRouter = (ui) => render(<MemoryRouter>{ui}</MemoryRouter>);

  const project = {
    id: 'p1',
    name: '基因编辑项目',
    description: '这是一个CRISPR相关实验项目',
    status: 'active',
    currentUserRole: 'OWNER',
    memberCount: 5,
    recordCount: 12,
    updatedAt: '2025-06-15T10:00:00Z',
  };

  it('renders project name', () => {
    renderWithRouter(<ProjectCard project={project} />);
    expect(screen.getByText('基因编辑项目')).toBeInTheDocument();
  });

  it('renders project description', () => {
    renderWithRouter(<ProjectCard project={project} />);
    expect(screen.getByText('这是一个CRISPR相关实验项目')).toBeInTheDocument();
  });

  it('renders fallback description when empty', () => {
    renderWithRouter(<ProjectCard project={{ ...project, description: '' }} />);
    expect(screen.getByText('暂无项目简介')).toBeInTheDocument();
  });

  it('renders member count and record count', () => {
    renderWithRouter(<ProjectCard project={project} />);
    expect(screen.getByText('5 人')).toBeInTheDocument();
    expect(screen.getByText('12 条')).toBeInTheDocument();
  });

  it('renders enter project button', () => {
    renderWithRouter(<ProjectCard project={project} />);
    expect(screen.getByText('进入项目')).toBeInTheDocument();
  });

  it('renders status badge', () => {
    renderWithRouter(<ProjectCard project={project} />);
    expect(screen.getByText('进行中')).toBeInTheDocument();
  });
});
