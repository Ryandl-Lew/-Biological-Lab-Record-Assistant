package com.bionote.record.infrastructure.persistence;

import com.bionote.record.RecordRevisionDisplayReader;
import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JpaRecordRevisionDisplayReaderTest {

    @Mock private EntityManager entityManager;
    @Mock private Query query;

    private JpaRecordRevisionDisplayReader reader;
    private final UUID revisionId = UUID.randomUUID();
    private final UUID reviewId = UUID.randomUUID();

    @BeforeEach
    void setUp() {
        reader = new JpaRecordRevisionDisplayReader();
        // Use reflection to set entityManager since it's @PersistenceContext injected
        try {
            var field = JpaRecordRevisionDisplayReader.class.getDeclaredField("entityManager");
            field.setAccessible(true);
            field.set(reader, entityManager);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    @Test
    void shouldReturnEmptyWhenFinalRevisionIdIsNull() {
        Optional<RecordRevisionDisplayReader.DisplayedRevision> result = reader.findCompleted(null);
        assertFalse(result.isPresent());
    }

    @Test
    void shouldFindCompletedRevision() {
        Object[] row = {revisionId.toString(), 3, "{\"title\":\"snapshot\"}"};
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyString(), any())).thenReturn(query);
        when(query.getResultList()).thenReturn(List.of(new Object[]{row}));

        Optional<RecordRevisionDisplayReader.DisplayedRevision> result = reader.findCompleted(revisionId);

        assertTrue(result.isPresent());
        assertEquals(revisionId, result.get().id());
        assertEquals(3, result.get().revisionNo());
    }

    @Test
    void shouldReturnEmptyWhenRevisionNotFound() {
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyString(), any())).thenReturn(query);
        when(query.getResultList()).thenReturn(List.of());

        Optional<RecordRevisionDisplayReader.DisplayedRevision> result = reader.findCompleted(revisionId);
        assertFalse(result.isPresent());
    }

    @Test
    void shouldReturnEmptyWhenCurrentReviewIdIsNull() {
        Optional<RecordRevisionDisplayReader.DisplayedRevision> result = reader.findInReview(null);
        assertFalse(result.isPresent());
    }

    @Test
    void shouldFindInReviewWhenReviewHasRevision() {
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyString(), any())).thenReturn(query);

        // Setup: first query returns review ids, second query returns revision
        when(query.getResultList())
                .thenReturn(List.of(revisionId.toString()))  // review query
                .thenReturn(List.of());  // revision query - will be empty

        Optional<RecordRevisionDisplayReader.DisplayedRevision> result = reader.findInReview(reviewId);
        assertFalse(result.isPresent());  // second query returns empty
    }

    @Test
    void shouldReturnEmptyWhenReviewNotFound() {
        when(entityManager.createNativeQuery(anyString())).thenReturn(query);
        when(query.setParameter(anyString(), any())).thenReturn(query);
        when(query.getResultList()).thenReturn(List.of());

        Optional<RecordRevisionDisplayReader.DisplayedRevision> result = reader.findInReview(reviewId);
        assertFalse(result.isPresent());
    }
}
