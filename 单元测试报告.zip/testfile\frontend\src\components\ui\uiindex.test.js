import { describe, it, expect } from 'vitest';

describe('ui/index', () => {
  it('exports Button', async () => {
    const mod = await import('@/components/ui');
    expect(mod.Button).toBeDefined();
  });

  it('exports Badge', async () => {
    const mod = await import('@/components/ui');
    expect(mod.Badge).toBeDefined();
  });

  it('exports StatusBadge', async () => {
    const mod = await import('@/components/ui');
    expect(mod.StatusBadge).toBeDefined();
  });

  it('exports PageHeader', async () => {
    const mod = await import('@/components/ui');
    expect(mod.PageHeader).toBeDefined();
  });

  it('exports Surface', async () => {
    const mod = await import('@/components/ui');
    expect(mod.Surface).toBeDefined();
  });

  it('exports EmptyState', async () => {
    const mod = await import('@/components/ui');
    expect(mod.EmptyState).toBeDefined();
  });

  it('exports Tabs', async () => {
    const mod = await import('@/components/ui');
    expect(mod.Tabs).toBeDefined();
  });
});
