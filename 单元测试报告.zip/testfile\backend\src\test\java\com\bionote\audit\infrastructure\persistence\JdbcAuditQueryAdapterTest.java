package com.bionote.audit.infrastructure.persistence;

import com.bionote.audit.AuditQueryStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("JdbcAuditQueryAdapter 测试")
class JdbcAuditQueryAdapterTest {

    @Mock
    private JdbcTemplate jdbcTemplate;

    private JdbcAuditQueryAdapter adapter;

    @BeforeEach
    void setUp() {
        adapter = new JdbcAuditQueryAdapter(jdbcTemplate);
    }

    @Test
    @DisplayName("exists 当事件存在时应返回 true")
    void shouldReturnTrueWhenEventExists() {
        UUID eventId = UUID.randomUUID();
        UUID projectId = UUID.randomUUID();

        when(jdbcTemplate.queryForObject(anyString(), eq(Boolean.class), any()))
                .thenReturn(true);

        boolean result = adapter.exists(eventId, projectId);

        assertTrue(result);
    }

    @Test
    @DisplayName("exists 当事件不存在时应返回 false")
    void shouldReturnFalseWhenEventNotExists() {
        UUID eventId = UUID.randomUUID();
        UUID projectId = UUID.randomUUID();

        when(jdbcTemplate.queryForObject(anyString(), eq(Boolean.class), any()))
                .thenReturn(false);

        boolean result = adapter.exists(eventId, projectId);

        assertFalse(result);
    }

    @Test
    @DisplayName("exists 返回 null 时应返回 false")
    void shouldReturnFalseWhenQueryReturnsNull() {
        UUID eventId = UUID.randomUUID();
        UUID projectId = UUID.randomUUID();

        when(jdbcTemplate.queryForObject(anyString(), eq(Boolean.class), any()))
                .thenReturn(null);

        boolean result = adapter.exists(eventId, projectId);

        assertFalse(result);
    }

    @Test
    @DisplayName("JdbcAuditQueryAdapter 应实现 AuditQueryStore 接口")
    void shouldImplementAuditQueryStore() {
        assertInstanceOf(AuditQueryStore.class, adapter);
    }
}
