package com.bionote.audit;

import com.bionote.common.PagedResponse;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.core.Authentication;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("AuditController 层测试")
class AuditControllerTest {

    @Mock
    private AuditUseCase service;

    @Mock
    private Authentication authentication;

    @InjectMocks
    private AuditController controller;

    private final UUID userId = UUID.fromString("00000000-0000-0000-0000-000000000001");
    private final UUID projectId = UUID.randomUUID();

    @Test
    @DisplayName("GET 审计事件应返回 200 和分页数据")
    void shouldListAuditEvents() {
        when(authentication.getName()).thenReturn(userId.toString());
        AuditDtos.View view = new AuditDtos.View(UUID.randomUUID(), "RECORD_CREATED",
                "RECORD", UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID(),
                "张三", Map.of(), Instant.now());
        PagedResponse<AuditDtos.View> response = PagedResponse.of(List.of(view), 0, 20, 1L);
        when(service.list(eq(userId), eq(projectId), isNull(), isNull(), isNull(), isNull(), eq(0), eq(20)))
                .thenReturn(response);

        PagedResponse<AuditDtos.View> result = controller.events(authentication, projectId, null, null, null, null, 0, 20);

        assertNotNull(result);
        assertEquals(1, result.meta().totalElements());
        assertEquals("RECORD_CREATED", result.data().get(0).eventType());
    }

    @Test
    @DisplayName("GET 审计事件带查询参数应返回 200")
    void shouldListAuditEventsWithFilters() {
        when(authentication.getName()).thenReturn(userId.toString());
        PagedResponse<AuditDtos.View> response = PagedResponse.of(List.of(), 0, 20, 0L);
        when(service.list(eq(userId), eq(projectId), eq("RECORD_CREATED"), any(), any(), any(), eq(0), eq(20)))
                .thenReturn(response);

        PagedResponse<AuditDtos.View> result = controller.events(authentication, projectId, "RECORD_CREATED", null, null, null, 0, 20);

        assertNotNull(result);
        assertTrue(result.data().isEmpty());
    }

    @Test
    @DisplayName("GET 附件汇总应返回 200")
    void shouldListAttachmentSummaries() {
        when(authentication.getName()).thenReturn(userId.toString());
        AuditDtos.AttachmentSummary summary = new AuditDtos.AttachmentSummary(
                UUID.randomUUID(), "test.pdf", "application/pdf", 1024L,
                UUID.randomUUID(), "Title", "RC-001", "张三", Instant.now());
        PagedResponse<AuditDtos.AttachmentSummary> response = PagedResponse.of(List.of(summary), 0, 20, 1L);
        when(service.attachments(eq(userId), eq(projectId), eq(0), eq(20))).thenReturn(response);

        PagedResponse<AuditDtos.AttachmentSummary> result = controller.attachments(authentication, projectId, 0, 20);

        assertNotNull(result);
        assertEquals(1, result.meta().totalElements());
        assertEquals("test.pdf", result.data().get(0).filename());
        assertEquals("application/pdf", result.data().get(0).mediaType());
    }

    @Test
    @DisplayName("未认证请求应返回错误")
    void shouldRejectUnauthenticated() {
        when(authentication.getName()).thenReturn("not-a-valid-uuid");
        assertThrows(IllegalArgumentException.class, () ->
                controller.events(authentication, projectId, null, null, null, null, 0, 20));
    }
}
