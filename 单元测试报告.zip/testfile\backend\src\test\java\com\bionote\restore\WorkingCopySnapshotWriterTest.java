package com.bionote.restore;

import com.bionote.common.ApiException;
import com.bionote.record.RecordStore;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.time.Instant;
import java.time.LocalDate;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("WorkingCopySnapshotWriter - 工作副本快照写入器测试")
class WorkingCopySnapshotWriterTest {

    @Mock private RecordStore records;
    @Mock private RestoreJsonCodec json;
    @InjectMocks private WorkingCopySnapshotWriter writer;

    private final UUID recordId = UUID.randomUUID();
    private final UUID projectId = UUID.randomUUID();
    private final UUID creatorId = UUID.randomUUID();

    @Nested
    @DisplayName("prepare - 准备工作副本数据")
    class PrepareTests {

        @Test
        @DisplayName("准备成功应返回 Prepared 对象")
        void shouldPrepareSuccessfully() {
            var record = new RecordStore.RecordData(recordId, "REC001", projectId, creatorId,
                    "Test Title", "TYPE_A", null, null, "ACTIVE", false,
                    "{}", "{}", "{}", "<p></p>", "", 0, null, null, 1L,
                    null, null, null);
            var snapshot = snapshotMap();
            when(json.encode(any())).thenReturn("{}");

            var result = writer.prepare(record, snapshot, Set.of());

            assertNotNull(result);
            assertEquals("Test Title", result.title());
            assertEquals("TYPE_A", result.experimentType());
            assertEquals(LocalDate.parse("2025-06-01"), result.experimentDate());
            assertEquals("test purpose", result.purpose());
            assertNotNull(result.fieldValues());
        }

        @Test
        @DisplayName("身份字段不匹配应抛出 INTERNAL_SERVER_ERROR")
        void shouldThrowWhenIdentityMismatch() {
            var record = new RecordStore.RecordData(recordId, "WRONG_CODE", projectId, creatorId,
                    "Test Title", "TYPE_A", null, null, "ACTIVE", false,
                    "{}", "{}", "{}", "<p></p>", "", 0, null, null, 1L,
                    null, null, null);
            var snapshot = snapshotMap();

            var ex = assertThrows(ApiException.class, () -> writer.prepare(record, snapshot, Set.of()));
            assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, ex.status());
            assertTrue(ex.getMessage().contains("code"));
        }

        @Test
        @DisplayName("空的 snapshot 字段应返回默认值")
        void shouldUseDefaultsForEmptySnapshots() {
            var record = new RecordStore.RecordData(recordId, "", projectId, creatorId,
                    "Test Title", "TYPE_A", null, null, "ACTIVE", false,
                    "{}", "{}", "{}", "<p></p>", "", 0, null, null, 1L,
                    null, null, null);
            var snapshot = new LinkedHashMap<String, Object>();
            snapshot.put("id", recordId.toString());
            snapshot.put("code", "");
            snapshot.put("projectId", projectId.toString());
            snapshot.put("creatorId", creatorId.toString());
            snapshot.put("title", "");
            snapshot.put("experimentType", "");
            snapshot.put("experimentDate", "2025-01-01");
            snapshot.put("purpose", "");
            snapshot.put("templateSnapshot", Map.of());
            snapshot.put("fieldValues", Map.of());
            snapshot.put("contentJson", Map.of());
            snapshot.put("contentHtml", "");
            when(json.encode(any())).thenReturn("{}");

            var result = writer.prepare(record, snapshot, Set.of());

            assertEquals("", result.title());
            assertEquals("", result.purpose());
        }
    }

    @Nested
    @DisplayName("write - 写入工作副本")
    class WriteTests {

        @Test
        @DisplayName("写入成功应返回新版本号")
        void shouldReturnNewVersionOnSuccess() {
            var prepared = new WorkingCopySnapshotWriter.Prepared("title", "type", LocalDate.now(),
                    "purpose", "{}", "{}", "{}", "<p>test</p>", "test", Map.of());
            when(records.restoreWorkingCopy(any(), anyLong(), any(), any())).thenReturn(true);

            var newVersion = writer.write(recordId, 3L, prepared, Instant.now());

            assertEquals(4L, newVersion);
        }

        @Test
        @DisplayName("乐观锁冲突应抛出 CONFLICT")
        void shouldThrowConflictOnOptimisticLockFailure() {
            var prepared = new WorkingCopySnapshotWriter.Prepared("title", "type", LocalDate.now(),
                    "purpose", "{}", "{}", "{}", "<p>test</p>", "test", Map.of());
            when(records.restoreWorkingCopy(any(), anyLong(), any(), any())).thenReturn(false);

            var ex = assertThrows(ApiException.class, () -> writer.write(recordId, 1L, prepared, Instant.now()));
            assertEquals(HttpStatus.CONFLICT, ex.status());
            assertEquals("OPTIMISTIC_LOCK_CONFLICT", ex.code());
        }
    }

    private Map<String, Object> snapshotMap() {
        Map<String, Object> map = new LinkedHashMap<>();
        map.put("id", recordId);
        map.put("code", "REC001");
        map.put("projectId", projectId);
        map.put("creatorId", creatorId);
        map.put("title", "Test Title");
        map.put("experimentType", "TYPE_A");
        map.put("experimentDate", "2025-06-01");
        map.put("purpose", "test purpose");
        map.put("templateSnapshot", Map.of());
        map.put("fieldValues", Map.of());
        map.put("contentJson", Map.of());
        map.put("contentHtml", "<p>test</p>");
        return map;
    }
}
