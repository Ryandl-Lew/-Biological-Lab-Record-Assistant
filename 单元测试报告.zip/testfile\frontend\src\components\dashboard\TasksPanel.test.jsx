import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import TasksPanel from '@/components/dashboard/TasksPanel';

vi.mock('@/api', () => ({
  fetchDashboardTasks: vi.fn(),
  fetchDashboardSummary: vi.fn(),
  acceptInvitation: vi.fn(),
  rejectInvitation: vi.fn(),
}));

vi.mock('@/lib/formatRelativeTime', () => ({
  default: vi.fn(() => '刚刚'),
}));

const { fetchDashboardTasks, fetchDashboardSummary } = await import('@/api');

describe('TasksPanel', () => {
  const renderWithRouter = (ui) => render(<MemoryRouter>{ui}</MemoryRouter>);

  beforeEach(() => {
    vi.clearAllMocks();
    fetchDashboardTasks.mockResolvedValue([]);
    fetchDashboardSummary.mockResolvedValue({
      changesRequestedCount: 0,
      pendingReviewCount: 0,
      pendingInvitationCount: 0,
    });
  });

  it('renders section heading', async () => {
    renderWithRouter(<TasksPanel />);
    expect(screen.getByText('待处理事项')).toBeInTheDocument();
  });

  it('shows loading state initially', () => {
    renderWithRouter(<TasksPanel />);
    expect(screen.getByText('加载待办中…')).toBeInTheDocument();
  });

  it('shows empty state after tasks load with no items', async () => {
    renderWithRouter(<TasksPanel />);
    expect(await screen.findByText('待办已清空')).toBeInTheDocument();
  });

  it('shows task items when tasks are returned', async () => {
    fetchDashboardTasks.mockResolvedValue([
      { id: 't1', type: 'PENDING_REVIEW', title: '需要审核的记录', projectName: '项目A', time: new Date().toISOString(), targetId: 'r1', stale: false },
    ]);
    renderWithRouter(<TasksPanel />);
    expect(await screen.findByText('需要审核的记录')).toBeInTheDocument();
    expect(screen.getByText('待审核')).toBeInTheDocument();
  });

  it('shows pending count summary', async () => {
    fetchDashboardSummary.mockResolvedValue({
      changesRequestedCount: 2,
      pendingReviewCount: 1,
      pendingInvitationCount: 0,
    });
    renderWithRouter(<TasksPanel />);
    expect(await screen.findByText('3 项待处理')).toBeInTheDocument();
  });
});
