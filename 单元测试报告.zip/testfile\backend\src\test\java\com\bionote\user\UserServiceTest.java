package com.bionote.user;

import com.bionote.common.ApiException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock private UserRepository users;
    @Mock private AvatarStorage avatars;
    @Mock private MultipartFile file;

    private UserService userService;
    private final UUID userId = UUID.randomUUID();
    private User testUser;

    @BeforeEach
    void setUp() {
        userService = new UserService(users, avatars);
        testUser = new User(userId, "测试用户", "test@example.com", "hash", Instant.now());
    }

    @Test
    void shouldRequireExistingUser() {
        when(users.findById(userId)).thenReturn(Optional.of(testUser));
        User result = userService.require(userId);
        assertEquals(userId, result.getId());
    }

    @Test
    void shouldThrowWhenUserNotFound() {
        when(users.findById(userId)).thenReturn(Optional.empty());
        ApiException ex = assertThrows(ApiException.class, () -> userService.require(userId));
        assertEquals(HttpStatus.NOT_FOUND, ex.status());
        assertEquals("RESOURCE_NOT_FOUND", ex.code());
    }

    @Test
    void shouldViewUserWithAvatar() {
        testUser.setAvatarStorageKey("key.jpg");
        testUser.setAvatarMimeType("image/jpeg");
        UserDtos.UserView view = userService.view(testUser);

        assertEquals(userId, view.id());
        assertEquals("测试用户", view.displayName());
        assertEquals("/api/v1/users/" + userId + "/avatar", view.avatarUrl());
    }

    @Test
    void shouldViewUserWithoutAvatar() {
        UserDtos.UserView view = userService.view(testUser);
        assertNull(view.avatarUrl());
    }

    @Test
    void shouldUpdateProfile() {
        when(users.findById(userId)).thenReturn(Optional.of(testUser));
        when(users.save(any(User.class))).thenReturn(testUser);

        UserDtos.UpdateProfileRequest request = new UserDtos.UpdateProfileRequest("新名称");
        UserDtos.UserView result = userService.update(userId, request);

        assertEquals("新名称", testUser.getDisplayName());
        assertNotNull(result);
    }

    @Test
    void shouldUpdateProfileWithTrimmedName() {
        when(users.findById(userId)).thenReturn(Optional.of(testUser));
        when(users.save(any(User.class))).thenReturn(testUser);

        UserDtos.UpdateProfileRequest request = new UserDtos.UpdateProfileRequest("  修剪后  ");
        userService.update(userId, request);

        assertEquals("修剪后", testUser.getDisplayName());
    }

    @Test
    void shouldUploadAvatar() {
        UUID storageKey = UUID.randomUUID();
        AvatarStorage.StoredAvatar stored = new AvatarStorage.StoredAvatar(storageKey + ".jpg", "image/jpeg");
        when(users.findById(userId)).thenReturn(Optional.of(testUser));
        when(users.save(any(User.class))).thenReturn(testUser);
        when(avatars.store(file)).thenReturn(stored);

        UserDtos.UserView result = userService.avatar(userId, file);

        assertEquals(stored.key(), testUser.getAvatarStorageKey());
        assertEquals(stored.mime(), testUser.getAvatarMimeType());
        assertNotNull(result);
    }

    @Test
    void shouldReadAvatarBytes() throws IOException {
        testUser.setAvatarStorageKey("key.jpg");
        testUser.setAvatarMimeType("image/jpeg");
        byte[] data = "image-bytes".getBytes();
        when(users.findById(userId)).thenReturn(Optional.of(testUser));
        when(avatars.read("key.jpg")).thenReturn(data);

        UserUseCase.AvatarContent content = userService.avatar(userId);

        assertNotNull(content);
        assertArrayEquals(data, content.bytes());
        assertEquals("image/jpeg", content.mediaType());
    }

    @Test
    void shouldReturnNullWhenNoAvatar() {
        when(users.findById(userId)).thenReturn(Optional.of(testUser));
        UserUseCase.AvatarContent content = userService.avatar(userId);
        assertNull(content);
    }

    @Test
    void shouldThrowWhenAvatarReadFails() throws IOException {
        testUser.setAvatarStorageKey("key.jpg");
        when(users.findById(userId)).thenReturn(Optional.of(testUser));
        when(avatars.read("key.jpg")).thenThrow(new IOException("disk error"));

        ApiException ex = assertThrows(ApiException.class, () -> userService.avatar(userId));
        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, ex.status());
    }
}
