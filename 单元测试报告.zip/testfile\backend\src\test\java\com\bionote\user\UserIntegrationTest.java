package com.bionote.user;

import com.bionote.user.infrastructure.persistence.JpaUserRepositoryAdapter;
import com.bionote.user.infrastructure.persistence.UserJpaRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@Import(JpaUserRepositoryAdapter.class)
class UserIntegrationTest {

    @Autowired private UserJpaRepository repository;
    @Autowired private JpaUserRepositoryAdapter adapter;

    @BeforeEach
    void setUp() {
        repository.deleteAll();
    }

    @Test
    void shouldPersistAndFindUser() {
        UUID id = UUID.randomUUID();
        User user = new User(id, "张三", "zhangsan@test.com", "hash123", Instant.now());
        adapter.save(user);

        Optional<User> found = adapter.findById(id);
        assertTrue(found.isPresent());
        assertEquals("张三", found.get().getDisplayName());
        assertEquals("zhangsan@test.com", found.get().getEmailNormalized());
    }

    @Test
    void shouldFindByEmail() {
        UUID id = UUID.randomUUID();
        User user = new User(id, "李四", "lisi@test.com", "hash", Instant.now());
        adapter.save(user);

        Optional<User> found = adapter.findByEmailNormalized("lisi@test.com");
        assertTrue(found.isPresent());
        assertEquals(id, found.get().getId());
    }

    @Test
    void shouldReturnEmptyForUnknownEmail() {
        Optional<User> found = adapter.findByEmailNormalized("unknown@test.com");
        assertFalse(found.isPresent());
    }

    @Test
    void shouldCheckEmailExistence() {
        assertFalse(adapter.existsByEmailNormalized("new@test.com"));
        adapter.save(new User(UUID.randomUUID(), "王五", "new@test.com", "hash", Instant.now()));
        assertTrue(adapter.existsByEmailNormalized("new@test.com"));
    }

    @Test
    void shouldSaveAndFlush() {
        User user = new User(UUID.randomUUID(), "赵六", "zhao@test.com", "hash", Instant.now());
        User saved = adapter.saveAndFlush(user);
        assertNotNull(saved.getId());
        assertNotNull(adapter.findById(saved.getId()));
    }
}
