package com.bionote.notification.infrastructure.persistence;

import org.junit.jupiter.api.Test;
import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class NotificationEntityTest {

    @Test
    void shouldHaveProtectedNoArgConstructor() {
        // Test via reflection
        try {
            var constructor = NotificationEntity.class.getDeclaredConstructor();
            constructor.setAccessible(true);
            NotificationEntity entity = constructor.newInstance();
            assertNotNull(entity);
        } catch (Exception e) {
            fail("Should have accessible no-arg constructor: " + e.getMessage());
        }
    }

    @Test
    void fieldsShouldBeAccessibleViaReflection() throws Exception {
        var constructor = NotificationEntity.class.getDeclaredConstructor();
        constructor.setAccessible(true);
        NotificationEntity entity = constructor.newInstance();

        UUID id = UUID.randomUUID();
        UUID recipientId = UUID.randomUUID();
        Instant now = Instant.now();

        // Set fields through reflection
        var idField = NotificationEntity.class.getDeclaredField("id");
        idField.setAccessible(true);
        idField.set(entity, id);

        var recipientField = NotificationEntity.class.getDeclaredField("recipientId");
        recipientField.setAccessible(true);
        recipientField.set(entity, recipientId);

        var typeField = NotificationEntity.class.getDeclaredField("type");
        typeField.setAccessible(true);
        typeField.set(entity, "INVITATION");

        var titleField = NotificationEntity.class.getDeclaredField("title");
        titleField.setAccessible(true);
        titleField.set(entity, "Test Title");

        var bodyField = NotificationEntity.class.getDeclaredField("body");
        bodyField.setAccessible(true);
        bodyField.set(entity, "Test Body");

        var createdAtField = NotificationEntity.class.getDeclaredField("createdAt");
        createdAtField.setAccessible(true);
        createdAtField.set(entity, now);

        assertEquals(id, idField.get(entity));
        assertEquals(recipientId, recipientField.get(entity));
        assertEquals("INVITATION", typeField.get(entity));
        assertEquals("Test Title", titleField.get(entity));
        assertEquals("Test Body", bodyField.get(entity));
        assertEquals(now, createdAtField.get(entity));
    }

    @Test
    void unreadNotificationShouldHaveNullReadAt() throws Exception {
        var constructor = NotificationEntity.class.getDeclaredConstructor();
        constructor.setAccessible(true);
        NotificationEntity entity = constructor.newInstance();

        var readAtField = NotificationEntity.class.getDeclaredField("readAt");
        readAtField.setAccessible(true);

        assertNull(readAtField.get(entity));
    }

    @Test
    void readNotificationShouldHaveNonNullReadAt() throws Exception {
        var constructor = NotificationEntity.class.getDeclaredConstructor();
        constructor.setAccessible(true);
        NotificationEntity entity = constructor.newInstance();

        Instant now = Instant.now();
        var readAtField = NotificationEntity.class.getDeclaredField("readAt");
        readAtField.setAccessible(true);
        readAtField.set(entity, now);

        assertEquals(now, readAtField.get(entity));
    }

    @Test
    void tableAnnotationShouldBeNotifications() {
        var tableAnnotation = NotificationEntity.class.getAnnotation(jakarta.persistence.Table.class);
        assertNotNull(tableAnnotation);
        assertEquals("notifications", tableAnnotation.name());
    }
}
