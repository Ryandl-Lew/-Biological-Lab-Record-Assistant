package com.bionote.restore;

import com.bionote.revision.RevisionDtos;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("RestoreJsonCodec - JSON 编解码测试")
class RestoreJsonCodecTest {

    @Mock private ObjectMapper objectMapper;
    @InjectMocks private RestoreJsonCodec codec;

    @Nested
    @DisplayName("encode")
    class EncodeTests {

        @Test
        @DisplayName("编码成功应返回 JSON 字符串")
        void shouldEncodeObjectToJson() throws Exception {
            var obj = Map.of("key", "value");
            when(objectMapper.writeValueAsString(obj)).thenReturn("{\"key\":\"value\"}");

            var result = codec.encode(obj);

            assertEquals("{\"key\":\"value\"}", result);
        }

        @Test
        @DisplayName("编码失败应抛出 IllegalArgumentException")
        void shouldThrowIllegalArgumentOnEncodeFailure() throws Exception {
            var obj = new Object();
            when(objectMapper.writeValueAsString(any())).thenThrow(new JsonProcessingException("error") {});

            var ex = assertThrows(IllegalArgumentException.class, () -> codec.encode(obj));
            assertTrue(ex.getMessage().contains("Restore data cannot be encoded"));
        }

        @Test
        @DisplayName("null 对象的编码")
        void shouldEncodeNull() throws Exception {
            when(objectMapper.writeValueAsString(null)).thenReturn("null");
            assertEquals("null", codec.encode(null));
        }
    }

    @Nested
    @DisplayName("decodeSummary")
    class DecodeSummaryTests {

        @Test
        @DisplayName("解码成功应返回 DiffSummary")
        void shouldDecodeJsonToDiffSummary() throws Exception {
            var summary = new RevisionDtos.DiffSummary(1, 2, 3, 4, 0, 0);
            var json = "{\"added\":1,\"removed\":2,\"modified\":3,\"unchanged\":4,\"attachmentAdded\":0,\"attachmentRemoved\":0}";
            when(objectMapper.readValue(json, RevisionDtos.DiffSummary.class)).thenReturn(summary);

            var result = codec.decodeSummary(json);

            assertEquals(1, result.added());
            assertEquals(2, result.removed());
            assertEquals(3, result.modified());
            assertEquals(4, result.unchanged());
        }

        @Test
        @DisplayName("解码失败应抛出 IllegalStateException")
        void shouldThrowIllegalStateOnDecodeFailure() throws Exception {
            when(objectMapper.readValue(any(String.class), eq(RevisionDtos.DiffSummary.class)))
                    .thenThrow(new JsonProcessingException("invalid") {});

            var ex = assertThrows(IllegalStateException.class, () -> codec.decodeSummary("bad json"));
            assertTrue(ex.getMessage().contains("Invalid restore diff summary"));
        }

        @Test
        @DisplayName("解码空字符串应抛异常")
        void shouldThrowOnEmptyString() throws Exception {
            when(objectMapper.readValue("", RevisionDtos.DiffSummary.class))
                    .thenThrow(new JsonProcessingException("empty") {});

            assertThrows(IllegalStateException.class, () -> codec.decodeSummary(""));
        }
    }
}
