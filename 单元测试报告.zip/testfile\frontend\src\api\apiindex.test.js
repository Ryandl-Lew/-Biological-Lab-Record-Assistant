import { describe, it, expect } from 'vitest'
import * as apiIndex from './index'

describe('api/index', () => {
  it('re-exports from client', () => {
    expect(apiIndex.request).toBeDefined()
    expect(apiIndex.ApiError).toBeDefined()
    expect(apiIndex.API_BASE_URL).toBeDefined()
  })

  it('re-exports from projects', () => {
    expect(apiIndex.fetchProjects).toBeDefined()
    expect(apiIndex.fetchProject).toBeDefined()
    expect(apiIndex.createProject).toBeDefined()
    expect(apiIndex.archiveProject).toBeDefined()
    expect(apiIndex.fetchProjectMembers).toBeDefined()
    expect(apiIndex.inviteProjectMember).toBeDefined()
    expect(apiIndex.updateProjectMemberRole).toBeDefined()
    expect(apiIndex.removeProjectMember).toBeDefined()
    expect(apiIndex.fetchProjectAuditEvents).toBeDefined()
    expect(apiIndex.fetchProjectAttachments).toBeDefined()
  })

  it('re-exports from records', () => {
    expect(apiIndex.fetchRecords).toBeDefined()
    expect(apiIndex.fetchRecord).toBeDefined()
    expect(apiIndex.reserveRecord).toBeDefined()
    expect(apiIndex.discardRecordReservation).toBeDefined()
    expect(apiIndex.createRecord).toBeDefined()
    expect(apiIndex.updateRecord).toBeDefined()
    expect(apiIndex.deleteRecord).toBeDefined()
  })

  it('re-exports from templates', () => {
    expect(apiIndex.fetchTemplates).toBeDefined()
    expect(apiIndex.fetchTemplate).toBeDefined()
    expect(apiIndex.createTemplate).toBeDefined()
    expect(apiIndex.updateTemplate).toBeDefined()
    expect(apiIndex.deleteTemplate).toBeDefined()
    expect(apiIndex.copyTemplate).toBeDefined()
  })

  it('re-exports named functions from assist', () => {
    expect(apiIndex.search).toBeDefined()
    expect(apiIndex.fetchDashboardTasks).toBeDefined()
    expect(apiIndex.fetchDashboardSummary).toBeDefined()
  })

  it('re-exports from auth', () => {
    expect(apiIndex.login).toBeDefined()
    expect(apiIndex.register).toBeDefined()
    expect(apiIndex.logout).toBeDefined()
    expect(apiIndex.getCurrentUser).toBeDefined()
  })

  it('re-exports from users', () => {
    expect(apiIndex.updateMyProfile).toBeDefined()
    expect(apiIndex.uploadMyAvatar).toBeDefined()
  })

  it('re-exports from notifications', () => {
    expect(apiIndex.fetchNotifications).toBeDefined()
    expect(apiIndex.fetchUnreadCount).toBeDefined()
    expect(apiIndex.markNotificationRead).toBeDefined()
    expect(apiIndex.markAllNotificationsRead).toBeDefined()
    expect(apiIndex.acceptInvitation).toBeDefined()
    expect(apiIndex.rejectInvitation).toBeDefined()
  })

  it('re-exports from attachments', () => {
    expect(apiIndex.fetchAttachments).toBeDefined()
    expect(apiIndex.deleteAttachment).toBeDefined()
    expect(apiIndex.previewAttachment).toBeDefined()
    expect(apiIndex.downloadAttachment).toBeDefined()
    expect(apiIndex.uploadAttachment).toBeDefined()
    expect(apiIndex.saveBlob).toBeDefined()
  })

  it('re-exports from reviews', () => {
    expect(apiIndex.fetchReviewerCandidates).toBeDefined()
    expect(apiIndex.submitRecord).toBeDefined()
    expect(apiIndex.requestReviewChanges).toBeDefined()
    expect(apiIndex.approveReview).toBeDefined()
    expect(apiIndex.fetchPendingReviews).toBeDefined()
  })

  it('re-exports from exports', () => {
    expect(apiIndex.fetchExportPreview).toBeDefined()
    expect(apiIndex.downloadMarkdown).toBeDefined()
    expect(apiIndex.downloadPdf).toBeDefined()
  })
})
