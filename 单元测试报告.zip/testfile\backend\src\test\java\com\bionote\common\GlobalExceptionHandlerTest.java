package com.bionote.common;

import jakarta.servlet.http.HttpServletRequest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.slf4j.MDC;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.multipart.MaxUploadSizeExceededException;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("GlobalExceptionHandler 测试")
class GlobalExceptionHandlerTest {

    private GlobalExceptionHandler handler;

    @Mock
    private HttpServletRequest request;

    @BeforeEach
    void setUp() {
        handler = new GlobalExceptionHandler();
    }

    @Test
    @DisplayName("ApiException 应返回对应状态码和错误信息")
    void shouldHandleApiException() {
        ApiException ex = new ApiException(HttpStatus.NOT_FOUND, "NOT_FOUND", "资源未找到");

        ResponseEntity<ApiErrorResponse> response = handler.api(ex, request);

        assertEquals(HttpStatus.NOT_FOUND, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals(404, response.getBody().status());
        assertEquals("NOT_FOUND", response.getBody().code());
        assertEquals("资源未找到", response.getBody().message());
        assertNotNull(response.getBody().traceId());
    }

    @Test
    @DisplayName("MethodArgumentNotValidException 应返回 400 校验错误")
    void shouldHandleValidationException() {
        MethodArgumentNotValidException ex = createValidationException();

        ResponseEntity<ApiErrorResponse> response = handler.validation(ex, request);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatusCode());
        assertNotNull(response.getBody());
        assertEquals("VALIDATION_ERROR", response.getBody().code());
        assertEquals("请检查输入内容", response.getBody().message());
        assertFalse(response.getBody().fieldErrors().isEmpty());
    }

    @Test
    @DisplayName("AccessDeniedException 应返回 403")
    void shouldHandleAccessDeniedException() {
        AccessDeniedException ex = new AccessDeniedException("无权访问");

        ResponseEntity<ApiErrorResponse> response = handler.denied(ex, request);

        assertEquals(HttpStatus.FORBIDDEN, response.getStatusCode());
        assertEquals("ACCESS_DENIED", response.getBody().code());
        assertEquals("无权执行此操作", response.getBody().message());
    }

    @Test
    @DisplayName("DataIntegrityViolationException 应返回 409")
    void shouldHandleDataIntegrityViolationException() {
        DataIntegrityViolationException ex = new DataIntegrityViolationException("重复键");

        ResponseEntity<ApiErrorResponse> response = handler.duplicate(ex, request);

        assertEquals(HttpStatus.CONFLICT, response.getStatusCode());
        assertEquals("DUPLICATE_RESOURCE", response.getBody().code());
        assertEquals("资源已存在", response.getBody().message());
    }

    @Test
    @DisplayName("MaxUploadSizeExceededException 应返回 413")
    void shouldHandleMaxUploadSizeExceededException() {
        MaxUploadSizeExceededException ex = new MaxUploadSizeExceededException(1024);

        ResponseEntity<ApiErrorResponse> response = handler.uploadSize(ex, request);

        assertEquals(HttpStatus.PAYLOAD_TOO_LARGE, response.getStatusCode());
        assertEquals("FILE_TOO_LARGE", response.getBody().code());
        assertEquals("上传文件超过大小限制", response.getBody().message());
    }

    @Test
    @DisplayName("HttpRequestMethodNotSupportedException 应返回 405")
    void shouldHandleMethodNotAllowed() {
        HttpRequestMethodNotSupportedException ex =
                new HttpRequestMethodNotSupportedException("POST");

        ResponseEntity<ApiErrorResponse> response = handler.methodNotAllowed(ex, request);

        assertEquals(HttpStatus.METHOD_NOT_ALLOWED, response.getStatusCode());
        assertEquals("METHOD_NOT_ALLOWED", response.getBody().code());
        assertEquals("该资源不支持此操作", response.getBody().message());
    }

    @Test
    @DisplayName("未预期的 Exception 应返回 500")
    void shouldHandleUnexpectedException() {
        Exception ex = new RuntimeException("未知错误");

        ResponseEntity<ApiErrorResponse> response = handler.unexpected(ex, request);

        assertEquals(HttpStatus.INTERNAL_SERVER_ERROR, response.getStatusCode());
        assertEquals("INTERNAL_ERROR", response.getBody().code());
        assertEquals("服务器暂时无法处理请求", response.getBody().message());
    }

    @Test
    @DisplayName("MDC 中无 traceId 时应生成 UUID")
    void shouldGenerateTraceIdWhenMdcIsEmpty() {
        MDC.remove("traceId");
        ApiException ex = new ApiException(HttpStatus.BAD_REQUEST, "ERR", "msg");

        ResponseEntity<ApiErrorResponse> response = handler.api(ex, request);

        assertNotNull(response.getBody().traceId());
        assertFalse(response.getBody().traceId().isEmpty());
    }

    // --- helper ---

    @SuppressWarnings("unchecked")
    private MethodArgumentNotValidException createValidationException() {
        BindingResult bindingResult = org.mockito.Mockito.mock(BindingResult.class);
        FieldError fieldError = new FieldError("dto", "name", "不能为空");
        when(bindingResult.getFieldErrors()).thenReturn(List.of(fieldError));

        MethodArgumentNotValidException ex = new MethodArgumentNotValidException(null, bindingResult);
        return ex;
    }
}
