import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import ProfilePage from '@/pages/ProfilePage';

const mockUpdateProfile = vi.fn();
const mockUploadAvatar = vi.fn();

let mockUserState = {
  displayName: 'TestUser',
  email: 'test@example.com',
  createdAt: '2025-01-15T08:00:00Z',
  avatarUrl: null,
};

vi.mock('@/store/authStore', () => ({
  useAuthStore: vi.fn((selector) => {
    const state = {
      currentUser: mockUserState,
      updateProfile: mockUpdateProfile,
      uploadAvatar: mockUploadAvatar,
    };
    return selector(state);
  }),
}));

vi.mock('lucide-react', () => ({
  CalendarDays: () => <span data-testid="icon-calendar">CalendarIcon</span>,
  Check: () => <span data-testid="icon-check">CheckIcon</span>,
  Mail: () => <span data-testid="icon-mail">MailIcon</span>,
  Pencil: () => <span data-testid="icon-pencil">PencilIcon</span>,
  Upload: () => <span data-testid="icon-upload">UploadIcon</span>,
  UserRound: () => <span data-testid="icon-user">UserIcon</span>,
  X: () => <span data-testid="icon-x">XIcon</span>,
}));

vi.mock('@/components/ui', () => ({
  Button: ({ children, onClick, type, icon: Icon, loading, disabled, size, variant, className }) => (
    <button
      type={type || 'button'}
      onClick={onClick}
      disabled={disabled || loading}
      data-testid={`btn-${children}`}
    >
      {Icon && <Icon />}
      {loading ? 'loading...' : children}
    </button>
  ),
  PageHeader: ({ eyebrow, title }) => (
    <header data-testid="page-header">
      <p>{eyebrow}</p>
      <h1>{title}</h1>
    </header>
  ),
  Surface: ({ children, title, extra, className }) => (
    <div data-testid="surface" className={className}>
      {title && <h2>{title}</h2>}
      {extra && <div data-testid="surface-extra">{extra}</div>}
      {children}
    </div>
  ),
}));

describe('ProfilePage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockUserState = {
      displayName: 'TestUser',
      email: 'test@example.com',
      createdAt: '2025-01-15T08:00:00Z',
      avatarUrl: null,
    };
  });

  function renderPage() {
    return render(<ProfilePage />);
  }

  it('should display the page header with correct title', () => {
    renderPage();
    expect(screen.getByTestId('page-header')).toBeInTheDocument();
    expect(screen.getByText('个人中心')).toBeInTheDocument();
    expect(screen.getByText('用户信息')).toBeInTheDocument();
  });

  it('should render the current user display name', () => {
    renderPage();
    const elements = screen.getAllByText('TestUser');
    expect(elements.length).toBeGreaterThanOrEqual(1);
  });

  it('should render the current user email', () => {
    renderPage();
    const elements = screen.getAllByText('test@example.com');
    expect(elements.length).toBeGreaterThanOrEqual(1);
  });

  it('should render the registration date', () => {
    renderPage();
    expect(screen.getByText(/2025/)).toBeInTheDocument();
  });

  it('should show the first letter of displayName when no avatarUrl', () => {
    renderPage();
    // The avatar circle shows the first letter "T"
    const tElements = screen.getAllByText('T');
    expect(tElements.length).toBeGreaterThanOrEqual(1);
  });

  it('should show image when avatarUrl is set', () => {
    mockUserState.avatarUrl = 'https://example.com/avatar.png';
    renderPage();
    const img = screen.getByAltText('用户头像');
    expect(img).toBeInTheDocument();
    expect(img).toHaveAttribute('src', 'https://example.com/avatar.png');
  });

  it('should enter edit mode when clicking "编辑资料"', () => {
    renderPage();
    fireEvent.click(screen.getByTestId('btn-编辑资料'));
    const nameInput = screen.getByLabelText('用户名');
    expect(nameInput).toBeInTheDocument();
    expect(nameInput).toHaveValue('TestUser');
  });

  it('should cancel editing and reset displayName', () => {
    renderPage();
    fireEvent.click(screen.getByTestId('btn-编辑资料'));
    const nameInput = screen.getByLabelText('用户名');
    fireEvent.change(nameInput, { target: { value: 'ChangedName' } });
    fireEvent.click(screen.getByTestId('btn-取消'));
    expect(screen.queryByLabelText('用户名')).not.toBeInTheDocument();
    const elements = screen.getAllByText('TestUser');
    expect(elements.length).toBeGreaterThanOrEqual(1);
  });

  it('should call updateProfile on save', async () => {
    mockUpdateProfile.mockResolvedValueOnce({ displayName: 'NewName' });
    renderPage();
    fireEvent.click(screen.getByTestId('btn-编辑资料'));
    const nameInput = screen.getByLabelText('用户名');
    fireEvent.change(nameInput, { target: { value: 'NewName' } });
    fireEvent.click(screen.getByTestId('btn-保存资料'));
    await waitFor(() => {
      expect(mockUpdateProfile).toHaveBeenCalledWith('NewName');
    });
  });

  it('should show success message after profile update', async () => {
    mockUpdateProfile.mockResolvedValueOnce({ displayName: 'NewName' });
    renderPage();
    fireEvent.click(screen.getByTestId('btn-编辑资料'));
    const nameInput = screen.getByLabelText('用户名');
    fireEvent.change(nameInput, { target: { value: 'NewName' } });
    fireEvent.click(screen.getByTestId('btn-保存资料'));
    await waitFor(() => {
      expect(screen.getByText('资料已更新')).toBeInTheDocument();
    });
  });

  it('should show error message when updateProfile fails', async () => {
    mockUpdateProfile.mockRejectedValueOnce(new Error('Network Error'));
    renderPage();
    fireEvent.click(screen.getByTestId('btn-编辑资料'));
    const nameInput = screen.getByLabelText('用户名');
    fireEvent.change(nameInput, { target: { value: 'NewName' } });
    fireEvent.click(screen.getByTestId('btn-保存资料'));
    await waitFor(() => {
      expect(screen.getByText('Network Error')).toBeInTheDocument();
    });
  });

  it('should disable save button when displayName is empty', () => {
    renderPage();
    fireEvent.click(screen.getByTestId('btn-编辑资料'));
    const nameInput = screen.getByLabelText('用户名');
    fireEvent.change(nameInput, { target: { value: '' } });
    expect(screen.getByTestId('btn-保存资料')).toBeDisabled();
  });

  it('should show "-" when createdAt is missing', () => {
    mockUserState.createdAt = null;
    renderPage();
    expect(screen.getByText('-')).toBeInTheDocument();
  });

  it('should render the avatar upload label', () => {
    renderPage();
    expect(screen.getByText('更换头像')).toBeInTheDocument();
  });
});
