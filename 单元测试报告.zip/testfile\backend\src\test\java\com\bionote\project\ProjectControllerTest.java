package com.bionote.project;

import com.bionote.common.ApiException;
import com.bionote.common.PagedResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class ProjectControllerTest {

    @Mock private ProjectUseCase projectUseCase;
    @Mock private Authentication authentication;

    @InjectMocks private ProjectController controller;

    private final UUID userId = UUID.randomUUID();
    private final UUID projectId = UUID.randomUUID();
    private final Instant now = Instant.now();

    @Test
    void shouldListProjects() {
        when(authentication.getName()).thenReturn(userId.toString());
        PagedResponse<ProjectDtos.ProjectView> page = PagedResponse.of(List.of(), 0, 20, 0);
        when(projectUseCase.list(eq(userId), eq(""), isNull(), eq(0), eq(20))).thenReturn(page);

        PagedResponse<ProjectDtos.ProjectView> result = controller.list(authentication, "", null, 0, 20);

        assertNotNull(result);
        assertEquals(0, result.meta().totalElements());
    }

    @Test
    void shouldCreateProjectSuccessfully() {
        when(authentication.getName()).thenReturn(userId.toString());
        ProjectDtos.ProjectView view = new ProjectDtos.ProjectView(
                projectId, "新项目", "描述", null, "ACTIVE", UUID.randomUUID(),
                "OWNER", now, now, null, 0L,
                Map.of(), 1L, 0L);
        when(projectUseCase.create(eq(userId), any())).thenReturn(view);

        var result = controller.create(authentication, new ProjectDtos.CreateProjectRequest("新项目", "描述"));

        assertNotNull(result);
        assertEquals("新项目", result.getData().name());
    }

    @Test
    void shouldGetProjectDetail() {
        when(authentication.getName()).thenReturn(userId.toString());
        ProjectDtos.ProjectView view = new ProjectDtos.ProjectView(
                projectId, "项目1", "desc", null, "ACTIVE", UUID.randomUUID(),
                "MEMBER", now, now, null, 0L,
                Map.of(), 3L, 5L);
        when(projectUseCase.detail(eq(userId), eq(projectId))).thenReturn(view);

        var result = controller.detail(authentication, projectId);

        assertNotNull(result);
        assertEquals("MEMBER", result.getData().currentUserRole());
    }

    @Test
    void shouldReturnNotFoundForNonexistentProject() {
        when(authentication.getName()).thenReturn(userId.toString());
        when(projectUseCase.detail(eq(userId), eq(projectId)))
                .thenThrow(new ApiException(HttpStatus.NOT_FOUND, "RESOURCE_NOT_FOUND", "项目不存在"));

        assertThrows(ApiException.class, () -> controller.detail(authentication, projectId));
    }

    @Test
    void shouldArchiveProject() {
        when(authentication.getName()).thenReturn(userId.toString());
        ProjectDtos.ProjectView view = new ProjectDtos.ProjectView(
                projectId, "项目", "desc", null, "ARCHIVED", UUID.randomUUID(),
                "OWNER", now, now, now, 1L,
                Map.of(), 3L, 5L);
        when(projectUseCase.archive(eq(userId), eq(projectId))).thenReturn(view);

        var result = controller.archive(authentication, projectId);

        assertNotNull(result);
        assertEquals("ARCHIVED", result.getData().status());
    }

    @Test
    void shouldGetMembers() {
        when(authentication.getName()).thenReturn(userId.toString());
        ProjectDtos.MemberView member = new ProjectDtos.MemberView(
                UUID.randomUUID(), "成员", "m@test.com", null, "MEMBER",
                now, now, Map.of());
        when(projectUseCase.members(eq(userId), eq(projectId))).thenReturn(List.of(member));

        var result = controller.members(authentication, projectId);

        assertNotNull(result);
        assertEquals(1, result.getData().size());
        assertEquals("成员", result.getData().get(0).displayName());
    }

    @Test
    void shouldInviteUser() {
        when(authentication.getName()).thenReturn(userId.toString());
        ProjectDtos.InvitationView invView = new ProjectDtos.InvitationView(
                UUID.randomUUID(), projectId, "项目", UUID.randomUUID(),
                "user@test.com", "PENDING", now.plusSeconds(86400), now);
        when(projectUseCase.invite(eq(userId), eq(projectId), any())).thenReturn(invView);

        var result = controller.invite(authentication, projectId, new ProjectDtos.InviteRequest("user@test.com"));

        assertNotNull(result);
        assertEquals("PENDING", result.getData().status());
    }
}
