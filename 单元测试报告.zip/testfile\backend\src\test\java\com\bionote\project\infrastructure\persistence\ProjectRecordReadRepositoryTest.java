package com.bionote.project.infrastructure.persistence;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;

import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@ActiveProfiles("test")
@TestPropertySource(properties = {"spring.flyway.enabled=false", "spring.jpa.hibernate.ddl-auto=update"})
class ProjectRecordReadRepositoryTest {

    @Autowired private ProjectRecordReadRepository repository;

    private final UUID projectId = UUID.randomUUID();
    private final UUID creatorId = UUID.randomUUID();

    @BeforeEach
    void setUp() {
        repository.deleteAll();
    }

    @Test
    void shouldCountRecordsWhenNone() {
        long count = repository.countByProjectIdAndDeletedAtIsNullAndProvisionalFalse(projectId);
        assertEquals(0, count);
    }

    @Test
    void shouldFindRecordsNotCompleted() {
        var records = repository.findByProjectIdAndDeletedAtIsNullAndProvisionalFalseAndStatusNot(
                projectId, "COMPLETED");
        assertNotNull(records);
    }

    @Test
    void shouldFindCreatorRecordsNotCompleted() {
        var records = repository.findByProjectIdAndCreatorIdAndDeletedAtIsNullAndProvisionalFalseAndStatusNot(
                projectId, creatorId, "COMPLETED");
        assertNotNull(records);
    }

    @Test
    void shouldReturnEmptyForUnknownProject() {
        long count = repository.countByProjectIdAndDeletedAtIsNullAndProvisionalFalse(UUID.randomUUID());
        assertEquals(0, count);

        var blocking = repository.findByProjectIdAndDeletedAtIsNullAndProvisionalFalseAndStatusNot(
                UUID.randomUUID(), "COMPLETED");
        assertTrue(blocking.isEmpty());
    }
}
