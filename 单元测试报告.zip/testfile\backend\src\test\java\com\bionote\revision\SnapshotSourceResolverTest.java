package com.bionote.revision;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("SnapshotSourceResolver - 快照源解析器测试")
class SnapshotSourceResolverTest {

    @Mock private RevisionStore repository;
    @Mock private SnapshotNormalizer normalizer;
    @InjectMocks private SnapshotSourceResolver resolver;

    private final UUID actorId = UUID.randomUUID();
    private final UUID recordId = UUID.randomUUID();
    private final UUID revisionId = UUID.randomUUID();

    @Nested
    @DisplayName("revision - 解析修订快照")
    class RevisionTests {

        @Test
        @DisplayName("应正确委托给 repository 和 normalizer")
        void shouldDelegateToRepositoryAndNormalizer() {
            var sourceRef = new RevisionDtos.SnapshotSourceRef("REVISION", revisionId, 1, null, "hash");
            var sourceRecord = new RevisionStore.SourceRecord(sourceRef, 1, Map.of(), List.of(), null, null, null);
            when(repository.revisionSource(actorId, recordId, revisionId)).thenReturn(sourceRecord);
            var normalized = createSnapshot(sourceRef, "hash");
            when(normalizer.normalize(sourceRecord)).thenReturn(normalized);

            var result = resolver.revision(actorId, recordId, revisionId);

            assertNotNull(result);
            assertEquals("hash", result.canonicalHash());
            verify(repository).revisionSource(actorId, recordId, revisionId);
            verify(normalizer).normalize(sourceRecord);
        }

        @Test
        @DisplayName("repository 异常应向上传播")
        void shouldPropagateRepositoryException() {
            when(repository.revisionSource(actorId, recordId, revisionId))
                    .thenThrow(new RuntimeException("not found"));

            assertThrows(RuntimeException.class,
                    () -> resolver.revision(actorId, recordId, revisionId));
        }
    }

    @Nested
    @DisplayName("workingCopy - 解析工作副本快照")
    class WorkingCopyTests {

        @Test
        @DisplayName("应正确委托给 repository 和 normalizer")
        void shouldDelegateWorkingCopy() {
            var sourceRef = new RevisionDtos.SnapshotSourceRef("WORKING_COPY", null, null, 3L, "wc-hash");
            var sourceRecord = new RevisionStore.SourceRecord(sourceRef, 1, Map.of(), List.of(), null, null, 3L);
            when(repository.workingCopySource(actorId, recordId)).thenReturn(sourceRecord);
            var normalized = createSnapshot(sourceRef, "wc-hash");
            when(normalizer.normalize(sourceRecord)).thenReturn(normalized);

            var result = resolver.workingCopy(actorId, recordId);

            assertNotNull(result);
            assertEquals("wc-hash", result.canonicalHash());
            verify(repository).workingCopySource(actorId, recordId);
        }
    }

    private NormalizedRecordSnapshot createSnapshot(RevisionDtos.SnapshotSourceRef ref, String hash) {
        return new NormalizedRecordSnapshot(ref, recordId, Map.of(), Map.of(), List.of(),
                List.of(), List.of(), null, hash, List.of());
    }
}
