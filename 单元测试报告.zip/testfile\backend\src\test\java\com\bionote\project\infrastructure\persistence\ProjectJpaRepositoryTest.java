package com.bionote.project.infrastructure.persistence;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@ActiveProfiles("test")
@TestPropertySource(properties = {"spring.flyway.enabled=false", "spring.jpa.hibernate.ddl-auto=update"})
class ProjectJpaRepositoryTest {

    @Autowired private ProjectJpaRepository repository;

    @Test
    void shouldSaveAndFindProject() {
        UUID id = UUID.randomUUID();
        ProjectEntity entity = new ProjectEntity(id, "测试项目", "描述", null, UUID.randomUUID(), Instant.now());
        repository.save(entity);

        Optional<ProjectEntity> found = repository.findById(id);
        assertTrue(found.isPresent());
        assertEquals("测试项目", found.get().name);
        assertEquals("ACTIVE", found.get().status);
    }

    @Test
    void shouldReturnEmptyForUnknownId() {
        Optional<ProjectEntity> found = repository.findById(UUID.randomUUID());
        assertFalse(found.isPresent());
    }

    @Test
    void shouldArchiveActiveProject() {
        UUID id = UUID.randomUUID();
        ProjectEntity entity = new ProjectEntity(id, "项目", null, null, UUID.randomUUID(), Instant.now());
        repository.save(entity);

        int updated = repository.archiveActive(id, Instant.now());
        assertEquals(1, updated);
    }

    @Test
    void shouldNotArchiveAlreadyArchivedProject() {
        UUID id = UUID.randomUUID();
        ProjectEntity entity = new ProjectEntity(id, "项目", null, null, UUID.randomUUID(), Instant.now());
        repository.save(entity);

        repository.archiveActive(id, Instant.now());
        int secondArchive = repository.archiveActive(id, Instant.now());

        assertEquals(0, secondArchive);
    }

    @Test
    void shouldReturnZeroForNonexistentProjectArchive() {
        int result = repository.archiveActive(UUID.randomUUID(), Instant.now());
        assertEquals(0, result);
    }
}
