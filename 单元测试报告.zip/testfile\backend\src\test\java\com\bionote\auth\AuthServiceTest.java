package com.bionote.auth;

import com.bionote.common.ApiException;
import com.bionote.config.JwtService;
import com.bionote.user.User;
import com.bionote.user.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("AuthService - 认证服务测试")
class AuthServiceTest {

    @Mock private UserRepository users;
    @Mock private PasswordEncoder passwords;
    @Mock private JwtService jwt;
    @InjectMocks private AuthService authService;

    @Nested
    @DisplayName("register")
    class RegisterTests {

        @Test
        @DisplayName("注册成功应返回 AuthResult")
        void shouldRegisterSuccessfully() {
            var request = new AuthDtos.RegisterRequest("Alice", "alice@example.com", "password123");
            when(users.existsByEmailNormalized("alice@example.com")).thenReturn(false);
            when(passwords.encode("password123")).thenReturn("hashed-password");
            when(jwt.issue(any(UUID.class))).thenReturn("jwt-token-xyz");

            var result = authService.register(request);

            assertNotNull(result);
            assertEquals("jwt-token-xyz", result.accessToken());
            assertNotNull(result.user());
            assertEquals("Alice", result.user().displayName());
            verify(users).saveAndFlush(any(User.class));
        }

        @Test
        @DisplayName("邮箱已注册应抛出 CONFLICT 异常")
        void shouldThrowConflictWhenEmailExists() {
            var request = new AuthDtos.RegisterRequest("Bob", "bob@example.com", "password123");
            when(users.existsByEmailNormalized("bob@example.com")).thenReturn(true);

            var ex = assertThrows(ApiException.class, () -> authService.register(request));
            assertEquals(HttpStatus.CONFLICT, ex.status());
            assertEquals("DUPLICATE_RESOURCE", ex.code());
            verify(users, never()).saveAndFlush(any());
        }

        @Test
        @DisplayName("邮箱格式无效应抛出 BAD_REQUEST 异常")
        void shouldThrowBadRequestForInvalidEmail() {
            var request = new AuthDtos.RegisterRequest("Charlie", "not-an-email", "password123");

            var ex = assertThrows(ApiException.class, () -> authService.register(request));
            assertEquals(HttpStatus.BAD_REQUEST, ex.status());
            assertEquals("VALIDATION_ERROR", ex.code());
        }

        @Test
        @DisplayName("邮箱带空格应被 trim 并 lowercased")
        void shouldTrimAndLowercaseEmail() {
            var request = new AuthDtos.RegisterRequest("Dave", "  DAVE@EXAMPLE.COM  ", "password123");
            when(users.existsByEmailNormalized("dave@example.com")).thenReturn(false);
            when(passwords.encode(anyString())).thenReturn("hashed");
            when(jwt.issue(any())).thenReturn("token");

            authService.register(request);

            verify(users).existsByEmailNormalized("dave@example.com");
        }
    }

    @Nested
    @DisplayName("login")
    class LoginTests {

        @Test
        @DisplayName("登录成功应返回 AuthResult")
        void shouldLoginSuccessfully() {
            var request = new AuthDtos.LoginRequest("alice@example.com", "password123");
            var user = new User(UUID.randomUUID(), "Alice", "alice@example.com", "hashed-password", null);
            when(users.findByEmailNormalized("alice@example.com")).thenReturn(Optional.of(user));
            when(passwords.matches("password123", "hashed-password")).thenReturn(true);
            when(jwt.issue(user.getId())).thenReturn("jwt-token");

            var result = authService.login(request);

            assertNotNull(result);
            assertEquals("jwt-token", result.accessToken());
            assertEquals("Alice", result.user().displayName());
        }

        @Test
        @DisplayName("密码错误应抛出 UNAUTHORIZED 异常")
        void shouldThrowUnauthorizedForWrongPassword() {
            var request = new AuthDtos.LoginRequest("alice@example.com", "wrong-password");
            var user = new User(UUID.randomUUID(), "Alice", "alice@example.com", "hashed-password", null);
            when(users.findByEmailNormalized("alice@example.com")).thenReturn(Optional.of(user));
            when(passwords.matches("wrong-password", "hashed-password")).thenReturn(false);

            var ex = assertThrows(ApiException.class, () -> authService.login(request));
            assertEquals(HttpStatus.UNAUTHORIZED, ex.status());
            assertEquals("INVALID_CREDENTIALS", ex.code());
        }

        @Test
        @DisplayName("用户不存在应抛出 UNAUTHORIZED 异常")
        void shouldThrowUnauthorizedWhenUserNotFound() {
            var request = new AuthDtos.LoginRequest("unknown@example.com", "password");
            when(users.findByEmailNormalized("unknown@example.com")).thenReturn(Optional.empty());

            var ex = assertThrows(ApiException.class, () -> authService.login(request));
            assertEquals(HttpStatus.UNAUTHORIZED, ex.status());
            assertEquals("INVALID_CREDENTIALS", ex.code());
        }
    }

    @Nested
    @DisplayName("currentUser")
    class CurrentUserTests {

        @Test
        @DisplayName("已存在用户应返回 UserView")
        void shouldReturnCurrentUser() {
            var userId = UUID.randomUUID();
            var user = new User(userId, "Alice", "alice@example.com", "hash", null);
            when(users.findById(userId)).thenReturn(Optional.of(user));

            var result = authService.currentUser(userId);

            assertNotNull(result);
            assertEquals(userId, result.id());
            assertEquals("Alice", result.displayName());
            assertEquals("alice@example.com", result.email());
        }

        @Test
        @DisplayName("用户不存在应抛出 NOT_FOUND 异常")
        void shouldThrowNotFoundForMissingUser() {
            var userId = UUID.randomUUID();
            when(users.findById(userId)).thenReturn(Optional.empty());

            var ex = assertThrows(ApiException.class, () -> authService.currentUser(userId));
            assertEquals(HttpStatus.NOT_FOUND, ex.status());
            assertEquals("RESOURCE_NOT_FOUND", ex.code());
        }

        @Test
        @DisplayName("有 avatar 的用户应返回 avatar URL")
        void shouldReturnAvatarUrlForUserWithAvatar() {
            var userId = UUID.randomUUID();
            var user = spy(new User(userId, "Bob", "bob@test.com", "hash", null));
            when(users.findById(userId)).thenReturn(Optional.of(user));
            when(user.getAvatarStorageKey()).thenReturn("avatars/bob.png");
            when(user.getCreatedAt()).thenReturn(null);
            when(user.getUpdatedAt()).thenReturn(null);

            var result = authService.currentUser(userId);

            assertNotNull(result.avatarUrl());
            assertTrue(result.avatarUrl().contains("/api/v1/users/"));
            assertTrue(result.avatarUrl().contains("/avatar"));
        }
    }
}
