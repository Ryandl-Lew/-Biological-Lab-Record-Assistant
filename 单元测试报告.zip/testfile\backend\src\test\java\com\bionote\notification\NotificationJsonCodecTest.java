package com.bionote.notification;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class NotificationJsonCodecTest {

    @Mock
    private ObjectMapper objectMapper;

    @InjectMocks
    private NotificationJsonCodec codec;

    @Test
    void encode_shouldReturnJsonString() throws Exception {
        Map<String, Object> payload = Map.of("key", "value", "num", 42);
        when(objectMapper.writeValueAsString(payload)).thenReturn("{\"key\":\"value\",\"num\":42}");

        String result = codec.encode(payload);

        assertEquals("{\"key\":\"value\",\"num\":42}", result);
    }

    @Test
    void encode_shouldThrowIllegalArgumentExceptionOnFailure() throws Exception {
        Map<String, Object> payload = Map.of("bad", new Object()); // This will cause issues
        when(objectMapper.writeValueAsString(any())).thenThrow(new RuntimeException("serialization error"));

        assertThrows(IllegalArgumentException.class, () -> codec.encode(payload));
    }

    @Test
    void decode_shouldReturnDecodedMap() throws Exception {
        String json = "{\"hello\":\"world\"}";
        Map<String, Object> expected = Map.of("hello", "world");
        when(objectMapper.readValue(eq(json), any(com.fasterxml.jackson.core.type.TypeReference.class)))
                .thenReturn(expected);

        Map<String, Object> result = codec.decode(json);

        assertEquals(expected, result);
    }

    @Test
    void decode_shouldReturnEmptyMapOnFailure() throws Exception {
        when(objectMapper.readValue(anyString(), any(com.fasterxml.jackson.core.type.TypeReference.class)))
                .thenThrow(new RuntimeException("parse error"));

        Map<String, Object> result = codec.decode("invalid json");

        assertTrue(result.isEmpty());
    }

    @Test
    void encode_shouldHandleEmptyMap() throws Exception {
        when(objectMapper.writeValueAsString(Map.of())).thenReturn("{}");

        String result = codec.encode(Map.of());

        assertEquals("{}", result);
    }

    @Test
    void decode_shouldHandleEmptyString() throws Exception {
        when(objectMapper.readValue(eq(""), any(com.fasterxml.jackson.core.type.TypeReference.class)))
                .thenReturn(Map.of());

        Map<String, Object> result = codec.decode("");

        assertNotNull(result);
    }
}
