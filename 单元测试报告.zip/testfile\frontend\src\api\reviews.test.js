import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('./client', () => ({ request: vi.fn() }))

import { request } from './client'
import {
  fetchReviewerCandidates,
  submitRecord,
  requestReviewChanges,
  approveReview,
  fetchPendingReviews,
} from './reviews'

describe('reviews API', () => {
  beforeEach(() => {
    request.mockReset()
  })

  describe('fetchReviewerCandidates', () => {
    it('sends GET /records/:id/reviewer-candidates', async () => {
      request.mockResolvedValueOnce([{ userId: 'u1', displayName: '用户1' }])
      const result = await fetchReviewerCandidates('rec-1')
      expect(request).toHaveBeenCalledWith('/records/rec-1/reviewer-candidates')
      expect(result).toEqual([{ userId: 'u1', displayName: '用户1' }])
    })
  })

  describe('submitRecord', () => {
    it('sends POST /records/:id/submissions with input and Idempotency-Key header', async () => {
      const cryptoSpy = vi.spyOn(crypto, 'randomUUID').mockReturnValue('fixed-uuid-1234')
      request.mockResolvedValueOnce({ submissionId: 'sub-1' })

      const input = { reviewerIds: ['u2', 'u3'] }
      const result = await submitRecord('rec-1', input)

      expect(request).toHaveBeenCalledWith('/records/rec-1/submissions', {
        method: 'POST',
        headers: { 'Idempotency-Key': 'fixed-uuid-1234' },
        body: JSON.stringify(input),
      })
      expect(result).toEqual({ submissionId: 'sub-1' })

      cryptoSpy.mockRestore()
    })

    it('accepts custom idempotencyKey', async () => {
      request.mockResolvedValueOnce({ submissionId: 'sub-2' })

      await submitRecord('rec-1', { reviewerIds: ['u2'] }, 'custom-key')
      expect(request).toHaveBeenCalledWith('/records/rec-1/submissions', {
        method: 'POST',
        headers: { 'Idempotency-Key': 'custom-key' },
        body: JSON.stringify({ reviewerIds: ['u2'] }),
      })
    })
  })

  describe('requestReviewChanges', () => {
    it('sends POST /records/:id/reviews/:reviewId/request-changes with comment', async () => {
      request.mockResolvedValueOnce({ status: 'CHANGES_REQUESTED' })
      await requestReviewChanges('rec-1', 'rev-1', '请修改数据部分')
      expect(request).toHaveBeenCalledWith('/records/rec-1/reviews/rev-1/request-changes', {
        method: 'POST',
        body: JSON.stringify({ comment: '请修改数据部分' }),
      })
    })
  })

  describe('approveReview', () => {
    it('sends POST /records/:id/reviews/:reviewId/approve with comment', async () => {
      request.mockResolvedValueOnce({ status: 'APPROVED' })
      await approveReview('rec-1', 'rev-2', '审核通过')
      expect(request).toHaveBeenCalledWith('/records/rec-1/reviews/rev-2/approve', {
        method: 'POST',
        body: JSON.stringify({ comment: '审核通过' }),
      })
    })
  })

  describe('fetchPendingReviews', () => {
    it('sends GET /reviews/pending', async () => {
      request.mockResolvedValueOnce([{ id: 'rev-1', status: 'PENDING' }])
      const result = await fetchPendingReviews()
      expect(request).toHaveBeenCalledWith('/reviews/pending')
      expect(result).toEqual([{ id: 'rev-1', status: 'PENDING' }])
    })
  })
})
