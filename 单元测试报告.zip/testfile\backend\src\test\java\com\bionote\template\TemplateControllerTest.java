package com.bionote.template;

import com.bionote.common.PagedResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TemplateControllerTest {

    @Mock
    private TemplateUseCase service;

    @InjectMocks
    private TemplateController controller;

    private static final UUID USER_ID = UUID.randomUUID();
    private static final UUID TEMPLATE_ID = UUID.randomUUID();

    @Test
    void list_shouldReturnPagedResponse() {
        Instant now = Instant.now();
        TemplateDtos.View view = new TemplateDtos.View(
                TEMPLATE_ID, "PERSONAL", USER_ID, "模板", "化学", "分类",
                "描述", now, now, 1L, List.of(), true, true
        );
        PagedResponse<TemplateDtos.View> expected = PagedResponse.of(List.of(view), 0, 20, 1);
        when(service.list(USER_ID, null, null, "", 0, 20)).thenReturn(expected);

        PagedResponse<TemplateDtos.View> result = service.list(USER_ID, null, null, "", 0, 20);

        assertNotNull(result);
        assertEquals(1, result.data().size());
    }

    @Test
    void create_shouldReturnCreatedTemplate() {
        Instant now = Instant.now();
        TemplateDtos.View view = new TemplateDtos.View(
                TEMPLATE_ID, "PERSONAL", USER_ID, "新模板", "物理", "力学",
                "描述", now, now, 0L, List.of(), true, true
        );
        TemplateDtos.SaveRequest request = new TemplateDtos.SaveRequest(
                "新模板", "物理", "力学", "描述",
                List.of(new TemplateDtos.FieldRequest("f", "F", "NUMBER", false, "", null, List.of())),
                null
        );
        when(service.create(USER_ID, request)).thenReturn(view);

        TemplateDtos.View result = service.create(USER_ID, request);

        assertNotNull(result);
        assertEquals("新模板", result.name());
    }

    @Test
    void get_shouldReturnTemplate() {
        Instant now = Instant.now();
        TemplateDtos.View view = new TemplateDtos.View(
                TEMPLATE_ID, "SYSTEM", UUID.randomUUID(), "系统模板", "通用", "分类",
                "描述", now, now, 0L, List.of(), false, false
        );
        when(service.get(USER_ID, TEMPLATE_ID)).thenReturn(view);

        TemplateDtos.View result = service.get(USER_ID, TEMPLATE_ID);

        assertNotNull(result);
        assertEquals("系统模板", result.name());
    }

    @Test
    void update_shouldReturnUpdatedTemplate() {
        Instant now = Instant.now();
        TemplateDtos.View view = new TemplateDtos.View(
                TEMPLATE_ID, "PERSONAL", USER_ID, "更新模板", "化学", "实验",
                "更新描述", now, now, 2L, List.of(), true, true
        );
        TemplateDtos.SaveRequest request = new TemplateDtos.SaveRequest(
                "更新模板", "化学", "实验", "更新描述",
                List.of(), 2L
        );
        when(service.update(USER_ID, TEMPLATE_ID, request)).thenReturn(view);

        TemplateDtos.View result = service.update(USER_ID, TEMPLATE_ID, request);

        assertNotNull(result);
        assertEquals("更新模板", result.name());
        assertEquals(2L, result.version());
    }

    @Test
    void delete_shouldCallServiceDelete() {
        doNothing().when(service).delete(USER_ID, TEMPLATE_ID);

        service.delete(USER_ID, TEMPLATE_ID);

        verify(service).delete(USER_ID, TEMPLATE_ID);
    }

    @Test
    void copy_shouldReturnCopiedTemplate() {
        Instant now = Instant.now();
        UUID newTemplateId = UUID.randomUUID();
        TemplateDtos.View view = new TemplateDtos.View(
                newTemplateId, "PERSONAL", USER_ID, "原模板 副本", "化学", "实验",
                "描述", now, now, 0L, List.of(), true, true
        );
        when(service.copy(USER_ID, TEMPLATE_ID)).thenReturn(view);

        TemplateDtos.View result = service.copy(USER_ID, TEMPLATE_ID);

        assertNotNull(result);
        assertTrue(result.name().contains("副本"));
    }
}
