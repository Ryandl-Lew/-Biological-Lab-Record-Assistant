package com.bionote.template.infrastructure.persistence;

import org.junit.jupiter.api.Test;
import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class RecordTemplateEntityTest {

    private static final UUID ID = UUID.randomUUID();
    private static final UUID OWNER_ID = UUID.randomUUID();
    private static final Instant NOW = Instant.now();

    @Test
    void constructor_shouldInitializeAllFields() {
        RecordTemplateEntity entity = new RecordTemplateEntity(
                ID, OWNER_ID, "实验模板", "实验模板",
                "active-key", "化学", "实验", "记录模板描述", NOW
        );

        assertEquals(ID, entity.id);
        assertEquals("PERSONAL", entity.scope);
        assertEquals(OWNER_ID, entity.ownerId);
        assertEquals("实验模板", entity.name);
        assertEquals("实验模板", entity.nameNormalized);
        assertEquals("active-key", entity.activeNameKey);
        assertEquals("化学", entity.experimentType);
        assertEquals("实验", entity.category);
        assertEquals("记录模板描述", entity.description);
        assertEquals(NOW, entity.createdAt);
        assertEquals(NOW, entity.updatedAt);
        assertNull(entity.deletedAt);
    }

    @Test
    void update_shouldModifyFields() {
        RecordTemplateEntity entity = new RecordTemplateEntity(
                ID, OWNER_ID, "旧名称", "旧名称",
                "old-key", "物理", "力学", "旧描述", NOW
        );

        Instant later = NOW.plusSeconds(3600);
        entity.update("新名称", "新名称", "new-key", "生物", "细胞", "新描述", later);

        assertEquals("新名称", entity.name);
        assertEquals("新名称", entity.nameNormalized);
        assertEquals("new-key", entity.activeNameKey);
        assertEquals("生物", entity.experimentType);
        assertEquals("细胞", entity.category);
        assertEquals("新描述", entity.description);
        assertEquals(later, entity.updatedAt);
        assertEquals(NOW, entity.createdAt); // createdAt should not change
    }

    @Test
    void softDelete_shouldSetDeletedAt() {
        RecordTemplateEntity entity = new RecordTemplateEntity(
                ID, OWNER_ID, "模板", "模板",
                "key", "化学", "实验", "描述", NOW
        );

        Instant deleteTime = NOW.plusSeconds(7200);
        entity.softDelete(deleteTime);

        assertEquals(deleteTime, entity.deletedAt);
        assertNull(entity.activeNameKey);
        assertEquals(deleteTime, entity.updatedAt);
    }

    @Test
    void protectedConstructor_shouldCreateEmptyEntity() {
        try {
            var constructor = RecordTemplateEntity.class.getDeclaredConstructor();
            constructor.setAccessible(true);
            RecordTemplateEntity entity = constructor.newInstance();

            assertNotNull(entity);
            assertNull(entity.id);
            assertNull(entity.name);
        } catch (Exception e) {
            fail("Should create entity via protected constructor: " + e.getMessage());
        }
    }

    @Test
    void versionShouldDefaultToZero() {
        try {
            var constructor = RecordTemplateEntity.class.getDeclaredConstructor();
            constructor.setAccessible(true);
            RecordTemplateEntity entity = constructor.newInstance();

            assertEquals(0L, entity.version);
        } catch (Exception e) {
            fail("Version field should be accessible: " + e.getMessage());
        }
    }
}
