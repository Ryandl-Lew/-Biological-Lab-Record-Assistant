package com.bionote.user;

import org.junit.jupiter.api.Test;
import java.time.Instant;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class UserDtosTest {

    @Test
    void shouldCreateUserViewWithAllFields() {
        UUID id = UUID.randomUUID();
        Instant createdAt = Instant.now();
        Instant updatedAt = Instant.now();
        UserDtos.UserView view = new UserDtos.UserView(id, "用户1", "user@test.com",
                "/api/v1/users/" + id + "/avatar", createdAt, updatedAt);

        assertEquals(id, view.id());
        assertEquals("用户1", view.displayName());
        assertEquals("user@test.com", view.email());
        assertEquals("/api/v1/users/" + id + "/avatar", view.avatarUrl());
        assertEquals(createdAt, view.createdAt());
        assertEquals(updatedAt, view.updatedAt());
    }

    @Test
    void shouldCreateUserViewWithNullAvatar() {
        UUID id = UUID.randomUUID();
        Instant now = Instant.now();
        UserDtos.UserView view = new UserDtos.UserView(id, "用户", "a@b.com", null, now, now);

        assertNull(view.avatarUrl());
    }

    @Test
    void shouldCreateUpdateProfileRequestWithValidData() {
        UserDtos.UpdateProfileRequest request = new UserDtos.UpdateProfileRequest("新显示名");
        assertEquals("新显示名", request.displayName());
    }

    @Test
    void shouldCreateUpdateProfileRequestWithMaxLength() {
        String longName = "A".repeat(50);
        UserDtos.UpdateProfileRequest request = new UserDtos.UpdateProfileRequest(longName);
        assertEquals(50, request.displayName().length());
    }

    @Test
    void shouldPreventInstantiation() {
        assertThrows(java.lang.reflect.InvocationTargetException.class, () -> {
            var ctor = UserDtos.class.getDeclaredConstructor();
            ctor.setAccessible(true);
            ctor.newInstance();
        });
    }
}
