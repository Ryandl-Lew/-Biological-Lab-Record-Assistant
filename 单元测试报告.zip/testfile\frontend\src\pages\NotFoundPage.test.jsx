import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import NotFoundPage from '@/pages/NotFoundPage';

vi.mock('lucide-react', () => ({
  Home: () => <span data-testid="icon-home">HomeIcon</span>,
}));

vi.mock('@/components/ui', () => ({
  Button: ({ to, children, icon: Icon, className }) => (
    <a href={to} className={className} data-testid="notfound-button">
      {Icon && <Icon />}
      {children}
    </a>
  ),
}));

describe('NotFoundPage', () => {
  function renderPage() {
    return render(
      <MemoryRouter>
        <NotFoundPage />
      </MemoryRouter>,
    );
  }

  it('should display the 404 status code', () => {
    renderPage();
    expect(screen.getByText('404')).toBeInTheDocument();
  });

  it('should display "页面不存在" heading', () => {
    renderPage();
    expect(screen.getByText('页面不存在')).toBeInTheDocument();
  });

  it('should display a description message', () => {
    renderPage();
    expect(
      screen.getByText('你访问的页面可能已被移动或删除。'),
    ).toBeInTheDocument();
  });

  it('should render a button linking back to home', () => {
    renderPage();
    const button = screen.getByTestId('notfound-button');
    expect(button).toBeInTheDocument();
    expect(button).toHaveAttribute('href', '/');
    expect(screen.getByText('返回工作台')).toBeInTheDocument();
  });

  it('should render the Home icon inside the button', () => {
    renderPage();
    expect(screen.getByTestId('icon-home')).toBeInTheDocument();
  });
});
