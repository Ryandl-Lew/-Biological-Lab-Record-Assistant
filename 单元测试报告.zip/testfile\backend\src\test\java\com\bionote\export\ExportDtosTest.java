package com.bionote.export;

import org.junit.jupiter.api.Test;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.time.Instant;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ExportDtosTest {

    @Test
    void preview_shouldHoldHtmlAndReport() {
        RecordReportModel model = new RecordReportModel(
                "title", "code", "project", "type",
                LocalDate.of(2025, 1, 1), "creator", "purpose",
                List.of(), "<html></html>", "text", 1,
                "reviewer", Instant.now(), "ok", List.of()
        );
        ExportDtos.Preview preview = new ExportDtos.Preview("<p>test</p>", model);

        assertEquals("<p>test</p>", preview.html());
        assertSame(model, preview.report());
    }

    @Test
    void preview_shouldHandleNullHtml() {
        RecordReportModel model = new RecordReportModel(
                "t", "c", "p", "e", LocalDate.now(),
                "cr", "pu", List.of(), "", "", 0,
                "rv", Instant.now(), null, List.of()
        );
        ExportDtos.Preview preview = new ExportDtos.Preview(null, model);

        assertNull(preview.html());
        assertNotNull(preview.report());
    }

    @Test
    void fileExport_shouldContainAllFields() {
        byte[] bytes = "content".getBytes(StandardCharsets.UTF_8);
        ExportDtos.FileExport file = new ExportDtos.FileExport(bytes, "test.md", "text/markdown");

        assertArrayEquals(bytes, file.bytes());
        assertEquals("test.md", file.filename());
        assertEquals("text/markdown", file.mediaType());
    }

    @Test
    void fileExport_shouldHandleEmptyBytes() {
        ExportDtos.FileExport file = new ExportDtos.FileExport(new byte[0], "empty.pdf", "application/pdf");

        assertEquals(0, file.bytes().length);
        assertEquals("empty.pdf", file.filename());
    }

    @Test
    void fileExport_shouldHandleNullMediaType() {
        ExportDtos.FileExport file = new ExportDtos.FileExport(new byte[]{1, 2}, "f.txt", null);

        assertArrayEquals(new byte[]{1, 2}, file.bytes());
        assertNull(file.mediaType());
    }
}
