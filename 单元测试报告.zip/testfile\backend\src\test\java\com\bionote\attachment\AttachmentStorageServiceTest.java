package com.bionote.attachment;

import com.bionote.common.ApiException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.junit.jupiter.api.io.TempDir;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockMultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("AttachmentStorageService 测试")
class AttachmentStorageServiceTest {

    private AttachmentStorageService storageService;

    @BeforeEach
    void setUp(@TempDir Path tempDir) {
        storageService = new AttachmentStorageService(tempDir.toString(), 20 * 1024 * 1024);
    }

    @Test
    @DisplayName("存储有效的 PNG 图片应返回 StoredFile")
    void shouldStoreValidPng() {
        byte[] pngContent = {(byte)0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d, 0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x08, 0x02, 0x00, 0x00, 0x00, 0x01, 0x02, 0x03, 0x04};
        MockMultipartFile file = new MockMultipartFile("file", "test.png", "image/png", pngContent);

        AttachmentStorage.StoredFile result = storageService.store(file);

        assertNotNull(result);
        assertEquals("test.png", result.originalFilename());
        assertEquals("image/png", result.mediaType());
        assertNotNull(result.storageKey());
        assertTrue(result.previewable());
    }

    @Test
    @DisplayName("存储有效的 JPG 图片应返回 StoredFile")
    void shouldStoreValidJpg() {
        byte[] jpgContent = {(byte)0xff, (byte)0xd8, (byte)0xff, (byte)0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0x01};
        MockMultipartFile file = new MockMultipartFile("file", "photo.jpg", "image/jpeg", jpgContent);

        AttachmentStorage.StoredFile result = storageService.store(file);

        assertNotNull(result);
        assertEquals("photo.jpg", result.originalFilename());
        assertEquals("image/jpeg", result.mediaType());
    }

    @Test
    @DisplayName("空文件应抛出异常")
    void shouldThrowWhenFileEmpty() {
        MockMultipartFile file = new MockMultipartFile("file", "test.png", "image/png", new byte[0]);

        ApiException ex = assertThrows(ApiException.class, () -> storageService.store(file));
        assertEquals("INVALID_ATTACHMENT", ex.code());
        assertEquals("附件不能为空", ex.getMessage());
    }

    @Test
    @DisplayName("文件超过大小限制应抛异常")
    void shouldThrowWhenFileTooLarge(@TempDir Path tempDir) {
        AttachmentStorageService smallService = new AttachmentStorageService(tempDir.toString(), 1L);
        byte[] content = new byte[10];
        MockMultipartFile file = new MockMultipartFile("file", "test.png", "image/png", content);

        ApiException ex = assertThrows(ApiException.class, () -> smallService.store(file));
        assertEquals("INVALID_ATTACHMENT", ex.code());
        assertTrue(ex.getMessage().contains("20"));
    }

    @Test
    @DisplayName("不支持的文件类型应抛异常")
    void shouldThrowForUnsupportedType() {
        MockMultipartFile file = new MockMultipartFile("file", "test.exe", "application/octet-stream", new byte[]{1, 2, 3, 4});

        ApiException ex = assertThrows(ApiException.class, () -> storageService.store(file));
        assertEquals("INVALID_ATTACHMENT", ex.code());
        assertTrue(ex.getMessage().contains("不支持的文件类型"));
    }

    @Test
    @DisplayName("双扩展名文件应抛异常")
    void shouldThrowForDoubleExtension() {
        byte[] pngContent = {(byte)0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d, 0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x08, 0x02, 0x00, 0x00, 0x00, 0x01, 0x02, 0x03, 0x04};
        MockMultipartFile file = new MockMultipartFile("file", "test.tar.gz", "image/png", pngContent);

        ApiException ex = assertThrows(ApiException.class, () -> storageService.store(file));
        assertEquals("INVALID_ATTACHMENT", ex.code());
        assertTrue(ex.getMessage().contains("双扩展名"));
    }

    @Test
    @DisplayName("MIME 类型与扩展名不匹配应抛异常")
    void shouldThrowWhenMimeMismatch() {
        byte[] jpgContent = {(byte)0xff, (byte)0xd8, (byte)0xff, (byte)0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0x01};
        MockMultipartFile file = new MockMultipartFile("file", "photo.jpg", "text/plain", jpgContent);

        ApiException ex = assertThrows(ApiException.class, () -> storageService.store(file));
        assertEquals("INVALID_ATTACHMENT", ex.code());
    }

    @Test
    @DisplayName("文件内容签名与扩展名不匹配应抛异常")
    void shouldThrowWhenSignatureMismatch() {
        MockMultipartFile file = new MockMultipartFile("file", "test.png", "image/png", new byte[]{0, 1, 2, 3, 4, 5, 6, 7, 8});

        ApiException ex = assertThrows(ApiException.class, () -> storageService.store(file));
        assertEquals("INVALID_ATTACHMENT", ex.code());
    }

    @Test
    @DisplayName("read 应返回存储的字节内容")
    void shouldReadStoredFile() {
        byte[] jpgContent = {(byte)0xff, (byte)0xd8, (byte)0xff, (byte)0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0x01};
        MockMultipartFile file = new MockMultipartFile("file", "photo.jpg", "image/jpeg", jpgContent);
        AttachmentStorage.StoredFile stored = storageService.store(file);

        byte[] result = storageService.read(stored.storageKey());

        assertArrayEquals(jpgContent, result);
    }

    @Test
    @DisplayName("read 不存在的 key 应抛异常")
    void shouldThrowWhenReadingNonExistentKey() {
        ApiException ex = assertThrows(ApiException.class,
                () -> storageService.read("00000000-0000-0000-0000-000000000000"));
        assertEquals("RESOURCE_NOT_FOUND", ex.code());
    }

    @Test
    @DisplayName("exists 应正确判断文件是否存在")
    void shouldCheckFileExistence() {
        byte[] jpgContent = {(byte)0xff, (byte)0xd8, (byte)0xff, (byte)0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0x01};
        MockMultipartFile file = new MockMultipartFile("file", "photo.jpg", "image/jpeg", jpgContent);
        AttachmentStorage.StoredFile stored = storageService.store(file);

        assertTrue(storageService.exists(stored.storageKey()));
        assertFalse(storageService.exists("00000000-0000-0000-0000-000000000000"));
    }

    @Test
    @DisplayName("deleteQuietly 删除文件不应抛异常")
    void shouldDeleteFileQuietly(@TempDir Path tempDir) throws IOException {
        AttachmentStorageService svc = new AttachmentStorageService(tempDir.toString(), 20 * 1024 * 1024);
        byte[] pngContent = {(byte)0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0x00, 0x00, 0x00, 0x0d, 0x49, 0x48, 0x44, 0x52, 0x00, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x01, 0x08, 0x02, 0x00, 0x00, 0x00, 0x01, 0x02, 0x03, 0x04};
        MockMultipartFile file = new MockMultipartFile("file", "test.png", "image/png", pngContent);
        AttachmentStorage.StoredFile stored = svc.store(file);

        assertDoesNotThrow(() -> svc.deleteQuietly(stored.storageKey()));
        assertFalse(svc.exists(stored.storageKey()));
    }

    @Test
    @DisplayName("deleteQuietly 对不存在的 key 不应抛异常")
    void shouldNotThrowDeletingNonExistentKey() {
        assertDoesNotThrow(() -> storageService.deleteQuietly("00000000-0000-0000-0000-000000000000"));
    }
}
