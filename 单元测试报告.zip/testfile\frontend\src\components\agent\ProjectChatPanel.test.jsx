import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, fireEvent, act } from '@testing-library/react';
import ProjectChatPanel from '@/components/agent/ProjectChatPanel';

vi.mock('@/api/agentChat', () => ({
  deleteProjectAgentReference: vi.fn(),
  sendProjectAgentChat: vi.fn(),
  uploadProjectAgentReference: vi.fn(),
}));

vi.mock('@/components/ui', () => ({
  Button: ({ children, onClick, loading, disabled, variant, size, type, className, ...rest }) => (
    <button onClick={onClick} disabled={disabled || loading} data-variant={variant} {...rest}>
      {loading ? 'loading...' : children}
    </button>
  ),
  Surface: ({ title, children, extra }) => (
    <section data-testid="chat-surface">
      <header>
        <h2>{title}</h2>
        {extra}
      </header>
      {children}
    </section>
  ),
}));

vi.mock('@/components/agent/messages', () => ({
  agentErrorMessage: vi.fn(() => '代理错误'),
  trimChatHistory: vi.fn((msgs) => msgs.slice(-20)),
}));

vi.mock('@/components/agent/DataChart', () => ({
  default: () => <div data-testid="data-chart">Chart</div>,
}));

vi.mock('@/components/agent/AgentHelpDialog', () => ({
  default: ({ open, onClose }) => (open ? <div data-testid="help-dialog" onClick={onClose}>Help</div> : null),
}));

const { sendProjectAgentChat } = await import('@/api/agentChat');

describe('ProjectChatPanel', () => {
  const project = { id: 'p1' };

  beforeEach(() => {
    vi.clearAllMocks();
    sendProjectAgentChat.mockResolvedValue({ reply: '收到', fit: null, fits: [], proposal: null, analysisTemplate: null, chart: null });
  });

  it('renders "项目问答" title', () => {
    render(<ProjectChatPanel project={project} />);
    expect(screen.getByText('项目问答')).toBeInTheDocument();
  });

  it('renders help button', () => {
    render(<ProjectChatPanel project={project} />);
    expect(screen.getByText('帮助')).toBeInTheDocument();
  });

  it('opens help dialog when help button clicked', () => {
    render(<ProjectChatPanel project={project} />);
    fireEvent.click(screen.getByText('帮助'));
    expect(screen.getByTestId('help-dialog')).toBeInTheDocument();
  });

  it('renders text input area', () => {
    render(<ProjectChatPanel project={project} />);
    expect(screen.getByPlaceholderText(/输入问题/)).toBeInTheDocument();
  });

  it('renders send button', () => {
    render(<ProjectChatPanel project={project} />);
    expect(screen.getByText('发送')).toBeInTheDocument();
  });

  it('shows placeholder hint when no messages', () => {
    render(<ProjectChatPanel project={project} />);
    expect(screen.getByText(/试试：线性拟合/)).toBeInTheDocument();
  });

  it('sends message and shows reply', async () => {
    render(<ProjectChatPanel project={project} />);
    const input = screen.getByPlaceholderText(/输入问题/);
    await act(async () => {
      fireEvent.change(input, { target: { value: '你好' } });
      fireEvent.click(screen.getByText('发送'));
    });
    expect(screen.getByText('收到')).toBeInTheDocument();
  });
});
