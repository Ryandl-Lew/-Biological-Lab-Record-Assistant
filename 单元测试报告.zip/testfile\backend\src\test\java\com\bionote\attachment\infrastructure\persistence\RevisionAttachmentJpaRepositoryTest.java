package com.bionote.attachment.infrastructure.persistence;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.TestPropertySource;

import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@TestPropertySource(properties = {"spring.flyway.enabled=false", "spring.jpa.hibernate.ddl-auto=update"})
@DisplayName("RevisionAttachmentJpaRepository 测试")
class RevisionAttachmentJpaRepositoryTest {

    @Autowired
    private RevisionAttachmentJpaRepository repository;

    @Test
    @DisplayName("save 和 findById 应正确工作")
    void shouldSaveAndFindById() {
        UUID revisionId = UUID.randomUUID();
        UUID attachmentId = UUID.randomUUID();
        RevisionAttachmentId id = new RevisionAttachmentId(revisionId, attachmentId);
        RevisionAttachmentEntity entity = new RevisionAttachmentEntity(id, 0);
        repository.saveAndFlush(entity);

        var found = repository.findById(id);

        assertTrue(found.isPresent());
        assertEquals(0, found.get().sortOrder);
    }

    @Test
    @DisplayName("findByIdRevisionIdOrderBySortOrderAsc 应按 sortOrder 排序返回")
    void shouldFindByRevisionIdOrderedBySortOrder() {
        UUID revisionId = UUID.randomUUID();
        UUID a1 = UUID.randomUUID();
        UUID a2 = UUID.randomUUID();
        UUID a3 = UUID.randomUUID();

        repository.saveAllAndFlush(List.of(
                new RevisionAttachmentEntity(new RevisionAttachmentId(revisionId, a2), 1),
                new RevisionAttachmentEntity(new RevisionAttachmentId(revisionId, a1), 0),
                new RevisionAttachmentEntity(new RevisionAttachmentId(revisionId, a3), 2)
        ));

        List<RevisionAttachmentEntity> result = repository.findByIdRevisionIdOrderBySortOrderAsc(revisionId);

        assertEquals(3, result.size());
        assertEquals(a1, result.get(0).id.attachmentId);
        assertEquals(a2, result.get(1).id.attachmentId);
        assertEquals(a3, result.get(2).id.attachmentId);
    }

    @Test
    @DisplayName("不存在的 revisionId 应返回空列表")
    void shouldReturnEmptyForUnknownRevisionId() {
        List<RevisionAttachmentEntity> result = repository.findByIdRevisionIdOrderBySortOrderAsc(UUID.randomUUID());

        assertTrue(result.isEmpty());
    }
}
