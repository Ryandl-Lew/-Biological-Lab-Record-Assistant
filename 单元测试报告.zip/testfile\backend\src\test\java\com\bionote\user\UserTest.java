package com.bionote.user;

import org.junit.jupiter.api.Test;
import java.time.Instant;
import java.util.UUID;
import static org.junit.jupiter.api.Assertions.*;

class UserTest {

    @Test
    void shouldCreateUserWithAllFields() {
        UUID id = UUID.randomUUID();
        Instant now = Instant.now();
        User user = new User(id, "测试用户", "test@example.com", "hashed_password", now);

        assertEquals(id, user.getId());
        assertEquals("测试用户", user.getDisplayName());
        assertEquals("test@example.com", user.getEmailNormalized());
        assertEquals("hashed_password", user.getPasswordHash());
        assertEquals(now, user.getCreatedAt());
        assertEquals(now, user.getUpdatedAt());
        assertEquals(0, user.getVersion());
        assertNull(user.getAvatarStorageKey());
        assertNull(user.getAvatarMimeType());
    }

    @Test
    void shouldUpdateDisplayName() {
        User user = new User(UUID.randomUUID(), "旧名称", "test@example.com", "hash", Instant.now());
        user.setDisplayName("新名称");
        assertEquals("新名称", user.getDisplayName());
    }

    @Test
    void shouldSetAndGetAvatarFields() {
        User user = new User(UUID.randomUUID(), "用户", "test@example.com", "hash", Instant.now());
        user.setAvatarStorageKey("avatars/key.jpg");
        user.setAvatarMimeType("image/jpeg");

        assertEquals("avatars/key.jpg", user.getAvatarStorageKey());
        assertEquals("image/jpeg", user.getAvatarMimeType());
    }

    @Test
    void shouldTrackVersion() {
        User user = new User(UUID.randomUUID(), "用户", "test@example.com", "hash", Instant.now());
        assertEquals(0, user.getVersion());
    }

    @Test
    void shouldHaveProtectedNoArgsConstructor() throws Exception {
        var constructor = User.class.getDeclaredConstructor();
        constructor.setAccessible(true);
        User user = constructor.newInstance();

        assertNull(user.getId());
        assertNull(user.getDisplayName());
        assertNull(user.getEmailNormalized());
    }
}
