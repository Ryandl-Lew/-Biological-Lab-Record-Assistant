import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { FileText } from 'lucide-react';
import EmptyState from '@/components/ui/EmptyState';

describe('EmptyState', () => {
  it('renders title', () => {
    render(<EmptyState icon={FileText} title="暂无数据" />);
    expect(screen.getByText('暂无数据')).toBeInTheDocument();
  });

  it('renders description when provided', () => {
    render(
      <EmptyState
        icon={FileText}
        title="暂无记录"
        description="当前项目还没有实验记录"
      />
    );
    expect(screen.getByText('当前项目还没有实验记录')).toBeInTheDocument();
  });

  it('does not render description when not provided', () => {
    const { container } = render(<EmptyState icon={FileText} title="空" />);
    const desc = container.querySelector('.max-w-sm');
    expect(desc).toBeNull();
  });

  it('renders action button when provided', () => {
    render(
      <EmptyState
        icon={FileText}
        title="暂无项目"
        action={<button>创建项目</button>}
      />
    );
    expect(screen.getByRole('button', { name: '创建项目' })).toBeInTheDocument();
  });

  it('renders icon component', () => {
    render(<EmptyState icon={FileText} title="测试" />);
    const iconContainer = document.querySelector('.h-12.w-12');
    expect(iconContainer).toBeTruthy();
    expect(iconContainer.querySelector('svg')).toBeTruthy();
  });
});
