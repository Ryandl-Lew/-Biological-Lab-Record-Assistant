import { describe, it, expect } from 'vitest'
import {
  PROJECT_ROLE_LABELS,
  PROJECT_ROLE_TONES,
  PROJECT_STATUS_LABELS,
  PROJECT_STATUS_TONES,
  RECORD_STATUS_LABELS,
  RECORD_STATUS_TONES,
  TEMPLATE_FIELD_TYPE_LABELS,
  TEMPLATE_CATEGORY_LABELS,
  SEARCH_ENTITY_LABELS,
  SEARCH_ENTITY_TONES,
  PERMISSION_VALUE_LABELS,
  PERMISSION_VALUE_TONES,
} from './enums'

describe('PROJECT_ROLE_LABELS', () => {
  it('has correct Chinese labels for each role', () => {
    expect(PROJECT_ROLE_LABELS.OWNER).toBe('项目负责人')
    expect(PROJECT_ROLE_LABELS.MEMBER).toBe('编辑成员')
    expect(PROJECT_ROLE_LABELS.REVIEWER).toBe('审核者')
  })

  it('has exactly three keys', () => {
    expect(Object.keys(PROJECT_ROLE_LABELS)).toHaveLength(3)
  })
})

describe('PROJECT_ROLE_TONES', () => {
  it('maps each role to a valid tone color', () => {
    expect(PROJECT_ROLE_TONES.OWNER).toBe('blue')
    expect(PROJECT_ROLE_TONES.MEMBER).toBe('green')
    expect(PROJECT_ROLE_TONES.REVIEWER).toBe('amber')
  })
})

describe('PROJECT_STATUS_LABELS', () => {
  it('has correct labels', () => {
    expect(PROJECT_STATUS_LABELS.ACTIVE).toBe('进行中')
    expect(PROJECT_STATUS_LABELS.ARCHIVED).toBe('已归档')
  })
})

describe('PROJECT_STATUS_TONES', () => {
  it('maps statuses to expected tones', () => {
    expect(PROJECT_STATUS_TONES.ACTIVE).toBe('blue')
    expect(PROJECT_STATUS_TONES.ARCHIVED).toBe('gray')
  })
})

describe('RECORD_STATUS_LABELS', () => {
  it('has correct labels for all 4 record statuses', () => {
    expect(RECORD_STATUS_LABELS.IN_PROGRESS).toBe('进行中')
    expect(RECORD_STATUS_LABELS.IN_REVIEW).toBe('审核中')
    expect(RECORD_STATUS_LABELS.CHANGES_REQUESTED).toBe('需修改')
    expect(RECORD_STATUS_LABELS.COMPLETED).toBe('已完成')
    expect(Object.keys(RECORD_STATUS_LABELS)).toHaveLength(4)
  })
})

describe('RECORD_STATUS_TONES', () => {
  it('maps statuses to expected tone colors', () => {
    expect(RECORD_STATUS_TONES.IN_PROGRESS).toBe('blue')
    expect(RECORD_STATUS_TONES.IN_REVIEW).toBe('amber')
    expect(RECORD_STATUS_TONES.CHANGES_REQUESTED).toBe('red')
    expect(RECORD_STATUS_TONES.COMPLETED).toBe('green')
  })
})

describe('TEMPLATE_FIELD_TYPE_LABELS', () => {
  it('has correct Chinese labels for all field types', () => {
    expect(TEMPLATE_FIELD_TYPE_LABELS.SINGLE_LINE_TEXT).toBe('单行文本')
    expect(TEMPLATE_FIELD_TYPE_LABELS.MULTI_LINE_TEXT).toBe('多行文本')
    expect(TEMPLATE_FIELD_TYPE_LABELS.NUMBER).toBe('数字')
    expect(TEMPLATE_FIELD_TYPE_LABELS.DATE).toBe('日期')
    expect(TEMPLATE_FIELD_TYPE_LABELS.SELECT).toBe('单选/下拉')
    expect(TEMPLATE_FIELD_TYPE_LABELS.FILE).toBe('文件')
    expect(Object.keys(TEMPLATE_FIELD_TYPE_LABELS)).toHaveLength(6)
  })
})

describe('TEMPLATE_CATEGORY_LABELS', () => {
  it('has correct labels for all categories', () => {
    expect(TEMPLATE_CATEGORY_LABELS.all).toBe('全部模板')
    expect(TEMPLATE_CATEGORY_LABELS.mine).toBe('我的模板')
    expect(TEMPLATE_CATEGORY_LABELS.molecular).toBe('分子生物学')
    expect(TEMPLATE_CATEGORY_LABELS.cell).toBe('细胞生物学')
    expect(TEMPLATE_CATEGORY_LABELS.protein).toBe('蛋白实验')
    expect(TEMPLATE_CATEGORY_LABELS.immunology).toBe('免疫实验')
  })
})

describe('SEARCH_ENTITY_LABELS', () => {
  it('has all entity labels', () => {
    expect(SEARCH_ENTITY_LABELS.PROJECT).toBe('项目')
    expect(SEARCH_ENTITY_LABELS.RECORD).toBe('实验记录')
    expect(SEARCH_ENTITY_LABELS.TEMPLATE).toBe('模板')
    expect(SEARCH_ENTITY_LABELS.MEMBER).toBe('成员')
    expect(SEARCH_ENTITY_LABELS.ATTACHMENT).toBe('附件')
    expect(Object.keys(SEARCH_ENTITY_LABELS)).toHaveLength(5)
  })
})

describe('SEARCH_ENTITY_TONES', () => {
  it('maps entities to expected tones', () => {
    expect(SEARCH_ENTITY_TONES.PROJECT).toBe('violet')
    expect(SEARCH_ENTITY_TONES.RECORD).toBe('amber')
    expect(SEARCH_ENTITY_TONES.TEMPLATE).toBe('green')
    expect(SEARCH_ENTITY_TONES.MEMBER).toBe('blue')
    expect(SEARCH_ENTITY_TONES.ATTACHMENT).toBe('blue')
  })
})

describe('PERMISSION_VALUE_LABELS', () => {
  it('maps permission values to correct labels', () => {
    expect(PERMISSION_VALUE_LABELS.yes).toBe('是')
    expect(PERMISSION_VALUE_LABELS.no).toBe('否')
    expect(PERMISSION_VALUE_LABELS.optional).toBe('可选')
  })
})

describe('PERMISSION_VALUE_TONES', () => {
  it('maps permission values to correct tones', () => {
    expect(PERMISSION_VALUE_TONES.yes).toBe('green')
    expect(PERMISSION_VALUE_TONES.no).toBe('red')
    expect(PERMISSION_VALUE_TONES.optional).toBe('amber')
  })
})
