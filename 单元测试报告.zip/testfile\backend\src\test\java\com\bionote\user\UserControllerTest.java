package com.bionote.user;

import com.bionote.common.ApiException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.security.core.Authentication;
import org.springframework.web.multipart.MultipartFile;

import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
class UserControllerTest {

    @Mock private UserUseCase userUseCase;
    @Mock private Authentication authentication;
    @Mock private MultipartFile multipartFile;

    @InjectMocks private UserController controller;

    private final UUID userId = UUID.randomUUID();

    @Test
    void shouldUpdateProfileSuccessfully() {
        when(authentication.getName()).thenReturn(userId.toString());
        UserDtos.UserView view = new UserDtos.UserView(userId, "新名称", "test@example.com",
                null, Instant.now(), Instant.now());
        when(userUseCase.update(eq(userId), any(UserDtos.UpdateProfileRequest.class))).thenReturn(view);

        var result = controller.update(authentication, new UserDtos.UpdateProfileRequest("新名称"));

        assertNotNull(result);
        assertEquals("新名称", result.getData().displayName());
        assertEquals("test@example.com", result.getData().email());
    }

    @Test
    void shouldReturnNotFoundWhenUserDoesNotExist() {
        when(authentication.getName()).thenReturn(userId.toString());
        when(userUseCase.update(any(UUID.class), any(UserDtos.UpdateProfileRequest.class)))
                .thenThrow(new ApiException(HttpStatus.NOT_FOUND, "RESOURCE_NOT_FOUND", "用户不存在"));

        assertThrows(ApiException.class, () ->
                controller.update(authentication, new UserDtos.UpdateProfileRequest("新名称")));
    }

    @Test
    void shouldUploadAvatarSuccessfully() throws Exception {
        when(authentication.getName()).thenReturn(userId.toString());
        UserDtos.UserView view = new UserDtos.UserView(userId, "用户", "test@example.com",
                "/api/v1/users/" + userId + "/avatar", Instant.now(), Instant.now());
        when(userUseCase.avatar(any(UUID.class), any(MultipartFile.class))).thenReturn(view);

        var result = controller.avatar(authentication, multipartFile);

        assertNotNull(result);
        assertNotNull(result.getData().avatarUrl());
    }

    @Test
    void shouldGetAvatarSuccessfully() throws Exception {
        byte[] bytes = "image-data".getBytes();
        UserUseCase.AvatarContent content = new UserUseCase.AvatarContent(bytes, "image/jpeg");
        when(userUseCase.avatar(userId)).thenReturn(content);

        var result = controller.avatar(userId);

        assertNotNull(result);
        assertEquals(200, result.getStatusCode().value());
        assertEquals(MediaType.IMAGE_JPEG, result.getHeaders().getContentType());
        assertArrayEquals(bytes, result.getBody());
    }

    @Test
    void shouldReturnNotFoundWhenAvatarNotSet() throws Exception {
        when(userUseCase.avatar(userId)).thenReturn(null);

        var result = controller.avatar(userId);

        assertNotNull(result);
        assertEquals(404, result.getStatusCode().value());
    }

    @Test
    void shouldReturnBadRequestWhenAvatarFileTooLarge() {
        when(authentication.getName()).thenReturn(userId.toString());
        when(userUseCase.avatar(any(UUID.class), any(MultipartFile.class)))
                .thenThrow(new ApiException(HttpStatus.PAYLOAD_TOO_LARGE, "FILE_TOO_LARGE", "头像不能超过 2 MB"));

        assertThrows(ApiException.class, () -> controller.avatar(authentication, multipartFile));
    }
}
