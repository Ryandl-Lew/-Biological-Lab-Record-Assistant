package com.bionote.revision;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("TextDiffEngine - 文本差异引擎测试")
class TextDiffEngineTest {

    private final TextDiffEngine engine = new TextDiffEngine();

    @Nested
    @DisplayName("diff - 基础差异计算")
    class BasicDiffTests {

        @Test
        @DisplayName("相同字符串应返回 EQUAL 操作")
        void shouldReturnEqualForIdenticalStrings() {
            var result = engine.diff("hello world", "hello world", 100);
            assertFalse(result.truncated());
            assertEquals(1, result.operations().size());
            assertEquals("EQUAL", result.operations().get(0).operation());
            assertEquals("hello world", result.operations().get(0).text());
        }

        @Test
        @DisplayName("插入新内容应返回 INSERT 和 EQUAL")
        void shouldReturnInsertForAddedContent() {
            var result = engine.diff("hello", "hello world", 100);
            assertFalse(result.truncated());
            boolean hasInsert = result.operations().stream()
                    .anyMatch(op -> "INSERT".equals(op.operation()) && op.text().contains("world"));
            assertTrue(hasInsert);
        }

        @Test
        @DisplayName("删除内容应返回 DELETE 和 EQUAL")
        void shouldReturnDeleteForRemovedContent() {
            var result = engine.diff("hello world", "hello", 100);
            assertFalse(result.truncated());
            boolean hasDelete = result.operations().stream()
                    .anyMatch(op -> "DELETE".equals(op.operation()));
            assertTrue(hasDelete);
        }

        @Test
        @DisplayName("完全不同的字符串应产生 INSERT 和 DELETE")
        void shouldHandleCompletelyDifferentStrings() {
            var result = engine.diff("abc", "xyz", 100);
            assertFalse(result.truncated());
            assertEquals(2, result.operations().size());
        }
    }

    @Nested
    @DisplayName("diff - 边界条件")
    class EdgeCaseTests {

        @Test
        @DisplayName("null 输入应被当作空字符串")
        void shouldTreatNullAsEmpty() {
            var result = engine.diff(null, "hello", 100);
            assertFalse(result.truncated());
            assertTrue(result.operations().stream()
                    .anyMatch(op -> "INSERT".equals(op.operation()) && "hello".equals(op.text())));
        }

        @Test
        @DisplayName("两个空字符串应返回空 EQUAL")
        void shouldReturnEmptyForBothNull() {
            var result = engine.diff(null, null, 100);
            assertEquals(1, result.operations().size());
            assertEquals("EQUAL", result.operations().get(0).operation());
        }

        @Test
        @DisplayName("maxOperations 限制应触发截断")
        void shouldTruncateWhenExceedingMaxOperations() {
            // create many differing tokens
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 200; i++) sb.append("word" + i + " ");
            var result = engine.diff(sb.toString(), "only one word", 5);
            assertTrue(result.truncated());
            assertFalse(result.operations().isEmpty());
        }
    }

    @Nested
    @DisplayName("diff - 大字符串处理")
    class LargeStringTests {

        @Test
        @DisplayName("超大差异应使用粗粒度算法")
        void shouldUseCoarseForLargeDiff() {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 2000; i++) sb.append("token" + i + " ");
            var result = engine.diff(sb.toString(), "", 10);
            assertNotNull(result.operations());
        }

        @Test
        @DisplayName("超过 token 数限制应使用 coarse")
        void shouldUseCoarseWhenTokenLimitExceeded() {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 2000; i++) sb.append("x ");
            var result = engine.diff(sb.toString(), "y", 100);
            assertTrue(result.truncated());
            // coarse mode produces DELETE + INSERT
            assertTrue(result.operations().size() <= 2);
        }
    }

    @Nested
    @DisplayName("diff - 操作合并")
    class OperationMergeTests {

        @Test
        @DisplayName("连续相同类型的操作应合并")
        void shouldMergeConsecutiveEqualOperations() {
            var result = engine.diff("abcdef", "abcdef", 100);
            assertEquals(1, result.operations().size());
        }

        @Test
        @DisplayName("短文本应精确计算差异")
        void shouldComputePreciseDiffForShortText() {
            var result = engine.diff("the quick brown fox", "the slow brown dog", 100);
            assertFalse(result.truncated());
            assertTrue(result.operations().size() > 1);
        }
    }
}
