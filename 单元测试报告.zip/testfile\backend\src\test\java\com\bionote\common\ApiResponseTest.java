package com.bionote.common;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("ApiResponse 记录测试")
class ApiResponseTest {

    @Test
    @DisplayName("应正确构造并读取 data 字段")
    void shouldConstructAndReadData() {
        ApiResponse<String> response = new ApiResponse<>("hello");

        assertEquals("hello", response.data());
    }

    @Test
    @DisplayName("of 静态工厂方法应创建正确实例")
    void shouldCreateInstanceViaOf() {
        ApiResponse<Integer> response = ApiResponse.of(42);

        assertNotNull(response);
        assertEquals(42, response.data());
    }

    @Test
    @DisplayName("data 为 null 时应正常工作")
    void shouldWorkWithNullData() {
        ApiResponse<String> response = ApiResponse.of(null);

        assertNotNull(response);
        assertNull(response.data());
    }

    @Test
    @DisplayName("相同 data 的两个记录应相等")
    void shouldBeEqualWhenSameData() {
        ApiResponse<String> r1 = new ApiResponse<>("test");
        ApiResponse<String> r2 = new ApiResponse<>("test");

        assertEquals(r1, r2);
        assertEquals(r1.hashCode(), r2.hashCode());
    }
}
