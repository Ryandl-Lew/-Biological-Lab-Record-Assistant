import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import Sidebar from '@/components/layout/Sidebar';

const mockUseAuthStore = vi.fn();

vi.mock('@/store/authStore', () => ({
  useAuthStore: (selector) => {
    const state = mockUseAuthStore();
    return selector ? selector(state) : state;
  },
}));

describe('Sidebar', () => {
  const renderWithRouter = (ui) => render(<MemoryRouter>{ui}</MemoryRouter>);

  beforeEach(() => {
    mockUseAuthStore.mockReturnValue({
      currentUser: { displayName: '张三', email: 'zhangsan@test.com', avatarUrl: null },
      logout: vi.fn(),
    });
  });

  it('renders brand name', () => {
    renderWithRouter(<Sidebar />);
    expect(screen.getByText('BioNote')).toBeInTheDocument();
  });

  it('renders navigation links', () => {
    renderWithRouter(<Sidebar />);
    expect(screen.getByText('工作台')).toBeInTheDocument();
    expect(screen.getByText('项目管理')).toBeInTheDocument();
    expect(screen.getByText('实验记录')).toBeInTheDocument();
    expect(screen.getByText('模板中心')).toBeInTheDocument();
  });

  it('renders user display name', () => {
    renderWithRouter(<Sidebar />);
    expect(screen.getByText('张三')).toBeInTheDocument();
  });

  it('renders logout button', () => {
    renderWithRouter(<Sidebar />);
    expect(screen.getByText('退出登录')).toBeInTheDocument();
  });

  it('renders section titles', () => {
    renderWithRouter(<Sidebar />);
    expect(screen.getByText('项目工作区')).toBeInTheDocument();
    expect(screen.getByText('发现与账户')).toBeInTheDocument();
  });
});
