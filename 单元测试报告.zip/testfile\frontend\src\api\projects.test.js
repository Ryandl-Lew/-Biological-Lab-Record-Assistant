import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('./client', () => ({ request: vi.fn() }))

import { request } from './client'
import {
  fetchProjects,
  fetchProject,
  createProject,
  archiveProject,
  fetchProjectMembers,
  inviteProjectMember,
  updateProjectMemberRole,
  removeProjectMember,
  fetchProjectAuditEvents,
  fetchProjectAttachments,
} from './projects'

describe('projects API', () => {
  beforeEach(() => {
    request.mockReset()
  })

  describe('fetchProjects', () => {
    it('sends GET /projects with no params', async () => {
      request.mockResolvedValueOnce([])
      await fetchProjects()
      expect(request).toHaveBeenCalledWith('/projects')
    })

    it('sends GET /projects with query params', async () => {
      request.mockResolvedValueOnce([])
      await fetchProjects({ status: 'ACTIVE', page: 1 })
      expect(request).toHaveBeenCalledWith('/projects?status=ACTIVE&page=1')
    })

    it('filters out falsy params', async () => {
      request.mockResolvedValueOnce([])
      await fetchProjects({ status: 'ACTIVE', keyword: '', page: undefined })
      expect(request).toHaveBeenCalledWith('/projects?status=ACTIVE')
    })
  })

  describe('fetchProject', () => {
    it('sends GET /projects/:id', async () => {
      request.mockResolvedValueOnce({ id: 'proj-1', name: '项目A' })
      const result = await fetchProject('proj-1')
      expect(request).toHaveBeenCalledWith('/projects/proj-1')
      expect(result).toEqual({ id: 'proj-1', name: '项目A' })
    })
  })

  describe('createProject', () => {
    it('sends POST /projects with input', async () => {
      request.mockResolvedValueOnce({ id: 'proj-new', name: '新项目' })
      const input = { name: '新项目', description: '描述' }
      await createProject(input)
      expect(request).toHaveBeenCalledWith('/projects', {
        method: 'POST',
        body: JSON.stringify(input),
      })
    })
  })

  describe('archiveProject', () => {
    it('sends POST /projects/:id/archive', async () => {
      request.mockResolvedValueOnce({ status: 'ARCHIVED' })
      await archiveProject('proj-1')
      expect(request).toHaveBeenCalledWith('/projects/proj-1/archive', { method: 'POST' })
    })
  })

  describe('fetchProjectMembers', () => {
    it('sends GET /projects/:id/members', async () => {
      request.mockResolvedValueOnce([{ userId: 'u1', role: 'OWNER' }])
      await fetchProjectMembers('proj-1')
      expect(request).toHaveBeenCalledWith('/projects/proj-1/members')
    })
  })

  describe('inviteProjectMember', () => {
    it('sends POST /projects/:id/invitations with email', async () => {
      request.mockResolvedValueOnce({ invited: true })
      await inviteProjectMember('proj-1', 'user@example.com')
      expect(request).toHaveBeenCalledWith('/projects/proj-1/invitations', {
        method: 'POST',
        body: JSON.stringify({ email: 'user@example.com' }),
      })
    })
  })

  describe('updateProjectMemberRole', () => {
    it('sends PATCH /projects/:projectId/members/:userId/role with role and reassignments', async () => {
      request.mockResolvedValueOnce({ updated: true })
      await updateProjectMemberRole('proj-1', 'user-2', 'REVIEWER', { oldRecords: 'user-3' })
      expect(request).toHaveBeenCalledWith('/projects/proj-1/members/user-2/role', {
        method: 'PATCH',
        body: JSON.stringify({ role: 'REVIEWER', reassignments: { oldRecords: 'user-3' } }),
      })
    })
  })

  describe('removeProjectMember', () => {
    it('sends POST /projects/:projectId/members/:userId/remove with reassignments', async () => {
      request.mockResolvedValueOnce(null)
      await removeProjectMember('proj-1', 'user-2', { records: 'user-3' })
      expect(request).toHaveBeenCalledWith('/projects/proj-1/members/user-2/remove', {
        method: 'POST',
        body: JSON.stringify({ reassignments: { records: 'user-3' } }),
      })
    })
  })

  describe('fetchProjectAuditEvents', () => {
    it('sends GET /projects/:id/audit-events with params', async () => {
      request.mockResolvedValueOnce([])
      await fetchProjectAuditEvents('proj-1', { page: 1, size: 10 })
      expect(request).toHaveBeenCalledWith('/projects/proj-1/audit-events?page=1&size=10')
    })
  })

  describe('fetchProjectAttachments', () => {
    it('sends GET /projects/:id/attachments with params', async () => {
      request.mockResolvedValueOnce([])
      await fetchProjectAttachments('proj-1', { page: 1, size: 5 })
      expect(request).toHaveBeenCalledWith('/projects/proj-1/attachments?page=1&size=5')
    })
  })
})
