package com.bionote.notification;

import org.junit.jupiter.api.Test;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class NotificationDtosTest {

    @Test
    void view_shouldHoldAllFields() {
        UUID id = UUID.randomUUID();
        Instant now = Instant.now();
        Map<String, Object> target = Map.of("type", "RECORD", "id", UUID.randomUUID().toString());
        List<String> actions = List.of("VIEW", "DISMISS");

        NotificationDtos.View view = new NotificationDtos.View(
                id, "INVITATION", "邀请通知", "你已被邀请加入项目",
                target, actions, false, now, null
        );

        assertEquals(id, view.id());
        assertEquals("INVITATION", view.type());
        assertEquals("邀请通知", view.title());
        assertEquals("你已被邀请加入项目", view.body());
        assertEquals(target, view.target());
        assertEquals(actions, view.actions());
        assertFalse(view.stale());
        assertEquals(now, view.createdAt());
        assertNull(view.readAt());
    }

    @Test
    void view_shouldBeStale() {
        NotificationDtos.View view = new NotificationDtos.View(
                UUID.randomUUID(), "SYSTEM", "标题", "内容",
                Map.of(), List.of(), true, Instant.now(), Instant.now()
        );

        assertTrue(view.stale());
        assertNotNull(view.readAt());
    }

    @Test
    void view_shouldHaveEmptyActions() {
        NotificationDtos.View view = new NotificationDtos.View(
                UUID.randomUUID(), "SYSTEM", "T", "B",
                Map.of("type", "NONE"), List.of(), true, Instant.now(), null
        );

        assertTrue(view.actions().isEmpty());
        assertEquals("NONE", view.target().get("type"));
    }

    @Test
    void view_shouldHandleNullReadAt() {
        NotificationDtos.View view = new NotificationDtos.View(
                UUID.randomUUID(), "COMMENT", "评论", "有新评论",
                Map.of("type", "RECORD", "id", "123"),
                List.of("REPLY"), false, Instant.now(), null
        );

        assertNull(view.readAt());
        assertFalse(view.stale());
    }

    @Test
    void view_equalInstancesShouldBeEqual() {
        UUID id = UUID.randomUUID();
        Instant now = Instant.now();
        Map<String, Object> target = Map.of("type", "PROJECT");

        NotificationDtos.View v1 = new NotificationDtos.View(id, "T", "title", "body", target, List.of(), false, now, null);
        NotificationDtos.View v2 = new NotificationDtos.View(id, "T", "title", "body", target, List.of(), false, now, null);

        assertEquals(v1, v2);
        assertEquals(v1.hashCode(), v2.hashCode());
    }
}
