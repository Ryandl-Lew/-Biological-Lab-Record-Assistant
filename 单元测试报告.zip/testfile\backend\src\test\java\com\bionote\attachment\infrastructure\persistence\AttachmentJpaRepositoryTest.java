package com.bionote.attachment.infrastructure.persistence;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.TestPropertySource;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@TestPropertySource(properties = {"spring.flyway.enabled=false", "spring.jpa.hibernate.ddl-auto=update"})
@DisplayName("AttachmentJpaRepository 测试")
class AttachmentJpaRepositoryTest {

    @Autowired
    private AttachmentJpaRepository repository;

    @Test
    @DisplayName("save 和 findById 应正确工作")
    void shouldSaveAndFindById() {
        UUID id = UUID.randomUUID();
        AttachmentEntity entity = new AttachmentEntity(id, UUID.randomUUID(), UUID.randomUUID(),
                "test.pdf", "sk-1", "application/pdf", 1024L, true, Instant.now());
        repository.saveAndFlush(entity);

        Optional<AttachmentEntity> found = repository.findById(id);

        assertTrue(found.isPresent());
        assertEquals("test.pdf", found.get().originalFilename);
        assertEquals("sk-1", found.get().storageKey);
    }

    @Test
    @DisplayName("findByRecordIdAndDeletedAtIsNull 应只返回未删除附件")
    void shouldFindActiveByRecordId() {
        UUID recordId = UUID.randomUUID();
        UUID id1 = UUID.randomUUID();
        UUID id2 = UUID.randomUUID();
        Instant now = Instant.now();

        AttachmentEntity e1 = new AttachmentEntity(id1, recordId, UUID.randomUUID(), "a.pdf",
                "sk-a", "application/pdf", 100L, true, now);
        AttachmentEntity e2 = new AttachmentEntity(id2, recordId, UUID.randomUUID(), "b.pdf",
                "sk-b", "application/pdf", 200L, true, now);
        e2.deletedAt = Instant.now();

        repository.saveAllAndFlush(List.of(e1, e2));

        List<AttachmentEntity> result = repository.findByRecordIdAndDeletedAtIsNullOrderByCreatedAtAscIdAsc(recordId);

        assertEquals(1, result.size());
        assertEquals("a.pdf", result.get(0).originalFilename);
    }

    @Test
    @DisplayName("existsByIdAndRecordIdAndDeletedAtIsNull 应正确判断")
    void shouldCheckExistenceWithoutDeleted() {
        UUID id = UUID.randomUUID();
        UUID recordId = UUID.randomUUID();
        AttachmentEntity entity = new AttachmentEntity(id, recordId, UUID.randomUUID(),
                "test.txt", "sk-exists", "text/plain", 50L, false, Instant.now());
        repository.saveAndFlush(entity);

        assertTrue(repository.existsByIdAndRecordIdAndDeletedAtIsNull(id, recordId));
        assertFalse(repository.existsByIdAndRecordIdAndDeletedAtIsNull(UUID.randomUUID(), recordId));
    }

    @Test
    @DisplayName("reactivate 应清除 deletedAt")
    void shouldReactivate() {
        UUID id = UUID.randomUUID();
        AttachmentEntity entity = new AttachmentEntity(id, UUID.randomUUID(), UUID.randomUUID(),
                "test.txt", "sk-react", "text/plain", 200L, false, Instant.now());
        entity.deletedAt = Instant.now();
        repository.saveAndFlush(entity);

        int updated = repository.reactivate(id);

        assertEquals(1, updated);
        var found = repository.findById(id);
        assertTrue(found.isPresent());
        assertNull(found.get().deletedAt);
    }
}
