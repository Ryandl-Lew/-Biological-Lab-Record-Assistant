import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import WelcomeHeader from '@/components/dashboard/WelcomeHeader';

const mockUseAuthStore = vi.fn();

vi.mock('@/store/authStore', () => ({
  useAuthStore: (selector) => {
    const state = mockUseAuthStore();
    return selector ? selector(state) : state;
  },
}));

describe('WelcomeHeader', () => {
  const renderWithRouter = (ui) => render(<MemoryRouter>{ui}</MemoryRouter>);

  beforeEach(() => {
    mockUseAuthStore.mockReset();
  });

  it('renders user display name when available', () => {
    mockUseAuthStore.mockReturnValue({ currentUser: { displayName: '张三' } });
    renderWithRouter(<WelcomeHeader />);
    expect(screen.getByText('你好，张三')).toBeInTheDocument();
  });

  it('renders default name when displayName is missing', () => {
    mockUseAuthStore.mockReturnValue({ currentUser: null });
    renderWithRouter(<WelcomeHeader />);
    expect(screen.getByText('你好，研究者')).toBeInTheDocument();
  });

  it('renders welcome subtitle', () => {
    mockUseAuthStore.mockReturnValue({ currentUser: { displayName: '张三' } });
    renderWithRouter(<WelcomeHeader />);
    expect(screen.getByText('欢迎回来')).toBeInTheDocument();
  });

  it('renders workspace label', () => {
    mockUseAuthStore.mockReturnValue({ currentUser: { displayName: '李四' } });
    renderWithRouter(<WelcomeHeader />);
    expect(screen.getByText('工作台')).toBeInTheDocument();
  });
});
