package com.bionote.restore;

import com.bionote.common.ApiException;
import com.bionote.common.PagedResponse;
import com.bionote.project.ProjectMemberStore;
import com.bionote.record.RecordStore;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@DisplayName("RestoreHistoryService - 恢复历史服务测试")
class RestoreHistoryServiceTest {

    @Mock private RestoreOperationStore operations;
    @Mock private RecordStore records;
    @Mock private ProjectMemberStore members;
    @InjectMocks private RestoreHistoryService historyService;

    @Nested
    @DisplayName("list - 分页查询恢复历史")
    class ListTests {

        @Test
        @DisplayName("正常查询应返回分页结果")
        void shouldReturnPagedResult() {
            var actorId = UUID.randomUUID();
            var recordId = UUID.randomUUID();
            var projectId = UUID.randomUUID();
            var record = new RecordStore.RecordData(recordId, "REC001", projectId, actorId,
                    "title", "type", LocalDate.now(), "purpose", "ACTIVE", false,
                    "{}", "{}", "{}", "<p></p>", "", 0, null, null, 1L,
                    Instant.now(), Instant.now(), null);
            when(records.findActive(recordId)).thenReturn(Optional.of(record));
            when(members.exists(projectId, actorId)).thenReturn(true);
            when(operations.list(recordId, 0, 20)).thenReturn(new RestoreOperationStore.PageSlice(List.of(), 0L));

            var result = historyService.list(actorId, recordId, 0, 20);

            assertNotNull(result);
            assertEquals(0L, result.meta().totalElements());
        }

        @Test
        @DisplayName("记录不存在应抛出 NOT_FOUND")
        void shouldThrowNotFoundWhenRecordMissing() {
            var actorId = UUID.randomUUID();
            var recordId = UUID.randomUUID();
            when(records.findActive(recordId)).thenReturn(Optional.empty());

            var ex = assertThrows(ApiException.class, () -> historyService.list(actorId, recordId, 0, 20));
            assertEquals(HttpStatus.NOT_FOUND, ex.status());
        }

        @Test
        @DisplayName("非项目成员无权访问")
        void shouldThrowNotFoundWhenNotMember() {
            var actorId = UUID.randomUUID();
            var recordId = UUID.randomUUID();
            var projectId = UUID.randomUUID();
            var record = new RecordStore.RecordData(recordId, "REC001", projectId, actorId,
                    "title", "type", LocalDate.now(), "purpose", "ACTIVE", false,
                    "{}", "{}", "{}", "<p></p>", "", 0, null, null, 1L,
                    Instant.now(), Instant.now(), null);
            when(records.findActive(recordId)).thenReturn(Optional.of(record));
            when(members.exists(projectId, actorId)).thenReturn(false);

            var ex = assertThrows(ApiException.class, () -> historyService.list(actorId, recordId, 0, 20));
            assertEquals(HttpStatus.NOT_FOUND, ex.status());
        }

        @Test
        @DisplayName("负页码应被归一化为 0")
        void shouldNormalizeNegativePage() {
            var actorId = UUID.randomUUID();
            var recordId = UUID.randomUUID();
            var projectId = UUID.randomUUID();
            var record = new RecordStore.RecordData(recordId, "REC001", projectId, actorId,
                    "title", "type", LocalDate.now(), "purpose", "ACTIVE", false,
                    "{}", "{}", "{}", "<p></p>", "", 0, null, null, 1L,
                    Instant.now(), Instant.now(), null);
            when(records.findActive(recordId)).thenReturn(Optional.of(record));
            when(members.exists(projectId, actorId)).thenReturn(true);
            when(operations.list(eq(recordId), eq(0), eq(20))).thenReturn(new RestoreOperationStore.PageSlice(List.of(), 0L));

            var result = historyService.list(actorId, recordId, -5, 20);
            assertNotNull(result);
        }

        @Test
        @DisplayName("超大 size 应被限制为 100")
        void shouldCapSizeTo100() {
            var actorId = UUID.randomUUID();
            var recordId = UUID.randomUUID();
            var projectId = UUID.randomUUID();
            var record = new RecordStore.RecordData(recordId, "REC001", projectId, actorId,
                    "title", "type", LocalDate.now(), "purpose", "ACTIVE", false,
                    "{}", "{}", "{}", "<p></p>", "", 0, null, null, 1L,
                    Instant.now(), Instant.now(), null);
            when(records.findActive(recordId)).thenReturn(Optional.of(record));
            when(members.exists(projectId, actorId)).thenReturn(true);
            when(operations.list(eq(recordId), eq(0), eq(100))).thenReturn(new RestoreOperationStore.PageSlice(List.of(), 0L));

            var result = historyService.list(actorId, recordId, 0, 500);
            assertNotNull(result);
        }
    }
}
