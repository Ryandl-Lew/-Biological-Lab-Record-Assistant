package com.bionote.export;

import org.junit.jupiter.api.Test;
import java.time.Instant;
import java.time.LocalDate;
import java.util.Collections;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class RecordReportModelTest {

    @Test
    void shouldCreateWithAllFields() {
        Instant now = Instant.now();
        LocalDate date = LocalDate.of(2025, 6, 15);
        List<RecordReportModel.Field> fields = List.of(
                new RecordReportModel.Field("Temperature", "25°C")
        );
        List<RecordReportModel.Attachment> attachments = List.of(
                new RecordReportModel.Attachment("data.csv", 1024, "Alice", now)
        );

        RecordReportModel model = new RecordReportModel(
                "Experiment A", "EXP-001", "My Project",
                "Chemical", date, "Bob", "Test purpose",
                fields, "<h1>Content</h1>", "Content",
                3, "Charlie", now, "Approved", attachments
        );

        assertEquals("Experiment A", model.title());
        assertEquals("EXP-001", model.code());
        assertEquals("My Project", model.projectName());
        assertEquals("Chemical", model.experimentType());
        assertEquals(date, model.experimentDate());
        assertEquals("Bob", model.creatorName());
        assertEquals("Test purpose", model.purpose());
        assertEquals(1, model.fields().size());
        assertEquals("Temperature", model.fields().get(0).label());
        assertEquals("25°C", model.fields().get(0).value());
        assertEquals("<h1>Content</h1>", model.contentHtml());
        assertEquals("Content", model.contentText());
        assertEquals(3, model.revisionNo());
        assertEquals("Charlie", model.reviewerName());
        assertEquals(now, model.reviewedAt());
        assertEquals("Approved", model.reviewComment());
        assertEquals(1, model.attachments().size());
    }

    @Test
    void shouldHandleEmptyFieldsAndAttachments() {
        RecordReportModel model = new RecordReportModel(
                "Title", "CODE", "Project", "Type",
                LocalDate.now(), "Creator", "Purpose",
                List.of(), "<html></html>", "text",
                1, "Reviewer", Instant.now(), null, List.of()
        );

        assertTrue(model.fields().isEmpty());
        assertTrue(model.attachments().isEmpty());
        assertNull(model.reviewComment());
    }

    @Test
    void field_shouldHoldLabelAndValue() {
        RecordReportModel.Field field = new RecordReportModel.Field("pH", "7.0");

        assertEquals("pH", field.label());
        assertEquals("7.0", field.value());
    }

    @Test
    void field_shouldHandleNullValues() {
        RecordReportModel.Field field = new RecordReportModel.Field(null, null);

        assertNull(field.label());
        assertNull(field.value());
    }

    @Test
    void attachment_shouldHoldAllProperties() {
        Instant uploaded = Instant.now();
        RecordReportModel.Attachment attachment = new RecordReportModel.Attachment(
                "result.pdf", 2048, "David", uploaded
        );

        assertEquals("result.pdf", attachment.filename());
        assertEquals(2048, attachment.sizeBytes());
        assertEquals("David", attachment.uploaderName());
        assertEquals(uploaded, attachment.uploadedAt());
    }
}
