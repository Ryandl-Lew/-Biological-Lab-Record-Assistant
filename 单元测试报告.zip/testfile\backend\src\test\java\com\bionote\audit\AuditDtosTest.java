package com.bionote.audit;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("AuditDtos 测试")
class AuditDtosTest {

    @Test
    @DisplayName("View 记录应正确构造并读取所有字段")
    void shouldConstructViewWithAllFields() {
        UUID id = UUID.randomUUID();
        UUID targetId = UUID.randomUUID();
        UUID recordId = UUID.randomUUID();
        UUID actorId = UUID.randomUUID();
        Instant now = Instant.now();
        Map<String, Object> metadata = Map.of("name", "test");

        AuditDtos.View view = new AuditDtos.View(id, "RECORD_CREATED", "RECORD",
                targetId, recordId, actorId, "张三", metadata, now);

        assertAll(
                () -> assertEquals(id, view.id()),
                () -> assertEquals("RECORD_CREATED", view.eventType()),
                () -> assertEquals("RECORD", view.targetType()),
                () -> assertEquals(targetId, view.targetId()),
                () -> assertEquals(recordId, view.recordId()),
                () -> assertEquals(actorId, view.actorId()),
                () -> assertEquals("张三", view.actorName()),
                () -> assertEquals(metadata, view.metadata()),
                () -> assertEquals(now, view.createdAt())
        );
    }

    @Test
    @DisplayName("AttachmentSummary 记录应正确构造")
    void shouldConstructAttachmentSummary() {
        UUID id = UUID.randomUUID();
        UUID recordId = UUID.randomUUID();
        Instant now = Instant.now();

        AuditDtos.AttachmentSummary summary = new AuditDtos.AttachmentSummary(
                id, "report.pdf", "application/pdf", 2048L, recordId,
                "实验报告", "RC-002", "李四", now);

        assertAll(
                () -> assertEquals(id, summary.id()),
                () -> assertEquals("report.pdf", summary.filename()),
                () -> assertEquals("application/pdf", summary.mediaType()),
                () -> assertEquals(2048L, summary.sizeBytes()),
                () -> assertEquals(recordId, summary.recordId()),
                () -> assertEquals("实验报告", summary.recordTitle()),
                () -> assertEquals("RC-002", summary.recordCode()),
                () -> assertEquals("李四", summary.uploaderName()),
                () -> assertEquals(now, summary.createdAt())
        );
    }

    @Test
    @DisplayName("相同值的两个 View 应相等")
    void shouldBeEqualWhenSameValues() {
        UUID id = UUID.randomUUID();
        Instant now = Instant.now();
        Map<String, Object> meta = Map.of();

        AuditDtos.View v1 = new AuditDtos.View(id, "TYPE", "TARGET", id, id, id, "Name", meta, now);
        AuditDtos.View v2 = new AuditDtos.View(id, "TYPE", "TARGET", id, id, id, "Name", meta, now);

        assertEquals(v1, v2);
    }

    @Test
    @DisplayName("recordId 可为 null")
    void shouldAllowNullRecordIdInView() {
        AuditDtos.View view = new AuditDtos.View(UUID.randomUUID(), "PROJECT_CREATED",
                "PROJECT", UUID.randomUUID(), null, UUID.randomUUID(),
                "系统", Map.of(), Instant.now());

        assertNull(view.recordId());
    }
}
