import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('./client', () => ({ request: vi.fn() }))

import { request } from './client'
import {
  fetchNotifications,
  fetchUnreadCount,
  markNotificationRead,
  markAllNotificationsRead,
  acceptInvitation,
  rejectInvitation,
} from './notifications'

describe('notifications API', () => {
  beforeEach(() => {
    request.mockReset()
  })

  describe('fetchNotifications', () => {
    it('sends GET /notifications with default params as URLSearchParams', async () => {
      request.mockResolvedValueOnce([])
      await fetchNotifications()
      expect(request).toHaveBeenCalled()
      const [url] = request.mock.calls[0]
      expect(url.startsWith('/notifications?')).toBe(true)
    })

    it('sends GET /notifications with custom params', async () => {
      request.mockResolvedValueOnce([])
      await fetchNotifications({ type: 'INVITATION', status: 'PENDING' })
      expect(request).toHaveBeenCalledWith('/notifications?type=INVITATION&status=PENDING')
    })

    it('excludes falsy values from params', async () => {
      request.mockResolvedValueOnce([])
      await fetchNotifications({ type: 'INVITATION', page: undefined, size: null, extra: '' })
      expect(request).toHaveBeenCalledWith('/notifications?type=INVITATION')
    })
  })

  describe('fetchUnreadCount', () => {
    it('sends GET /notifications/unread-count', async () => {
      request.mockResolvedValueOnce(5)
      const count = await fetchUnreadCount()
      expect(request).toHaveBeenCalledWith('/notifications/unread-count')
      expect(count).toBe(5)
    })
  })

  describe('markNotificationRead', () => {
    it('sends PATCH /notifications/:id/read', async () => {
      request.mockResolvedValueOnce({ success: true })
      await markNotificationRead('notif-1')
      expect(request).toHaveBeenCalledWith('/notifications/notif-1/read', { method: 'PATCH' })
    })
  })

  describe('markAllNotificationsRead', () => {
    it('sends POST /notifications/read-all', async () => {
      request.mockResolvedValueOnce(null)
      await markAllNotificationsRead()
      expect(request).toHaveBeenCalledWith('/notifications/read-all', { method: 'POST' })
    })
  })

  describe('acceptInvitation', () => {
    it('sends POST /invitations/:id/accept', async () => {
      request.mockResolvedValueOnce({ status: 'ACCEPTED' })
      await acceptInvitation('inv-1')
      expect(request).toHaveBeenCalledWith('/invitations/inv-1/accept', { method: 'POST' })
    })
  })

  describe('rejectInvitation', () => {
    it('sends POST /invitations/:id/reject', async () => {
      request.mockResolvedValueOnce({ status: 'REJECTED' })
      await rejectInvitation('inv-2')
      expect(request).toHaveBeenCalledWith('/invitations/inv-2/reject', { method: 'POST' })
    })
  })
})
