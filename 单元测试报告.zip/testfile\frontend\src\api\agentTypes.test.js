import { describe, it, expect } from 'vitest'
import {
  AGENT_ARTIFACT_KIND,
  AGENT_RUN_STATUS,
  ACTIVE_AGENT_RUN_STATUSES,
} from './agentTypes'

describe('agentTypes', () => {
  describe('AGENT_ARTIFACT_KIND', () => {
    it('contains RECORD_SUMMARY and PROJECT_PROGRESS', () => {
      expect(AGENT_ARTIFACT_KIND.RECORD_SUMMARY).toBe('RECORD_SUMMARY')
      expect(AGENT_ARTIFACT_KIND.PROJECT_PROGRESS).toBe('PROJECT_PROGRESS')
    })

    it('is frozen', () => {
      expect(Object.isFrozen(AGENT_ARTIFACT_KIND)).toBe(true)
    })

    it('has exactly two entries', () => {
      expect(Object.keys(AGENT_ARTIFACT_KIND)).toHaveLength(2)
    })
  })

  describe('AGENT_RUN_STATUS', () => {
    it('contains all expected statuses', () => {
      expect(AGENT_RUN_STATUS.QUEUED).toBe('QUEUED')
      expect(AGENT_RUN_STATUS.RUNNING).toBe('RUNNING')
      expect(AGENT_RUN_STATUS.SUCCEEDED).toBe('SUCCEEDED')
      expect(AGENT_RUN_STATUS.FAILED).toBe('FAILED')
      expect(AGENT_RUN_STATUS.CANCELLED).toBe('CANCELLED')
      expect(AGENT_RUN_STATUS.LIMIT_EXCEEDED).toBe('LIMIT_EXCEEDED')
      expect(AGENT_RUN_STATUS.INVALID_OUTPUT).toBe('INVALID_OUTPUT')
    })

    it('is frozen', () => {
      expect(Object.isFrozen(AGENT_RUN_STATUS)).toBe(true)
    })
  })

  describe('ACTIVE_AGENT_RUN_STATUSES', () => {
    it('contains QUEUED and RUNNING', () => {
      expect(ACTIVE_AGENT_RUN_STATUSES.has(AGENT_RUN_STATUS.QUEUED)).toBe(true)
      expect(ACTIVE_AGENT_RUN_STATUSES.has(AGENT_RUN_STATUS.RUNNING)).toBe(true)
    })

    it('does not contain terminal statuses', () => {
      expect(ACTIVE_AGENT_RUN_STATUSES.has(AGENT_RUN_STATUS.SUCCEEDED)).toBe(false)
      expect(ACTIVE_AGENT_RUN_STATUSES.has(AGENT_RUN_STATUS.FAILED)).toBe(false)
      expect(ACTIVE_AGENT_RUN_STATUSES.has(AGENT_RUN_STATUS.CANCELLED)).toBe(false)
    })

    it('has exactly two entries', () => {
      expect(ACTIVE_AGENT_RUN_STATUSES.size).toBe(2)
    })
  })
})
