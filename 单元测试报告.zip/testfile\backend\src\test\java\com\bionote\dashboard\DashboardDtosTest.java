package com.bionote.dashboard;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("DashboardDtos 测试")
class DashboardDtosTest {

    @Test
    @DisplayName("Task 记录应正确构造并读取所有字段")
    void shouldConstructTaskWithAllFields() {
        UUID targetId = UUID.randomUUID();
        UUID projectId = UUID.randomUUID();
        Instant now = Instant.now();

        DashboardDtos.Task task = new DashboardDtos.Task(
                "changes:xxx", "CHANGES_REQUESTED", targetId, "实验标题",
                projectId, "项目名称", now, 3, "继续修改", false);

        assertAll(
                () -> assertEquals("changes:xxx", task.id()),
                () -> assertEquals("CHANGES_REQUESTED", task.type()),
                () -> assertEquals(targetId, task.targetId()),
                () -> assertEquals("实验标题", task.title()),
                () -> assertEquals(projectId, task.projectId()),
                () -> assertEquals("项目名称", task.projectName()),
                () -> assertEquals(now, task.time()),
                () -> assertEquals(3, task.revisionNo()),
                () -> assertEquals("继续修改", task.action()),
                () -> assertFalse(task.stale())
        );
    }

    @Test
    @DisplayName("Task 中 revisionNo 可为 null")
    void shouldAllowNullRevisionNo() {
        DashboardDtos.Task task = new DashboardDtos.Task(
                "task-1", "CHANGES_REQUESTED", UUID.randomUUID(), "标题",
                UUID.randomUUID(), "项目", Instant.now(), null, "操作", false);

        assertNull(task.revisionNo());
    }

    @Test
    @DisplayName("Task stale=true 应正确设置")
    void shouldSetStaleTrue() {
        DashboardDtos.Task task = new DashboardDtos.Task(
                "task-1", "PENDING_REVIEW", UUID.randomUUID(), "标题",
                UUID.randomUUID(), "项目", Instant.now(), 2, "开始审核", true);

        assertTrue(task.stale());
    }

    @Test
    @DisplayName("Summary 记录应正确构造并读取所有字段")
    void shouldConstructSummaryWithAllFields() {
        DashboardDtos.Summary summary = new DashboardDtos.Summary(10L, 5L, 2L, 3L, 1L, 8L);

        assertAll(
                () -> assertEquals(10L, summary.projectCount()),
                () -> assertEquals(5L, summary.editableRecordCount()),
                () -> assertEquals(2L, summary.changesRequestedCount()),
                () -> assertEquals(3L, summary.pendingReviewCount()),
                () -> assertEquals(1L, summary.pendingInvitationCount()),
                () -> assertEquals(8L, summary.unreadNotificationCount())
        );
    }

    @Test
    @DisplayName("Summary 全零值应正确构造")
    void shouldConstructZeroSummary() {
        DashboardDtos.Summary summary = new DashboardDtos.Summary(0L, 0L, 0L, 0L, 0L, 0L);

        assertEquals(0L, summary.projectCount());
        assertEquals(0L, summary.unreadNotificationCount());
    }

    @Test
    @DisplayName("相同值的 Task 应相等")
    void shouldBeEqualWhenSameValues() {
        UUID targetId = UUID.randomUUID();
        UUID projectId = UUID.randomUUID();
        Instant now = Instant.now();

        DashboardDtos.Task t1 = new DashboardDtos.Task("id", "TYPE", targetId, "A", projectId, "P", now, 1, "action", false);
        DashboardDtos.Task t2 = new DashboardDtos.Task("id", "TYPE", targetId, "A", projectId, "P", now, 1, "action", false);

        assertEquals(t1, t2);
        assertEquals(t1.hashCode(), t2.hashCode());
    }
}
