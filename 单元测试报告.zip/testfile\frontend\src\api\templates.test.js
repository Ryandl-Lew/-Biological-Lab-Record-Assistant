import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('./client', () => ({ request: vi.fn() }))

import { request } from './client'
import {
  fetchTemplates,
  fetchTemplate,
  createTemplate,
  updateTemplate,
  deleteTemplate,
  copyTemplate,
} from './templates'

describe('templates API', () => {
  beforeEach(() => {
    request.mockReset()
  })

  describe('fetchTemplates', () => {
    it('sends GET /templates with no params', async () => {
      request.mockResolvedValueOnce([])
      await fetchTemplates()
      expect(request).toHaveBeenCalledWith('/templates')
    })

    it('sends GET /templates with params', async () => {
      request.mockResolvedValueOnce([])
      await fetchTemplates({ category: 'molecular', page: 1 })
      expect(request).toHaveBeenCalledWith('/templates?category=molecular&page=1')
    })

    it('filters out falsy params', async () => {
      request.mockResolvedValueOnce([])
      await fetchTemplates({ category: 'cell', keyword: '', page: undefined, size: null })
      expect(request).toHaveBeenCalledWith('/templates?category=cell')
    })
  })

  describe('fetchTemplate', () => {
    it('sends GET /templates/:id', async () => {
      request.mockResolvedValueOnce({ id: 'tpl-1', name: '分子克隆模板' })
      const result = await fetchTemplate('tpl-1')
      expect(request).toHaveBeenCalledWith('/templates/tpl-1')
      expect(result).toEqual({ id: 'tpl-1', name: '分子克隆模板' })
    })
  })

  describe('createTemplate', () => {
    it('sends POST /templates with input', async () => {
      request.mockResolvedValueOnce({ id: 'tpl-new', name: '新模板' })
      const input = { name: '新模板', category: 'cell', fields: [] }
      await createTemplate(input)
      expect(request).toHaveBeenCalledWith('/templates', {
        method: 'POST',
        body: JSON.stringify(input),
      })
    })
  })

  describe('updateTemplate', () => {
    it('sends PUT /templates/:id with input', async () => {
      request.mockResolvedValueOnce({ id: 'tpl-1', name: '已更新模板' })
      await updateTemplate('tpl-1', { name: '已更新模板' })
      expect(request).toHaveBeenCalledWith('/templates/tpl-1', {
        method: 'PUT',
        body: JSON.stringify({ name: '已更新模板' }),
      })
    })
  })

  describe('deleteTemplate', () => {
    it('sends DELETE /templates/:id', async () => {
      request.mockResolvedValueOnce(null)
      await deleteTemplate('tpl-1')
      expect(request).toHaveBeenCalledWith('/templates/tpl-1', { method: 'DELETE' })
    })
  })

  describe('copyTemplate', () => {
    it('sends POST /templates/:id/copy', async () => {
      request.mockResolvedValueOnce({ id: 'tpl-copy', name: '分子克隆模板 (副本)' })
      await copyTemplate('tpl-1')
      expect(request).toHaveBeenCalledWith('/templates/tpl-1/copy', { method: 'POST' })
    })
  })
})
