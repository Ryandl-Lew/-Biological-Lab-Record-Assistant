package com.bionote.auth;

import com.bionote.user.UserDtos;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("AuthDtos - DTO 测试")
class AuthDtosTest {

    @Nested
    @DisplayName("RegisterRequest")
    class RegisterRequestTests {

        @Test
        @DisplayName("应该成功创建 RegisterRequest")
        void shouldCreateRegisterRequest() {
            var request = new AuthDtos.RegisterRequest("张三", "test@example.com", "password123");
            assertEquals("张三", request.displayName());
            assertEquals("test@example.com", request.email());
            assertEquals("password123", request.password());
        }

        @Test
        @DisplayName("displayName 为空时验证应失败")
        void shouldHaveNotBlankDisplayName() {
            var request = new AuthDtos.RegisterRequest("", "test@example.com", "password123");
            assertEquals("", request.displayName());
        }

        @Test
        @DisplayName("密码长度不符合要求时记录仍能创建")
        void shouldAcceptShortPasswordForDto() {
            var request = new AuthDtos.RegisterRequest("test", "a@b.com", "short");
            assertEquals("short", request.password());
        }
    }

    @Nested
    @DisplayName("LoginRequest")
    class LoginRequestTests {

        @Test
        @DisplayName("应该成功创建 LoginRequest")
        void shouldCreateLoginRequest() {
            var request = new AuthDtos.LoginRequest("user@example.com", "secret123");
            assertEquals("user@example.com", request.email());
            assertEquals("secret123", request.password());
        }

        @Test
        @DisplayName("email 可为空字符串")
        void shouldAllowEmptyEmail() {
            var request = new AuthDtos.LoginRequest("", "password");
            assertEquals("", request.email());
        }
    }

    @Nested
    @DisplayName("AuthResult")
    class AuthResultTests {

        @Test
        @DisplayName("应该成功创建包含 token 和 user 的 AuthResult")
        void shouldCreateAuthResult() {
            var user = new UserDtos.UserView(UUID.randomUUID(), "Alice", "alice@example.com",
                    "/api/v1/users/avatar", Instant.now(), null);
            var result = new AuthDtos.AuthResult("jwt-token-abc", user);
            assertEquals("jwt-token-abc", result.accessToken());
            assertNotNull(result.user());
            assertEquals("Alice", result.user().displayName());
        }

        @Test
        @DisplayName("avatarUrl 可为 null")
        void shouldAllowNullAvatarUrl() {
            var user = new UserDtos.UserView(UUID.randomUUID(), "Bob", "bob@test.com",
                    null, Instant.now(), null);
            var result = new AuthDtos.AuthResult("token", user);
            assertNull(result.user().avatarUrl());
        }

        @Test
        @DisplayName("两个相同数据对象应相等")
        void shouldBeEqualForSameData() {
            var id = UUID.randomUUID();
            var user1 = new UserDtos.UserView(id, "Tom", "tom@test.com", null, Instant.EPOCH, null);
            var user2 = new UserDtos.UserView(id, "Tom", "tom@test.com", null, Instant.EPOCH, null);
            assertEquals(user1, user2);
        }
    }
}
