package com.bionote.revision.infrastructure.persistence;

import com.bionote.common.ApiException;
import com.bionote.revision.RevisionDtos;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.http.HttpStatus;

import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.Instant;
import java.util.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("JdbcRevisionQueryAdapter - JDBC 修订查询适配器测试")
class JdbcRevisionQueryAdapterTest {

    @Mock private JdbcTemplate jdbc;
    @Mock private ObjectMapper json;
    @InjectMocks private JdbcRevisionQueryAdapter adapter;

    private final UUID actorId = UUID.randomUUID();
    private final UUID recordId = UUID.randomUUID();
    private final UUID revisionId = UUID.randomUUID();

    @Nested
    @DisplayName("list - 分页查询修订列表")
    class ListTests {

        @Test
        @DisplayName("非成员应抛出 NOT_FOUND")
        void shouldThrowNotFoundForNonMember() {
            when(jdbc.queryForObject(anyString(), eq(Integer.class), eq(recordId.toString()))).thenReturn(0);

            var ex = assertThrows(ApiException.class,
                    () -> adapter.list(actorId, recordId, 0, 20));
            assertEquals("RESOURCE_NOT_FOUND", ex.code());
        }

        @Test
        @DisplayName("成员应成功查询")
        void shouldQuerySuccessfullyForMember() {
            when(jdbc.queryForObject(anyString(), eq(Integer.class), eq(recordId.toString()))).thenReturn(1);
            when(jdbc.queryForObject(anyString(), eq(Integer.class),
                    eq(recordId.toString()), eq(actorId.toString()))).thenReturn(1);
            when(jdbc.query(anyString(), any(RowMapper.class), any(), anyInt(), anyInt()))
                    .thenReturn(List.of());

            var result = adapter.list(actorId, recordId, 0, 20);

            assertNotNull(result);
        }
    }

    @Nested
    @DisplayName("detail - 查询修订详情")
    class DetailTests {

        @Test
        @DisplayName("记录不存在应抛出 NOT_FOUND")
        void shouldThrowNotFoundForMissingRevision() throws Exception {
            when(json.readValue(anyString(), any(com.fasterxml.jackson.core.type.TypeReference.class)))
                    .thenReturn(Map.of());
            when(jdbc.queryForList(anyString(), eq(Map.class))).thenReturn(List.of());

            var ex = assertThrows(ApiException.class,
                    () -> adapter.detail(actorId, recordId, revisionId));
            assertEquals(HttpStatus.NOT_FOUND, ex.status());
        }
    }

    @Nested
    @DisplayName("workingCopySource - 工作副本快照")
    class WorkingCopySourceTests {

        @Test
        @DisplayName("非成员应抛出 NOT_FOUND")
        void shouldThrowNotFoundForWorkingCopyNonMember() {
            when(jdbc.queryForList(anyString(), eq(actorId.toString()), eq(recordId.toString())))
                    .thenReturn(List.of());

            var ex = assertThrows(ApiException.class,
                    () -> adapter.workingCopySource(actorId, recordId));
            assertEquals("RESOURCE_NOT_FOUND", ex.code());
        }
    }
}
