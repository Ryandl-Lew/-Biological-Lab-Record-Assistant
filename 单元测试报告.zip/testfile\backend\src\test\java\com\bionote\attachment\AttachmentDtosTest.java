package com.bionote.attachment;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("AttachmentDtos 测试")
class AttachmentDtosTest {

    @Test
    @DisplayName("View 记录应正确构造并读取所有字段")
    void shouldConstructViewWithAllFields() {
        UUID id = UUID.randomUUID();
        UUID recordId = UUID.randomUUID();
        UUID uploaderId = UUID.randomUUID();
        Instant now = Instant.now();

        AttachmentDtos.View view = new AttachmentDtos.View(
                id, recordId, "test.pdf", "application/pdf", 1024L,
                true, uploaderId, "张三", now, false, true);

        assertAll(
                () -> assertEquals(id, view.id()),
                () -> assertEquals(recordId, view.recordId()),
                () -> assertEquals("test.pdf", view.originalFilename()),
                () -> assertEquals("application/pdf", view.mediaType()),
                () -> assertEquals(1024L, view.sizeBytes()),
                () -> assertTrue(view.previewable()),
                () -> assertEquals(uploaderId, view.uploaderId()),
                () -> assertEquals("张三", view.uploaderName()),
                () -> assertEquals(now, view.createdAt()),
                () -> assertFalse(view.deleted()),
                () -> assertTrue(view.canDelete())
        );
    }

    @Test
    @DisplayName("deleted=true 时应正确反映")
    void shouldReflectDeletedState() {
        AttachmentDtos.View view = new AttachmentDtos.View(
                UUID.randomUUID(), UUID.randomUUID(), "file.txt",
                "text/plain", 512L, false, UUID.randomUUID(),
                "李四", Instant.now(), true, false);

        assertTrue(view.deleted());
    }

    @Test
    @DisplayName("相同值的两个 View 应相等")
    void shouldBeEqualWhenSameValues() {
        UUID id = UUID.randomUUID();
        UUID recordId = UUID.randomUUID();
        UUID uploaderId = UUID.randomUUID();
        Instant now = Instant.now();

        AttachmentDtos.View v1 = new AttachmentDtos.View(id, recordId, "a.txt", "text/plain", 100L, false, uploaderId, "王五", now, false, false);
        AttachmentDtos.View v2 = new AttachmentDtos.View(id, recordId, "a.txt", "text/plain", 100L, false, uploaderId, "王五", now, false, false);

        assertEquals(v1, v2);
        assertEquals(v1.hashCode(), v2.hashCode());
    }

    @Test
    @DisplayName("不同值的 View 应不相等")
    void shouldNotBeEqualWhenDifferentValues() {
        AttachmentDtos.View v1 = new AttachmentDtos.View(UUID.randomUUID(), UUID.randomUUID(), "a.txt", "text/plain", 100L, false, UUID.randomUUID(), "A", Instant.now(), false, false);
        AttachmentDtos.View v2 = new AttachmentDtos.View(UUID.randomUUID(), UUID.randomUUID(), "b.txt", "text/plain", 200L, false, UUID.randomUUID(), "B", Instant.now(), false, false);

        assertNotEquals(v1, v2);
    }
}
