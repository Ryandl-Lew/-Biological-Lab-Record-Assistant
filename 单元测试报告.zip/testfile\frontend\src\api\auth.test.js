import { describe, it, expect, vi, beforeEach } from 'vitest'

vi.mock('./client', () => ({ request: vi.fn() }))

import { request } from './client'
import { login, register, logout, getCurrentUser } from './auth'

describe('auth API', () => {
  beforeEach(() => {
    request.mockReset()
  })

  describe('login', () => {
    it('sends POST /auth/login with credentials', async () => {
      const credentials = { email: 'test@example.com', password: 'password123' }
      request.mockResolvedValueOnce({ token: 'jwt-token' })

      const result = await login(credentials)
      expect(request).toHaveBeenCalledWith('/auth/login', {
        method: 'POST',
        body: JSON.stringify(credentials),
      })
      expect(result).toEqual({ token: 'jwt-token' })
    })

    it('propagates API errors', async () => {
      request.mockRejectedValueOnce(new Error('登录失败'))
      await expect(login({ email: 'bad@example.com', password: 'wrong' })).rejects.toThrow('登录失败')
    })
  })

  describe('register', () => {
    it('sends POST /auth/register with account data', async () => {
      const account = { email: 'new@example.com', password: 'pass123', displayName: '新用户' }
      request.mockResolvedValueOnce({ id: 'user-1' })

      await register(account)
      expect(request).toHaveBeenCalledWith('/auth/register', {
        method: 'POST',
        body: JSON.stringify(account),
      })
    })
  })

  describe('logout', () => {
    it('sends POST /auth/logout', async () => {
      request.mockResolvedValueOnce(null)
      await logout()
      expect(request).toHaveBeenCalledWith('/auth/logout', { method: 'POST' })
    })
  })

  describe('getCurrentUser', () => {
    it('sends GET /auth/me', async () => {
      request.mockResolvedValueOnce({ id: 'user-1', email: 'test@example.com' })
      const user = await getCurrentUser()
      expect(request).toHaveBeenCalledWith('/auth/me')
      expect(user).toEqual({ id: 'user-1', email: 'test@example.com' })
    })
  })
})
