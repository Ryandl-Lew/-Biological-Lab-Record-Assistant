package com.bionote.project.infrastructure.persistence;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@ActiveProfiles("test")
@TestPropertySource(properties = {"spring.flyway.enabled=false", "spring.jpa.hibernate.ddl-auto=update"})
class ProjectInvitationJpaRepositoryTest {

    @Autowired private ProjectInvitationJpaRepository repository;

    @BeforeEach
    void setUp() {
        repository.deleteAll();
    }

    @Test
    void shouldSaveAndFindInvitation() {
        UUID id = UUID.randomUUID();
        UUID projectId = UUID.randomUUID();
        Instant now = Instant.now();
        ProjectInvitationEntity entity = new ProjectInvitationEntity(
                id, projectId, UUID.randomUUID(), UUID.randomUUID(),
                "user@test.com", "PENDING", now.plusSeconds(86400), now, null, "key");

        repository.save(entity);

        Optional<ProjectInvitationEntity> found = repository.findById(id);
        assertTrue(found.isPresent());
        assertEquals("PENDING", found.get().status);
    }

    @Test
    void shouldFindPendingIds() {
        UUID projectId = UUID.randomUUID();
        UUID id1 = UUID.randomUUID();
        UUID id2 = UUID.randomUUID();
        Instant now = Instant.now();

        repository.save(new ProjectInvitationEntity(
                id1, projectId, UUID.randomUUID(), UUID.randomUUID(),
                "a@t.com", "PENDING", now.plusSeconds(86400), now, null, "k1"));
        repository.save(new ProjectInvitationEntity(
                id2, projectId, UUID.randomUUID(), UUID.randomUUID(),
                "b@t.com", "ACCEPTED", now.plusSeconds(86400), now, now, "k2"));

        var pendingIds = repository.findPendingIds(projectId);
        assertFalse(pendingIds.isEmpty());
    }

    @Test
    void shouldExpireForProject() {
        UUID projectId = UUID.randomUUID();
        Instant now = Instant.now();
        repository.save(new ProjectInvitationEntity(
                UUID.randomUUID(), projectId, UUID.randomUUID(), UUID.randomUUID(),
                "a@t.com", "PENDING", now.plusSeconds(86400), now, null, "k1"));

        int expired = repository.expireForProject(projectId, Instant.now());
        assertTrue(expired >= 0);
    }

    @Test
    void shouldChangePendingStatus() {
        UUID id = UUID.randomUUID();
        Instant now = Instant.now();
        repository.save(new ProjectInvitationEntity(
                id, UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID(),
                "u@t.com", "PENDING", now.plusSeconds(86400), now, null, "key"));

        int changed = repository.changePendingStatus(id, "ACCEPTED", Instant.now());
        assertEquals(1, changed);
    }
}
