import { describe, it, expect, vi, beforeEach } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import AgentMvpPage from '@/pages/AgentMvpPage';

const mockProjects = [
  { id: 'proj-1', name: 'Project Alpha', status: 'ACTIVE' },
  { id: 'proj-2', name: 'Project Beta', status: 'ARCHIVED' },
  { id: 'proj-3', name: 'Project Gamma', status: 'ACTIVE' },
];

const mockProjectDetail = {
  id: 'proj-1',
  name: 'Project Alpha',
  status: 'ACTIVE',
  currentUserRole: 'OWNER',
};

const mockFetchProjects = vi.fn();
const mockFetchProject = vi.fn();

vi.mock('@/api', () => ({
  fetchProjects: (...args) => mockFetchProjects(...args),
  fetchProject: (...args) => mockFetchProject(...args),
}));

vi.mock('@/components/agent/ProjectChatPanel', () => ({
  default: ({ project, variant }) => (
    <div data-testid="chat-panel" data-project-id={project?.id} data-variant={variant}>
      ProjectChatPanel
    </div>
  ),
}));

vi.mock('lucide-react', () => ({
  Bot: () => <span data-testid="icon-bot">BotIcon</span>,
  ExternalLink: () => <span data-testid="icon-external-link">ExternalLinkIcon</span>,
}));

vi.mock('@/components/ui', () => ({
  EmptyState: ({ icon: Icon, title, description }) => (
    <div data-testid="empty-state">
      {Icon && <Icon />}
      <h3>{title}</h3>
      <p>{description}</p>
    </div>
  ),
  PageHeader: ({ eyebrow, title, description }) => (
    <header>
      <p>{eyebrow}</p>
      <h1>{title}</h1>
      {description && <p>{description}</p>}
    </header>
  ),
  Surface: ({ children }) => <div data-testid="surface">{children}</div>,
}));

describe('AgentMvpPage', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    localStorage.clear();
    mockFetchProjects.mockResolvedValue({ items: mockProjects });
    mockFetchProject.mockResolvedValue(mockProjectDetail);
  });

  function renderPage(initialRoute = '/agent') {
    return render(
      <MemoryRouter initialEntries={[initialRoute]}>
        <AgentMvpPage />
      </MemoryRouter>,
    );
  }

  it('should display the page header correctly', async () => {
    renderPage();
    expect(screen.getByText('发现与账户')).toBeInTheDocument();
    expect(screen.getByText('Agent助手')).toBeInTheDocument();
  });

  it('should load and display project list in the select dropdown', async () => {
    renderPage();
    await waitFor(() => {
      expect(mockFetchProjects).toHaveBeenCalledWith({ status: 'ACTIVE', size: 100 });
    });
    const select = screen.getByLabelText('选择 Agent 适用的实验项目');
    expect(select).toBeInTheDocument();
    expect(screen.getByText('Project Alpha')).toBeInTheDocument();
    expect(screen.getByText('Project Beta（ARCHIVED）')).toBeInTheDocument();
  });

  it('should auto-select the first project when no projectId in URL', async () => {
    renderPage();
    await waitFor(() => {
      expect(mockFetchProject).toHaveBeenCalledWith('proj-1');
    });
  });

  it('should display error message when fetchProjects fails', async () => {
    mockFetchProjects.mockRejectedValueOnce(new Error('Failed to load'));
    renderPage();
    await waitFor(() => {
      expect(screen.getByRole('alert')).toHaveTextContent('Failed to load');
    });
  });

  it('should show EmptyState when projects are empty', async () => {
    mockFetchProjects.mockResolvedValueOnce({ items: [] });
    renderPage('/agent');
    await waitFor(() => {
      expect(screen.getByTestId('empty-state')).toBeInTheDocument();
      expect(screen.getByText('请先选择实验项目')).toBeInTheDocument();
    });
  });

  it('should render ProjectChatPanel when a project is loaded', async () => {
    renderPage();
    await waitFor(() => {
      expect(screen.getByTestId('chat-panel')).toBeInTheDocument();
    });
    expect(screen.getByTestId('chat-panel')).toHaveAttribute('data-project-id', 'proj-1');
  });

  it('should show demo scenario cards when project is loaded', async () => {
    renderPage();
    await waitFor(() => {
      expect(screen.getByText('实验记录智能总结')).toBeInTheDocument();
      expect(screen.getByText('项目进度助手')).toBeInTheDocument();
      expect(screen.getByText('实验数据分析助手')).toBeInTheDocument();
    });
  });

  it('should show "前往项目查看记录" link for OWNER role', async () => {
    renderPage();
    await waitFor(() => {
      expect(screen.getByText('前往项目查看记录 →')).toBeInTheDocument();
      expect(screen.getByText('前往项目详情 →')).toBeInTheDocument();
    });
  });

  it('should display loading text while fetching', async () => {
    mockFetchProjects.mockImplementation(
      () => new Promise((resolve) => setTimeout(() => resolve({ items: [] }), 100)),
    );
    renderPage();
    expect(screen.getByText('加载中…')).toBeInTheDocument();
  });

  it('should store selected projectId in localStorage', async () => {
    renderPage();
    await waitFor(() => {
      expect(localStorage.getItem('bionote.agent.projectId')).toBe('proj-1');
    });
  });

  it('should show "暂无可用项目" when projects list is empty', async () => {
    mockFetchProjects.mockResolvedValueOnce({ items: [] });
    renderPage();
    await waitFor(() => {
      expect(screen.getByText('暂无可用项目')).toBeInTheDocument();
    });
  });
});
