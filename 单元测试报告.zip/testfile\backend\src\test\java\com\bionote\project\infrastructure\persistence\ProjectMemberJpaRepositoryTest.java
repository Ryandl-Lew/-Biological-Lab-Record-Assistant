package com.bionote.project.infrastructure.persistence;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.TestPropertySource;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@ActiveProfiles("test")
@TestPropertySource(properties = {"spring.flyway.enabled=false", "spring.jpa.hibernate.ddl-auto=update"})
class ProjectMemberJpaRepositoryTest {

    @Autowired private ProjectMemberJpaRepository repository;

    private final UUID projectId = UUID.randomUUID();
    private final UUID userId = UUID.randomUUID();

    @BeforeEach
    void setUp() {
        repository.deleteAll();
    }

    @Test
    void shouldSaveAndFindMember() {
        ProjectMemberEntity entity = new ProjectMemberEntity(projectId, userId, "MEMBER",
                Instant.now(), Instant.now());
        repository.save(entity);

        Optional<ProjectMemberEntity> found = repository.findById(new ProjectMemberId(projectId, userId));
        assertTrue(found.isPresent());
        assertEquals("MEMBER", found.get().role);
    }

    @Test
    void shouldCountMembersByProjectId() {
        repository.save(new ProjectMemberEntity(projectId, UUID.randomUUID(), "OWNER", Instant.now(), Instant.now()));
        repository.save(new ProjectMemberEntity(projectId, UUID.randomUUID(), "MEMBER", Instant.now(), Instant.now()));

        long count = repository.countByIdProjectId(projectId);
        assertEquals(2, count);
    }

    @Test
    void shouldFindMemberIds() {
        UUID user1 = UUID.randomUUID();
        UUID user2 = UUID.randomUUID();
        repository.save(new ProjectMemberEntity(projectId, user1, "OWNER", Instant.now(), Instant.now()));
        repository.save(new ProjectMemberEntity(projectId, user2, "MEMBER", Instant.now(), Instant.now()));

        List<UUID> ids = repository.findMemberIds(projectId);
        assertEquals(2, ids.size());
        assertTrue(ids.contains(user1));
        assertTrue(ids.contains(user2));
    }

    @Test
    void shouldUpdateRole() {
        repository.save(new ProjectMemberEntity(projectId, userId, "MEMBER", Instant.now(), Instant.now()));

        int updated = repository.updateRole(projectId, userId, "REVIEWER");
        assertEquals(1, updated);

        Optional<ProjectMemberEntity> found = repository.findById(new ProjectMemberId(projectId, userId));
        assertTrue(found.isPresent());
        assertEquals("REVIEWER", found.get().role);
    }

    @Test
    void shouldTouchMember() {
        Instant initial = Instant.now();
        repository.save(new ProjectMemberEntity(projectId, userId, "MEMBER", initial, initial));

        Instant later = initial.plusSeconds(3600);
        int touched = repository.touch(projectId, userId, later);
        assertEquals(1, touched);
    }
}
