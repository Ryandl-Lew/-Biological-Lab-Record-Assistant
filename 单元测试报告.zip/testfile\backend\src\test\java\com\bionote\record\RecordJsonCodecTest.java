package com.bionote.record;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.*;

class RecordJsonCodecTest {

    private RecordJsonCodec codec;
    private ObjectMapper objectMapper;

    @BeforeEach
    void setUp() {
        objectMapper = new ObjectMapper();
        codec = new RecordJsonCodec(objectMapper);
    }

    @Test
    void shouldEncodeObject() {
        Map<String, Object> data = Map.of("key", "value", "number", 42);
        String encoded = codec.encode(data);
        assertNotNull(encoded);
        assertTrue(encoded.contains("key"));
        assertTrue(encoded.contains("value"));
    }

    @Test
    void shouldDecodeString() {
        Object result = codec.decode("{\"name\":\"test\",\"count\":5}");
        assertNotNull(result);
        assertTrue(result instanceof Map);
        @SuppressWarnings("unchecked")
        Map<String, Object> map = (Map<String, Object>) result;
        assertEquals("test", map.get("name"));
        assertEquals(5, map.get("count"));
    }

    @Test
    void shouldDecodeMap() {
        Map<String, Object> result = codec.decodeMap("{\"a\":\"1\",\"b\":\"2\"}");
        assertEquals("1", result.get("a"));
        assertEquals("2", result.get("b"));
    }

    @Test
    void shouldReturnEmptyMapForInvalidJson() {
        Map<String, Object> result = codec.decodeMap("invalid json");
        assertNotNull(result);
        assertTrue(result.isEmpty());
    }

    @Test
    void shouldReturnEmptyMapForNull() {
        Map<String, Object> result = codec.decodeMap("null");
        assertNotNull(result);
    }

    @Test
    void shouldReturnObjectForInvalidDecode() {
        Object result = codec.decode("not-json");
        assertNotNull(result);
        assertTrue(result instanceof Map);
        assertTrue(((Map<?, ?>) result).isEmpty());
    }

    @Test
    void shouldEncodeNull() {
        String encoded = codec.encode(null);
        assertNotNull(encoded);
        assertEquals("null", encoded);
    }

    @Test
    void shouldEncodeAndDecodeRoundtrip() {
        Map<String, Object> original = new LinkedHashMap<>();
        original.put("name", "实验名称");
        original.put("fields", List.of(Map.of("key", "f1", "type", "TEXT")));

        String encoded = codec.encode(original);
        Object decoded = codec.decode(encoded);

        assertNotNull(decoded);
    }
}
