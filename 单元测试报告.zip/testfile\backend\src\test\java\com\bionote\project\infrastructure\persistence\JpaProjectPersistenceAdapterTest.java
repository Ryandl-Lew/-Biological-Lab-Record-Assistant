package com.bionote.project.infrastructure.persistence;

import com.bionote.project.ProjectInvitationStore;
import com.bionote.project.ProjectMemberStore;
import com.bionote.project.ProjectStore;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class JpaProjectPersistenceAdapterTest {

    @Mock private ProjectJpaRepository projects;
    @Mock private ProjectMemberJpaRepository members;
    @Mock private ProjectInvitationJpaRepository invitations;
    @Mock private ProjectRecordReadRepository records;

    private JpaProjectPersistenceAdapter adapter;
    private final UUID projectId = UUID.randomUUID();
    private final UUID userId = UUID.randomUUID();

    @BeforeEach
    void setUp() {
        adapter = new JpaProjectPersistenceAdapter(projects, members, invitations, records);
    }

    @Test
    void shouldInsertProject() {
        ProjectStore.ProjectRecord project = new ProjectStore.ProjectRecord(
                projectId, "项目", "描述", null, "ACTIVE", userId,
                Instant.now(), Instant.now(), null, 0L);

        when(projects.saveAndFlush(any())).thenReturn(null);

        assertDoesNotThrow(() -> adapter.insert(project));
        verify(projects).saveAndFlush(any());
    }

    @Test
    void shouldFindProjectById() {
        ProjectEntity entity = new ProjectEntity(projectId, "项目", null, null, userId, Instant.now());
        when(projects.findById(projectId)).thenReturn(Optional.of(entity));

        Optional<ProjectStore.ProjectRecord> result = adapter.findById(projectId);

        assertTrue(result.isPresent());
        assertEquals("项目", result.get().name());
    }

    @Test
    void shouldReturnEmptyWhenProjectNotFound() {
        when(projects.findById(projectId)).thenReturn(Optional.empty());

        Optional<ProjectStore.ProjectRecord> result = adapter.findById(projectId);

        assertFalse(result.isPresent());
    }

    @Test
    void shouldRecordCount() {
        when(records.countByProjectIdAndDeletedAtIsNullAndProvisionalFalse(projectId)).thenReturn(5L);

        assertEquals(5L, adapter.recordCount(projectId));
    }

    @Test
    void shouldInsertMember() {
        when(members.saveAndFlush(any())).thenReturn(null);

        assertDoesNotThrow(() -> adapter.insert(projectId, userId, "MEMBER", Instant.now(), Instant.now()));
        verify(members).saveAndFlush(any());
    }

    @Test
    void shouldFindRole() {
        ProjectMemberEntity memberEntity = new ProjectMemberEntity(projectId, userId, "OWNER",
                Instant.now(), Instant.now());
        when(members.findById(any())).thenReturn(Optional.of(memberEntity));

        Optional<String> role = adapter.findRole(projectId, userId);
        assertTrue(role.isPresent());
        assertEquals("OWNER", role.get());
    }

    @Test
    void shouldCheckMemberExists() {
        when(members.existsById(any())).thenReturn(true);
        assertTrue(adapter.exists(projectId, userId));
    }

    @Test
    void shouldCountMembers() {
        when(members.countByIdProjectId(projectId)).thenReturn(3L);
        assertEquals(3L, adapter.count(projectId));
    }

    @Test
    void shouldGetMemberIds() {
        List<UUID> ids = List.of(UUID.randomUUID(), UUID.randomUUID());
        when(members.findMemberIds(projectId)).thenReturn(ids);
        assertEquals(2, adapter.memberIds(projectId).size());
    }

    @Test
    void shouldInsertInvitation() {
        ProjectInvitationStore.InvitationRecord invitation = new ProjectInvitationStore.InvitationRecord(
                UUID.randomUUID(), projectId, userId, UUID.randomUUID(),
                "user@test.com", "PENDING", Instant.now().plusSeconds(86400),
                Instant.now(), null, "key");
        when(invitations.saveAndFlush(any())).thenReturn(null);

        assertDoesNotThrow(() -> adapter.insert(invitation));
        verify(invitations).saveAndFlush(any());
    }

    @Test
    void shouldFindInvitation() {
        UUID invitationId = UUID.randomUUID();
        ProjectInvitationEntity entity = new ProjectInvitationEntity(
                invitationId, projectId, userId, UUID.randomUUID(),
                "u@t.com", "PENDING", Instant.now().plusSeconds(86400),
                Instant.now(), null, "key");
        when(invitations.findById(invitationId)).thenReturn(Optional.of(entity));

        Optional<ProjectInvitationStore.InvitationRecord> result = adapter.findInvitation(invitationId);
        assertTrue(result.isPresent());
        assertEquals("PENDING", result.get().status());
    }

    @Test
    void shouldBlockingArchive() {
        when(records.findByProjectIdAndDeletedAtIsNullAndProvisionalFalseAndStatusNot(eq(projectId), eq("COMPLETED")))
                .thenReturn(List.of());

        List<ProjectRecordReadEntity> result = adapter.blockingArchive(projectId);
        assertTrue(result.isEmpty());
    }

    @Test
    void shouldBlockingMember() {
        when(records.findByProjectIdAndCreatorIdAndDeletedAtIsNullAndProvisionalFalseAndStatusNot(
                eq(projectId), eq(userId), eq("COMPLETED"))).thenReturn(List.of());

        List<ProjectRecordReadEntity> result = adapter.blockingMember(projectId, userId);
        assertTrue(result.isEmpty());
    }
}
