import { describe, it, expect, vi } from 'vitest';
import { render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import AuthLayout from '@/components/auth/AuthLayout';

describe('AuthLayout', () => {
  const renderWithRouter = (ui) => render(<MemoryRouter>{ui}</MemoryRouter>);

  it('renders title and subtitle', () => {
    renderWithRouter(
      <AuthLayout title="登录" subtitle="欢迎回来">
        <div>表单内容</div>
      </AuthLayout>
    );
    expect(screen.getByText('登录')).toBeInTheDocument();
    expect(screen.getByText('欢迎回来')).toBeInTheDocument();
  });

  it('renders children content', () => {
    renderWithRouter(
      <AuthLayout title="注册" subtitle="创建账号">
        <input placeholder="邮箱" />
      </AuthLayout>
    );
    expect(screen.getByPlaceholderText('邮箱')).toBeInTheDocument();
  });

  it('renders footer when provided', () => {
    renderWithRouter(
      <AuthLayout title="登录" subtitle="欢迎" footer={<a href="/register">还没有账号？</a>}>
        <div>表单</div>
      </AuthLayout>
    );
    expect(screen.getByText('还没有账号？')).toBeInTheDocument();
  });

  it('renders BioNote branding text', () => {
    renderWithRouter(
      <AuthLayout title="登录" subtitle="欢迎">
        <div>表单</div>
      </AuthLayout>
    );
    expect(screen.getAllByText('BioNote').length).toBeGreaterThanOrEqual(1);
  });

  it('renders feature list items', () => {
    renderWithRouter(
      <AuthLayout title="登录" subtitle="欢迎">
        <div>表单</div>
      </AuthLayout>
    );
    expect(screen.getByText('结构化实验记录')).toBeInTheDocument();
    expect(screen.getByText('全文快速检索')).toBeInTheDocument();
    expect(screen.getByText('团队实时协作')).toBeInTheDocument();
    expect(screen.getByText('审计与版本追踪')).toBeInTheDocument();
  });
});
