package com.bionote.audit.infrastructure.persistence;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.TestPropertySource;

import java.time.Instant;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@TestPropertySource(properties = {"spring.flyway.enabled=false", "spring.jpa.hibernate.ddl-auto=update"})
@DisplayName("AuditEventJpaRepository 测试")
class AuditEventJpaRepositoryTest {

    @Autowired
    private AuditEventJpaRepository repository;

    @Test
    @DisplayName("save 和 findById 应正确工作")
    void shouldSaveAndFindById() {
        UUID id = UUID.randomUUID();
        AuditEventEntity entity = new AuditEventEntity(id, UUID.randomUUID(), UUID.randomUUID(),
                UUID.randomUUID(), "RECORD_CREATED", "RECORD", UUID.randomUUID(),
                "{}", Instant.now());
        repository.saveAndFlush(entity);

        var found = repository.findById(id);

        assertTrue(found.isPresent());
        assertEquals("RECORD_CREATED", found.get().eventType);
        assertEquals("RECORD", found.get().targetType);
    }

    @Test
    @DisplayName("多个事件应能分别保存和查询")
    void shouldSaveMultipleEvents() {
        UUID id1 = UUID.randomUUID();
        UUID id2 = UUID.randomUUID();
        Instant now = Instant.now();

        repository.saveAndFlush(new AuditEventEntity(id1, UUID.randomUUID(), UUID.randomUUID(),
                UUID.randomUUID(), "RECORD_CREATED", "RECORD", UUID.randomUUID(), "{}", now));
        repository.saveAndFlush(new AuditEventEntity(id2, UUID.randomUUID(), UUID.randomUUID(),
                UUID.randomUUID(), "RECORD_DELETED", "RECORD", UUID.randomUUID(), "{}", now));

        assertTrue(repository.findById(id1).isPresent());
        assertTrue(repository.findById(id2).isPresent());
        assertEquals("RECORD_CREATED", repository.findById(id1).get().eventType);
        assertEquals("RECORD_DELETED", repository.findById(id2).get().eventType);
    }

    @Test
    @DisplayName("findAll 应返回所有保存的实体")
    void shouldFindAllEvents() {
        repository.deleteAll();
        long before = repository.count();

        repository.saveAndFlush(new AuditEventEntity(UUID.randomUUID(), UUID.randomUUID(), UUID.randomUUID(),
                UUID.randomUUID(), "RECORD_CREATED", "RECORD", UUID.randomUUID(), "{}", Instant.now()));

        assertTrue(repository.count() > before);
    }

    @Test
    @DisplayName("recordId 为 null 的事件应能保存")
    void shouldSaveEventWithNullRecordId() {
        UUID id = UUID.randomUUID();
        AuditEventEntity entity = new AuditEventEntity(id, UUID.randomUUID(), UUID.randomUUID(),
                null, "PROJECT_CREATED", "PROJECT", UUID.randomUUID(), "{}", Instant.now());
        repository.saveAndFlush(entity);

        var found = repository.findById(id);
        assertTrue(found.isPresent());
        assertNull(found.get().recordId);
    }
}
