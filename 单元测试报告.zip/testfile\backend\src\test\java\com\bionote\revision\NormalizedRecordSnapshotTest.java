package com.bionote.revision;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("NormalizedRecordSnapshot - 规范化快照记录测试")
class NormalizedRecordSnapshotTest {

    private final UUID recordId = UUID.randomUUID();
    private final UUID revisionId = UUID.randomUUID();

    @Nested
    @DisplayName("构造和字段验证")
    class ConstructionTests {

        @Test
        @DisplayName("应成功创建完整的 NormalizedRecordSnapshot")
        void shouldCreateFullyPopulatedSnapshot() {
            var source = new RevisionDtos.SnapshotSourceRef("REVISION", revisionId, 1, null, "hash");
            var identity = Map.of("id", recordId.toString(), "code", "REC001");
            var scalar = new NormalizedRecordSnapshot.ScalarValue("Test Title", "test title");
            var fixed = Map.of("title", scalar);
            var templateField = new NormalizedRecordSnapshot.NormalizedTemplateField(
                    "f1", "Field 1", "SINGLE_LINE_TEXT", true, 0, "value1", "value1");
            var block = new NormalizedRecordSnapshot.RichTextBlock("paragraph", "content", 0);
            var attachment = new NormalizedRecordSnapshot.NormalizedAttachment(
                    UUID.randomUUID(), "file.pdf", "application/pdf", 1024L,
                    UUID.randomUUID(), "Alice", Instant.now());

            var snapshot = new NormalizedRecordSnapshot(source, recordId, identity, fixed,
                    List.of(templateField), List.of(block), List.of(attachment), null,
                    "canonical-hash", List.of("warning1"));

            assertEquals(recordId, snapshot.recordId());
            assertEquals("canonical-hash", snapshot.canonicalHash());
            assertEquals(1, snapshot.fixedFields().size());
            assertEquals(1, snapshot.templateFields().size());
            assertEquals(1, snapshot.contentBlocks().size());
            assertEquals(1, snapshot.attachments().size());
            assertEquals(1, snapshot.warnings().size());
            assertNull(snapshot.reviewMetadata());
        }

        @Test
        @DisplayName("空集合应可正常工作")
        void shouldWorkWithEmptyCollections() {
            var source = new RevisionDtos.SnapshotSourceRef("WORKING_COPY", null, null, 1L, "hash");
            var snapshot = new NormalizedRecordSnapshot(source, recordId, Map.of(), Map.of(),
                    List.of(), List.of(), List.of(), null, "hash", List.of());

            assertTrue(snapshot.templateFields().isEmpty());
            assertTrue(snapshot.contentBlocks().isEmpty());
            assertTrue(snapshot.attachments().isEmpty());
        }

        @Test
        @DisplayName("包含 reviewMetadata 的快照")
        void shouldIncludeReviewMetadata() {
            var source = new RevisionDtos.SnapshotSourceRef("REVISION", revisionId, 1, null, "hash");
            var review = new NormalizedRecordSnapshot.ReviewMetadata(
                    "submit note", UUID.randomUUID(), "Reviewer", "APPROVED", "Good", Instant.now());
            var snapshot = new NormalizedRecordSnapshot(source, recordId, Map.of("id", "1"), Map.of(),
                    List.of(), List.of(), List.of(), review, "hash", List.of());

            assertNotNull(snapshot.reviewMetadata());
            assertEquals("APPROVED", snapshot.reviewMetadata().status());
        }
    }

    @Nested
    @DisplayName("ScalarValue")
    class ScalarValueTests {

        @Test
        @DisplayName("应该成功创建 ScalarValue")
        void shouldCreateScalarValue() {
            var sv = new NormalizedRecordSnapshot.ScalarValue("display", "normalized");
            assertEquals("display", sv.displayValue());
            assertEquals("normalized", sv.normalizedValue());
        }

        @Test
        @DisplayName("normalizedValue 可为空字符串")
        void shouldAllowEmptyNormalizedValue() {
            var sv = new NormalizedRecordSnapshot.ScalarValue(null, "");
            assertNull(sv.displayValue());
            assertEquals("", sv.normalizedValue());
        }
    }

    @Nested
    @DisplayName("NormalizedTemplateField")
    class NormalizedTemplateFieldTests {

        @Test
        @DisplayName("应该成功创建 NormalizedTemplateField")
        void shouldCreateTemplateField() {
            var field = new NormalizedRecordSnapshot.NormalizedTemplateField(
                    "key1", "Label", "NUMBER", true, 5, 42, "42.00");
            assertEquals("key1", field.fieldKey());
            assertEquals("Label", field.label());
            assertEquals("NUMBER", field.fieldType());
            assertTrue(field.required());
            assertEquals(5, field.sortOrder());
            assertEquals(42, field.displayValue());
            assertEquals("42.00", field.normalizedValue());
        }
    }

    @Nested
    @DisplayName("RichTextBlock")
    class RichTextBlockTests {

        @Test
        @DisplayName("应该成功创建 RichTextBlock")
        void shouldCreateRichTextBlock() {
            var block = new NormalizedRecordSnapshot.RichTextBlock("heading:1", "Title Text", 0);
            assertEquals("heading:1", block.type());
            assertEquals("Title Text", block.text());
            assertEquals(0, block.ordinal());
        }
    }

    @Nested
    @DisplayName("NormalizedAttachment")
    class NormalizedAttachmentTests {

        @Test
        @DisplayName("应该成功创建 NormalizedAttachment")
        void shouldCreateNormalizedAttachment() {
            var id = UUID.randomUUID();
            var uploaderId = UUID.randomUUID();
            var now = Instant.now();
            var att = new NormalizedRecordSnapshot.NormalizedAttachment(
                    id, "image.png", "image/png", 2048L, uploaderId, "Bob", now);
            assertEquals(id, att.id());
            assertEquals("image.png", att.filename());
            assertEquals("image/png", att.mediaType());
            assertEquals(2048L, att.sizeBytes());
        }
    }

    @Nested
    @DisplayName("ReviewMetadata")
    class ReviewMetadataTests {

        @Test
        @DisplayName("应该成功创建 ReviewMetadata")
        void shouldCreateReviewMetadata() {
            var reviewerId = UUID.randomUUID();
            var decidedAt = Instant.now();
            var meta = new NormalizedRecordSnapshot.ReviewMetadata(
                    "note", reviewerId, "Charlie", "REJECTED", "Needs improvement", decidedAt);
            assertEquals("note", meta.submitNote());
            assertEquals("Charlie", meta.reviewerName());
            assertEquals("REJECTED", meta.status());
        }

        @Test
        @DisplayName("decisionComment 和 decidedAt 可为 null")
        void shouldAllowNullCommentAndDecidedAt() {
            var meta = new NormalizedRecordSnapshot.ReviewMetadata(
                    null, UUID.randomUUID(), "Alice", "PENDING", null, null);
            assertNull(meta.submitNote());
            assertNull(meta.decisionComment());
            assertNull(meta.decidedAt());
        }
    }
}
