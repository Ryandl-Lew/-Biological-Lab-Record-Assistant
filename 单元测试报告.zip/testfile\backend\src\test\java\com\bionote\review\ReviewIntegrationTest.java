package com.bionote.review;

import com.bionote.review.infrastructure.persistence.JpaReviewStore;
import com.bionote.review.infrastructure.persistence.ReviewJpaRepository;
import com.bionote.review.infrastructure.persistence.ReviewEntity;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.context.annotation.Import;

import java.time.Instant;
import java.util.Optional;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@Import(JpaReviewStore.class)
class ReviewIntegrationTest {

    @Autowired private ReviewJpaRepository repository;
    @Autowired private JpaReviewStore reviewStore;

    private final UUID reviewId = UUID.randomUUID();
    private final UUID recordId = UUID.randomUUID();
    private final UUID revisionId = UUID.randomUUID();
    private final UUID reviewerId = UUID.randomUUID();

    @BeforeEach
    void setUp() {
        repository.deleteAll();
    }

    @Test
    void shouldPersistAndFindReview() {
        ReviewStore.ReviewRecord review = new ReviewStore.ReviewRecord(
                reviewId, recordId, revisionId, reviewerId, "PENDING",
                null, Instant.now(), null);
        reviewStore.append(review);

        Optional<ReviewStore.ReviewRecord> found = reviewStore.findById(reviewId);
        assertTrue(found.isPresent());
        assertEquals("PENDING", found.get().status());
        assertEquals(recordId, found.get().recordId());
    }

    @Test
    void shouldCheckExistsPending() {
        assertFalse(reviewStore.existsPending(recordId));

        ReviewStore.ReviewRecord review = new ReviewStore.ReviewRecord(
                reviewId, recordId, revisionId, reviewerId, "PENDING",
                null, Instant.now(), null);
        reviewStore.append(review);

        assertTrue(reviewStore.existsPending(recordId));
    }

    @Test
    void shouldFindByRevisionId() {
        ReviewStore.ReviewRecord review = new ReviewStore.ReviewRecord(
                reviewId, recordId, revisionId, reviewerId, "PENDING",
                null, Instant.now(), null);
        reviewStore.append(review);

        Optional<ReviewStore.ReviewRecord> found = reviewStore.findByRevisionId(revisionId);
        assertTrue(found.isPresent());
        assertEquals(reviewId, found.get().id());
    }

    @Test
    void shouldDecidePendingReview() {
        ReviewStore.ReviewRecord review = new ReviewStore.ReviewRecord(
                reviewId, recordId, revisionId, reviewerId, "PENDING",
                null, Instant.now(), null);
        reviewStore.append(review);

        boolean decided = reviewStore.decidePending(reviewId, "APPROVED", "通过审核", Instant.now());
        assertTrue(decided);

        Optional<ReviewStore.ReviewRecord> found = reviewStore.findById(reviewId);
        assertTrue(found.isPresent());
        assertEquals("APPROVED", found.get().status());
        assertEquals("通过审核", found.get().decisionComment());
    }

    @Test
    void shouldNotDecideAlreadyProcessedReview() {
        ReviewStore.ReviewRecord review = new ReviewStore.ReviewRecord(
                reviewId, recordId, revisionId, reviewerId, "PENDING",
                null, Instant.now(), null);
        reviewStore.append(review);

        reviewStore.decidePending(reviewId, "APPROVED", "pass", Instant.now());
        boolean secondDecide = reviewStore.decidePending(reviewId, "APPROVED", "again", Instant.now());

        assertFalse(secondDecide);
    }
}
