package com.bionote.revision;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

@DisplayName("RevisionDtos - DTO 测试")
class RevisionDtosTest {

    @Nested
    @DisplayName("ReviewSummary")
    class ReviewSummaryTests {

        @Test
        @DisplayName("应该成功创建 ReviewSummary")
        void shouldCreateReviewSummary() {
            var id = UUID.randomUUID();
            var reviewerId = UUID.randomUUID();
            var now = Instant.now();
            var review = new RevisionDtos.ReviewSummary(id, reviewerId, "Alice", "PENDING",
                    "需要修改", now, null, true);
            assertEquals(id, review.id());
            assertEquals("Alice", review.reviewerName());
            assertTrue(review.canDecide());
        }

        @Test
        @DisplayName("未决策的审核 canDecide 可为 false")
        void shouldHaveFalseCanDecide() {
            var review = new RevisionDtos.ReviewSummary(UUID.randomUUID(), UUID.randomUUID(),
                    "Bob", "APPROVED", null, Instant.now(), Instant.now(), false);
            assertFalse(review.canDecide());
        }
    }

    @Nested
    @DisplayName("AttachmentView")
    class AttachmentViewTests {

        @Test
        @DisplayName("应该成功创建 AttachmentView")
        void shouldCreateAttachmentView() {
            var id = UUID.randomUUID();
            var uploaderId = UUID.randomUUID();
            var now = Instant.now();
            var attachment = new RevisionDtos.AttachmentView(id, "file.pdf", "application/pdf",
                    2048L, uploaderId, "Alice", now);
            assertEquals(id, attachment.id());
            assertEquals("file.pdf", attachment.filename());
            assertEquals(2048L, attachment.sizeBytes());
        }
    }

    @Nested
    @DisplayName("RevisionSummary")
    class RevisionSummaryTests {

        @Test
        @DisplayName("应该成功创建 RevisionSummary")
        void shouldCreateRevisionSummary() {
            var review = new RevisionDtos.ReviewSummary(UUID.randomUUID(), UUID.randomUUID(),
                    "Reviewer", "APPROVED", null, Instant.now(), Instant.now(), false);
            var summary = new RevisionDtos.RevisionSummary(UUID.randomUUID(), UUID.randomUUID(),
                    1, "R1", UUID.randomUUID(), "Alice", Instant.now(), "Note", "hash", review,
                    3, true, false);
            assertEquals("R1", summary.label());
            assertEquals(3, summary.attachmentCount());
            assertTrue(summary.current());
        }
    }

    @Nested
    @DisplayName("SnapshotView")
    class SnapshotViewTests {

        @Test
        @DisplayName("应该成功创建 SnapshotView")
        void shouldCreateSnapshotView() {
            var view = new RevisionDtos.SnapshotView(UUID.randomUUID(), "REC001", UUID.randomUUID(),
                    UUID.randomUUID(), "Title", "TYPE", "2025-01-01", "purpose",
                    Map.of("key", "value"), Map.of("f1", "v1"), Map.of("c", "d"), "plain text");
            assertEquals("REC001", view.code());
            assertEquals("Title", view.title());
            assertNotNull(view.templateSnapshot());
        }
    }

    @Nested
    @DisplayName("RevisionDetail")
    class RevisionDetailTests {

        @Test
        @DisplayName("应该成功创建 RevisionDetail")
        void shouldCreateRevisionDetail() {
            var review = new RevisionDtos.ReviewSummary(UUID.randomUUID(), UUID.randomUUID(),
                    "Reviewer", "APPROVED", null, Instant.now(), Instant.now(), false);
            var detail = new RevisionDtos.RevisionDetail(UUID.randomUUID(), UUID.randomUUID(),
                    2, "R2", 1, null, "hash", UUID.randomUUID(), "Bob",
                    Instant.now(), "submit note", review, List.of(), false, true);
            assertEquals(2, detail.revisionNo());
            assertTrue(detail.finalRevision());
            assertEquals("Bob", detail.submitterName());
        }
    }

    @Nested
    @DisplayName("SnapshotSourceRef")
    class SnapshotSourceRefTests {

        @Test
        @DisplayName("应该成功创建 WORKING_COPY 类型的 SnapshotSourceRef")
        void shouldCreateWorkingCopyRef() {
            var ref = new RevisionDtos.SnapshotSourceRef("WORKING_COPY", null, null, 5L, "hash");
            assertEquals("WORKING_COPY", ref.type());
            assertEquals(5L, ref.recordVersion());
        }

        @Test
        @DisplayName("应该成功创建 REVISION 类型的 SnapshotSourceRef")
        void shouldCreateRevisionRef() {
            var ref = new RevisionDtos.SnapshotSourceRef("REVISION", UUID.randomUUID(), 3, null, "hash");
            assertEquals("REVISION", ref.type());
            assertEquals(3, ref.revisionNo());
        }
    }

    @Nested
    @DisplayName("TextOperation")
    class TextOperationTests {

        @Test
        @DisplayName("应该成功创建 TextOperation")
        void shouldCreateTextOperation() {
            var op = new RevisionDtos.TextOperation("INSERT", "hello");
            assertEquals("INSERT", op.operation());
            assertEquals("hello", op.text());
        }
    }

    @Nested
    @DisplayName("DiffSection")
    class DiffSectionTests {

        @Test
        @DisplayName("应该成功创建 DiffSection")
        void shouldCreateDiffSection() {
            var section = new RevisionDtos.DiffSection("key1", "Label", "fixed", "text",
                    "MODIFIED", "before", "after", List.of(), Map.of());
            assertEquals("key1", section.key());
            assertEquals("MODIFIED", section.status());
            assertEquals("before", section.before());
            assertEquals("after", section.after());
        }
    }

    @Nested
    @DisplayName("DiffSummary")
    class DiffSummaryTests {

        @Test
        @DisplayName("应该成功创建 DiffSummary")
        void shouldCreateDiffSummary() {
            var summary = new RevisionDtos.DiffSummary(1, 2, 3, 4, 0, 0);
            assertEquals(1, summary.added());
            assertEquals(2, summary.removed());
            assertEquals(3, summary.modified());
            assertEquals(4, summary.unchanged());
        }
    }

    @Nested
    @DisplayName("DiffResult")
    class DiffResultTests {

        @Test
        @DisplayName("应该成功创建 DiffResult")
        void shouldCreateDiffResult() {
            var from = new RevisionDtos.SnapshotSourceRef("REVISION", UUID.randomUUID(), 1, null, "h1");
            var to = new RevisionDtos.SnapshotSourceRef("WORKING_COPY", null, null, 3L, "h2");
            var summary = new RevisionDtos.DiffSummary(2, 1, 0, 3, 1, 0);
            var result = new RevisionDtos.DiffResult(UUID.randomUUID(), from, to, summary,
                    List.of(), false, List.of(), Instant.now());
            assertEquals("REVISION", result.from().type());
            assertEquals("WORKING_COPY", result.to().type());
            assertFalse(result.truncated());
        }
    }
}
