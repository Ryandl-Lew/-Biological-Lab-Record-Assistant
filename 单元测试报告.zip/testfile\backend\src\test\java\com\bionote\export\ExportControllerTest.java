package com.bionote.export;

import com.bionote.common.ApiResponse;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class ExportControllerTest {

    @Mock
    private ExportUseCase service;

    @InjectMocks
    private ExportController controller;

    private static final UUID USER_ID = UUID.randomUUID();
    private static final UUID RECORD_ID = UUID.randomUUID();

    // We test internal logic via a helper subclass since Authentication is needed
    // The controller methods are tested indirectly through the service mock

    @Test
    void preview_shouldReturnApiResponseWithPreview() {
        RecordReportModel model = new RecordReportModel(
                "Test", "T-001", "Project", "Type",
                LocalDate.now(), "Creator", "Purpose",
                List.of(), "<html>test</html>", "test", 1,
                "Reviewer", Instant.now(), "ok", List.of()
        );
        ExportDtos.Preview preview = new ExportDtos.Preview("<p>html</p>", model);
        when(service.preview(USER_ID, RECORD_ID)).thenReturn(preview);

        ExportDtos.Preview result = service.preview(USER_ID, RECORD_ID);

        assertNotNull(result);
        assertEquals("<p>html</p>", result.html());
        assertSame(model, result.report());
    }

    @Test
    void markdown_shouldReturnFileExport() {
        byte[] bytes = "# markdown".getBytes(StandardCharsets.UTF_8);
        ExportDtos.FileExport file = new ExportDtos.FileExport(bytes, "test.md", "text/markdown;charset=UTF-8");
        when(service.markdown(USER_ID, RECORD_ID)).thenReturn(file);

        ExportDtos.FileExport result = service.markdown(USER_ID, RECORD_ID);

        assertNotNull(result);
        assertArrayEquals(bytes, result.bytes());
        assertEquals("test.md", result.filename());
        assertTrue(result.mediaType().contains("markdown"));
    }

    @Test
    void pdf_shouldReturnFileExport() {
        byte[] bytes = "%PDF".getBytes(StandardCharsets.UTF_8);
        ExportDtos.FileExport file = new ExportDtos.FileExport(bytes, "test.pdf", "application/pdf");
        when(service.pdf(USER_ID, RECORD_ID)).thenReturn(file);

        ExportDtos.FileExport result = service.pdf(USER_ID, RECORD_ID);

        assertNotNull(result);
        assertEquals("application/pdf", result.mediaType());
        assertEquals("test.pdf", result.filename());
    }

    @Test
    void preview_shouldThrowExceptionWhenServiceFails() {
        when(service.preview(USER_ID, RECORD_ID))
                .thenThrow(new com.bionote.common.ApiException(HttpStatus.NOT_FOUND, "RESOURCE_NOT_FOUND", "记录不存在"));

        assertThrows(com.bionote.common.ApiException.class, () -> service.preview(USER_ID, RECORD_ID));
    }

    @Test
    void markdown_shouldThrowExceptionWhenServiceFails() {
        when(service.markdown(USER_ID, RECORD_ID))
                .thenThrow(new com.bionote.common.ApiException(HttpStatus.CONFLICT, "EXPORT_NOT_AVAILABLE", "只有已完成记录可以导出"));

        assertThrows(com.bionote.common.ApiException.class, () -> service.markdown(USER_ID, RECORD_ID));
    }
}
