package com.bionote.revision;

import com.bionote.common.ApiException;
import com.bionote.common.ApiResponse;
import com.bionote.common.PagedResponse;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.mockito.junit.jupiter.MockitoSettings;
import org.mockito.quality.Strictness;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
@MockitoSettings(strictness = Strictness.LENIENT)
@DisplayName("RevisionController - 修订接口测试")
class RevisionControllerTest {

    @Mock private RevisionQueryUseCase queries;
    @Mock private RevisionDiffUseCase diffs;
    @Mock private Authentication authentication;

    @InjectMocks private RevisionController controller;

    private final UUID userId = UUID.randomUUID();
    private final UUID recordId = UUID.randomUUID();
    private final UUID revisionId = UUID.randomUUID();

    @Nested
    @DisplayName("GET /api/v1/records/{recordId}/revisions")
    class ListTests {

        @Test
        @DisplayName("分页查询成功应返回分页数据")
        void shouldReturnRevisionPage() {
            when(authentication.getName()).thenReturn(userId.toString());
            var page = PagedResponse.of(List.of(), 0, 20, 0L);
            when(queries.list(eq(userId), eq(recordId), eq(0), eq(20))).thenReturn(page);

            var result = controller.list(authentication, recordId, 0, 20);

            assertNotNull(result);
            assertEquals(0, result.meta().page());
            assertEquals(20, result.meta().size());
        }

        @Test
        @DisplayName("支持自定义分页参数")
        void shouldSupportCustomPagination() {
            when(authentication.getName()).thenReturn(userId.toString());
            var page = PagedResponse.of(List.of(), 2, 5, 25L);
            when(queries.list(eq(userId), eq(recordId), eq(2), eq(5))).thenReturn(page);

            var result = controller.list(authentication, recordId, 2, 5);

            assertNotNull(result);
            assertEquals(2, result.meta().page());
            assertEquals(5, result.meta().size());
        }

        @Test
        @DisplayName("未认证应返回错误")
        void shouldReturnUnauthorizedForAnonymous() {
            when(authentication.getName()).thenReturn("not-a-valid-uuid");
            assertThrows(IllegalArgumentException.class, () ->
                    controller.list(authentication, recordId, 0, 20));
        }
    }

    @Nested
    @DisplayName("GET /api/v1/records/{recordId}/revisions/{revisionId}")
    class DetailTests {

        @Test
        @DisplayName("查询详情成功应返回详情")
        void shouldReturnRevisionDetail() {
            when(authentication.getName()).thenReturn(userId.toString());
            var review = new RevisionDtos.ReviewSummary(UUID.randomUUID(), UUID.randomUUID(),
                    "Reviewer", "APPROVED", null, Instant.now(), Instant.now(), false);
            var detail = new RevisionDtos.RevisionDetail(revisionId, recordId, 1, "R1", 1, null,
                    "hash", userId, "Alice", Instant.now(), null, review, List.of(), true, false);
            when(queries.detail(eq(userId), eq(recordId), eq(revisionId))).thenReturn(detail);

            var result = controller.detail(authentication, recordId, revisionId);

            assertNotNull(result);
            assertEquals(1, result.getData().revisionNo());
            assertEquals("R1", result.getData().label());
            assertEquals("Alice", result.getData().submitterName());
        }

        @Test
        @DisplayName("查询不存在的修订应返回错误")
        void shouldPropagateNotFoundError() {
            when(authentication.getName()).thenReturn(userId.toString());
            when(queries.detail(eq(userId), eq(recordId), eq(revisionId)))
                    .thenThrow(new ApiException(HttpStatus.NOT_FOUND, "REVISION_NOT_FOUND", "修订不存在"));

            assertThrows(ApiException.class, () ->
                    controller.detail(authentication, recordId, revisionId));
        }
    }

    @Nested
    @DisplayName("GET /api/v1/revisions/{revisionId} (legacy)")
    class LegacyDetailTests {

        @Test
        @DisplayName("兼容旧路径应返回详情")
        void shouldReturnLegacyDetail() {
            when(authentication.getName()).thenReturn(userId.toString());
            var review = new RevisionDtos.ReviewSummary(UUID.randomUUID(), UUID.randomUUID(),
                    "Reviewer", "PENDING", null, Instant.now(), null, true);
            var detail = new RevisionDtos.RevisionDetail(revisionId, recordId, 2, "R2", 1, null,
                    "hash2", userId, "Bob", Instant.now(), "note", review, List.of(), false, false);
            when(queries.legacyDetail(eq(userId), eq(revisionId))).thenReturn(detail);

            var result = controller.legacyDetail(authentication, revisionId);

            assertNotNull(result);
            assertEquals("R2", result.getData().label());
            assertEquals("Bob", result.getData().submitterName());
        }
    }

    @Nested
    @DisplayName("GET /api/v1/records/{recordId}/revision-diff")
    class DiffTests {

        @Test
        @DisplayName("diff 成功应返回 diff 结果")
        void shouldReturnDiffResult() {
            when(authentication.getName()).thenReturn(userId.toString());
            var summary = new RevisionDtos.DiffSummary(1, 2, 3, 4, 0, 0);
            var diffResult = new RevisionDtos.DiffResult(recordId,
                    new RevisionDtos.SnapshotSourceRef("REVISION", revisionId, 1, null, "h1"),
                    new RevisionDtos.SnapshotSourceRef("WORKING_COPY", null, null, 5L, "h2"),
                    summary, List.of(), false, List.of(), Instant.now());
            when(diffs.compare(any(), eq(recordId), any(), any(), any(), eq(false))).thenReturn(diffResult);

            var result = controller.diff(authentication, recordId, revisionId, null, "WORKING_COPY", false);

            assertNotNull(result);
            assertEquals(1, result.getData().summary().added());
            assertEquals(2, result.getData().summary().removed());
        }
    }
}
